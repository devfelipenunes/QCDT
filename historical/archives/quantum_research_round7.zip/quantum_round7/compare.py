"""Query-count planning and a sparse classical comparator on degree-one cubic functions."""
import json,random,math,statistics
from pathlib import Path
from previous import direct_recover
from weighted import recover
from soft_noise import candidates
from crt import mul_terms as crt_terms
import weighted
from previous import mul_terms as kara_terms
R=random.Random(716);rows=[]
for n,d in [(12,1),(16,2),(32,2),(64,2),(128,2),(256,2),(64,8),(128,8)]:
    z=lambda a,b:0
    q4=direct_recover(n,d,z,compact=True)[1];weighted.mul_terms=kara_terms;q5=recover(n,d,z)[1];weighted.mul_terms=crt_terms;qc=recover(n,d,z)[1]
    row=dict(n=n,d=d,dense_cubic_phase_calls=4*math.comb(n-1,2),qcdt04=q4,qcdt05=q5,qcdt05_crt=qc,best=min(q4,q5,qc));rows.append(row);print(row,flush=True)

def f(e,x):return sum(all(x>>i&1 for i in t) for t in e)%2
small=[]
for n in [5,6,7]:
    cs=candidates(n);domain=range(1<<n);lookup={x:[f(e,x) for e in cs] for x in domain};counts=[];random_counts=[]
    # Select point with most balanced split among surviving hypotheses; expensive but strong at tiny n.
    for e in cs:
        active=list(range(len(cs)));count=0
        while len(active)>1:
            x=max(domain,key=lambda x:min(sum(lookup[x][i] for i in active),len(active)-sum(lookup[x][i] for i in active)))
            val=f(e,x);new=[i for i in active if lookup[x][i]==val];assert len(new)<len(active);active=new;count+=1
        assert cs[active[0]]==e;counts.append(count)
    row=dict(n=n,candidates=len(cs),exact=len(cs),classical_greedy_median_value_calls=statistics.median(counts),classical_greedy_worst_value_calls=max(counts),qcdt04_cubic_phase_calls=direct_recover(n,1,lambda a,b:0,compact=True)[1]);small.append(row);print(row,flush=True)
Path(__file__).with_name('comparison_results.json').write_text(json.dumps(dict(query_plans=rows,classical_sparse=small),indent=2))
