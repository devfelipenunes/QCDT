"""Unknown-degree recovery with independent one-sided random certification."""
import math,random,json,statistics
from pathlib import Path
from previous import direct_recover,random_hypergraph,contraction,statevector_probe
from weighted import recover as weighted
from functools import lru_cache

@lru_cache(None)
def plan(n,d):
    q0=direct_recover(n,d,lambda a,b:0,compact=True)[1]
    q1=weighted(n,d,lambda a,b:0)[1]
    return ('v04' if q0<=q1 else 'v05',min(q0,q1))

def adaptive(n,probe,rng,delta=.01,cap=None):
    if not 0<delta<1:raise ValueError('delta')
    cap=math.comb(n-1,2) if cap is None else min(cap,math.comb(n-1,2)); d=1;stage=0;history=[];calls=0
    def query(a,b):
        nonlocal calls
        calls+=4;return probe(a,b)
    while True:
        mode,pred=plan(n,d)
        try:
            es,_=(direct_recover(n,d,query,compact=True) if mode=='v04' else weighted(n,d,query))
        except (ValueError,AssertionError,ZeroDivisionError,KeyError,IndexError):es=None
        # sum 1/((s+1)(s+2)) = 1, so a union bound applies to all stages
        epsilon=delta/((stage+1)*(stage+2));r=math.ceil(math.log(epsilon)/math.log(5/8));checks=0;accepted=es is not None
        if accepted:
            for _ in range(r):
                a,b=rng.getrandbits(n),rng.getrandbits(n);checks+=1
                if query(a,b)!=contraction(es,a,b):accepted=False;break
        history.append(dict(d=d,mode=mode,predicted_phase_calls=pred,checks=checks,accepted=accepted))
        if accepted:return es,calls,history
        if d>=cap:raise ValueError('no certified candidate at cap')
        d=min(2*d,cap);stage+=1

def run():
    rng=random.Random(7132026);rows=[]
    for n,d,reps in [(6,0,20),(6,1,20),(9,2,20),(12,3,16),(24,4,12),(32,8,6)]:
        calls=[];cert=[];accepted=[];fail=0;stage_counts=[];wrong=0
        for _ in range(reps):
            es=random_hypergraph(n,d,rng);p=statevector_probe(n,es,rng) if n<=12 else lambda a,b:contraction(es,a,b)
            got,q,h=adaptive(n,p,rng,delta=.01,cap=8);wrong+=got!=es;calls.append(q);cert.append(h[-1]['d']);stage_counts.append(len(h));accepted.append(h[-1]['mode'])
        row=dict(n=n,degree_bound=d,cases=reps,wrong=wrong,median_phase_calls=statistics.median(calls),median_final_bound=statistics.median(cert),median_stages=statistics.median(stage_counts),selected_modes={m:accepted.count(m) for m in set(accepted)},mode='statevector' if n<=12 else 'contraction');rows.append(row);print(row,flush=True)
    # Exact worst-case witness acceptance probability: one edge difference, rank 2 in a selected link.
    # Check all mask pairs at n=3, comparing entire vector and one coordinate.
    e={(0,1,2)};one=allbits=0
    for a in range(8):
        for b in range(8):
            z=contraction(e,a,b);one+=(z&1)==0;allbits+=z==0
    assert one==40 and allbits<=40
    Path(__file__).with_name('adaptive_results.json').write_text(json.dumps(dict(rows=rows,single_coordinate_pass=one/64,full_vector_pass=allbits/64),indent=2))
if __name__=='__main__':run()
