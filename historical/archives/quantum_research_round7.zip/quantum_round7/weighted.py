from previous import CompactField, roots, masks, mul_terms

def bm(seq,g,d):
 C=[1]+[0]*len(seq); B=C.copy(); L=0; shift=1; last=1
 for i,s in enumerate(seq):
  delta=s
  for j in range(1,L+1):delta^=g.mul(C[j],seq[i-j])
  if not delta:shift+=1;continue
  old=C.copy();c=g.div(delta,last)
  for j in range(len(C)-shift):C[j+shift]^=g.mul(c,B[j])
  if 2*L<=i:L=i+1-L;B=old;last=delta;shift=1
  else:shift+=1
 assert L<=d
 return C[:L+1]
class Tower:
 def __init__(self,m):
  self.base=CompactField(m);self.h=m;self.m=2*m;self.q=1<<self.m;self.mod=self.q-1;self.mask=(1<<m)-1
  def trace(x):
   t=x
   for _ in range(1,m):x=self.base.mul(x,x);t^=x
   return t
  self.beta=next(x for x in (1<<j for j in range(m)) if trace(x)==1)
 def mul(self,a,b):
  a0,a1=a&self.mask,a>>self.h;b0,b1=b&self.mask,b>>self.h;g=self.base
  p=g.mul(a0,b0);q=g.mul(a1,b1);r=g.mul(a0^a1,b0^b1)
  return (p^g.mul(self.beta,q))|((r^p)<<self.h)
 def pow(self,a,t):
  r=1
  while t:
   if t&1:r=self.mul(r,a)
   a=self.mul(a,a);t>>=1
  return r
 def div(self,a,b):
  assert b
  return self.mul(a,self.pow(b,self.mod-1))
 def terms(self,a,b):
  h=self.h;a0,a1=a[:h],a[h:];b0,b1=b[:h],b[h:]
  for x,y,w in mul_terms(a0,b0,self.base):yield x,y,w|(w<<h)
  for x,y,w in mul_terms(a1,b1,self.base):yield x,y,self.base.mul(self.beta,w)
  for x,y,w in mul_terms([x^y for x,y in zip(a0,a1)],[x^y for x,y in zip(b0,b1)],self.base):yield x,y,w<<h

def recover(n,d,probe,verify=None):
 g=Tower(max(2,n.bit_length()));K=g.base;h=g.h;xs=list(range(1,n+1));labels=[(1<<h)|x for x in xs]
 cache={};moments=[[] for _ in xs]
 def query(a,b):
  if not a or not b or a==b:return 0
  key=tuple(sorted((a,b)))
  if key not in cache:cache[key]=probe(*key)
  return cache[key]
 powers=[1]*n
 for t in range(2*d):
  out=[0]*n;a=masks([g.mul(x,p) for x,p in zip(xs,powers)],g.m);b=masks(powers,g.m)
  for ma,mb,w in g.terms(a,b):
   bits=query(ma,mb)
   while bits:
    low=bits&-bits;out[low.bit_length()-1]^=w;bits^=low
  if verify is not None:
   expected=[0]*n
   for e in verify:
    for i,j,k in (e,(e[1],e[0],e[2]),(e[2],e[0],e[1])):expected[i]^=g.mul(xs[j]^xs[k],g.pow(g.mul(labels[j],labels[k]),t))
   assert out==expected,(t,out,expected)
  for i,v in enumerate(out):moments[i].append(v)
  powers=[g.mul(p,L) for p,L in zip(powers,labels)]
 links=[]
 for i,seq in enumerate(moments):
  C=bm(seq,g,d);found=[]
  for root in roots(C,g):
   z=g.div(1,root);s=(z>>h)^1;p=(z&g.mask)^g.beta;assert s
   pair=tuple(sorted(x-1 for x in roots([p,s,1],K)))
   assert len(pair)==2 and 0<=pair[0]<pair[1]<n and i not in pair
   found.append(pair)
  for t,observed in enumerate(seq):
   value=0
   for j,k in found:value^=g.mul(xs[j]^xs[k],g.pow(g.mul(labels[j],labels[k]),t))
   assert value==observed
  links.append(set(found))
 es={tuple(sorted((i,*p))) for i,L in enumerate(links) for p in L}
 for i,j,k in es:assert (j,k) in links[i] and (i,k) in links[j] and (i,j) in links[k]
 return es,4*len(cache)
