"""QCDT v0.1: ideal statevector prototype for sparse cubic Boolean terms.
Run: python qcdt.py   (requires numpy). No quantum hardware used.
Bit i corresponds to variable x_i, using zero-based indices.
"""
from itertools import combinations
from math import comb, ceil, log
import numpy as np


def mask(indices):
    return sum(1 << i for i in indices)


def make_truth_table(n, terms):
    """Construct a test oracle from monomials, including optional lower terms."""
    x = np.arange(1 << n, dtype=np.int64)
    f = np.zeros(len(x), dtype=np.uint8)
    for term in terms:
        m = mask(term)
        f ^= ((x & m) == m).astype(np.uint8)
    return f


def derivative_bv(f, a, b):
    """Simulate H^n U_f X^... U_f ... H^n via its exact phase vector.
    Four logical phase-oracle calls (truth-table implementation for simulation).
    Returns the measured coefficient word for a polynomial of degree <=3.
    """
    x = np.arange(len(f), dtype=np.int64)
    phase = f[x] ^ f[x ^ a] ^ f[x ^ b] ^ f[x ^ a ^ b]
    state = (1.0 - 2.0 * phase) / np.sqrt(len(f))
    step = 1
    while step < len(f):
        v = state.reshape(-1, 2 * step)
        left, right = v[:, :step].copy(), v[:, step:].copy()
        v[:, :step] = (left + right) / np.sqrt(2)
        v[:, step:] = (left - right) / np.sqrt(2)
        step *= 2
    probs = state ** 2
    word = int(np.argmax(probs))
    if not np.isclose(probs[word], 1.0, atol=1e-10):
        raise ValueError('Derivative is not affine or simulation failed')
    return word


def pair_signature(i, j, probes):
    """Bit t = a_i*b_j XOR a_j*b_i for probe t."""
    return sum((((a >> i & 1) * (b >> j & 1)) ^
                 ((a >> j & 1) * (b >> i & 1))) << t
               for t, (a, b) in enumerate(probes))


def recover(n, d, probes, words):
    """Brute-force sparse decoding. Reject ambiguity and inconsistent edges."""
    signatures = {(i, j): pair_signature(i, j, probes)
                  for i, j in combinations(range(n), 2)}
    local = []
    for v in range(n):
        target = sum((w >> v & 1) << t for t, w in enumerate(words))
        pairs = [p for p in signatures if v not in p]
        matches = []
        for k in range(min(d, len(pairs)) + 1):
            for subset in combinations(pairs, k):
                s = 0
                for p in subset:
                    s ^= signatures[p]
                if s == target:
                    matches.append(subset)
                    if len(matches) > 1:
                        raise ValueError('Ambiguous syndrome; add more probes')
        if len(matches) != 1:
            raise ValueError('No matching syndrome; verify sparsity and oracle')
        local.append(set(matches[0]))
    edges = {tuple(sorted((v, *p))) for v, pairs in enumerate(local) for p in pairs}
    for edge in edges:
        for v in edge:
            if tuple(i for i in edge if i != v) not in local[v]:
                raise ValueError('Inconsistent hyperedge; add more probes')
    return edges


def num_probes(n, d, delta=0.01):
    m = comb(n-1, 2)
    candidates = sum(comb(m, k) for k in range(min(d, m)+1))
    return ceil(log(n*candidates/delta) / log(8/5))


def qcdt(f, n, d, seed=0, t=None):
    t = num_probes(n, d) if t is None else t
    rng = np.random.default_rng(seed)
    probes = [(int(a), int(b)) for a, b in rng.integers(0, 1 << n, size=(t,2))]
    words = [derivative_bv(f, a, b) for a, b in probes]
    return recover(n, d, probes, words), 4*t


def build_qiskit_probe(phase_oracle, a, b):
    """H, U_f, X_a, U_f, X_b, U_f, X_a, U_f, X_b, H, measure."""
    from qiskit import QuantumCircuit
    n = phase_oracle.num_qubits
    qc = QuantumCircuit(n, n)
    qc.h(range(n))
    for shift in (a, b, a, b):
        qc.append(phase_oracle, list(range(n)))
        for i in range(n):
            if shift >> i & 1:
                qc.x(i)
    qc.h(range(n))
    qc.measure(range(n), range(n))
    return qc


def benchmark():
    n, d, trials = 9, 2, 50
    rng = np.random.default_rng(20261125)
    t = num_probes(n,d)
    ok = 0
    for trial in range(trials):
        candidates = list(combinations(range(n), 3))
        degree = [0]*n
        edges = set()
        for idx in rng.permutation(len(candidates)):
            edge = candidates[int(idx)]
            if all(degree[i] < d for i in edge):
                edges.add(edge)
                for i in edge:
                    degree[i] += 1
        lower = [term for k in range(3) for term in combinations(range(n), k)
                 if rng.integers(0,2)]
        f = make_truth_table(n, list(edges)+lower)
        try:
            got, calls = qcdt(f,n,d,seed=trial,t=t)
        except ValueError:
            continue
        ok += got == edges
        if trial == 0:
            print('Example hidden:', sorted(edges))
            print('Example recovered:', sorted(got))
    print(f'{ok}/{trials} exact recoveries; n={n}, d={d}, probes={t}, phase calls={4*t} per trial')

if __name__ == '__main__':
    benchmark()
