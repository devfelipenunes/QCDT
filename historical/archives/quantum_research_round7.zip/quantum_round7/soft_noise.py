"""Paired comparison for degree-one links. Soft candidate decoder is combinatorial, small n only."""
from pathlib import Path
import random,itertools as it,json,math
import numpy as np
from circuit import Simulator,oracle_gates,derivative
from previous import direct_recover,random_hypergraph
from round4_reference import contraction
R=random.Random(7251);N=np.random.default_rng(7251);BASE=Path(__file__).parent

def candidates(n):
    # Exhaustively enumerate vertex-disjoint triples (degree bound 1).
    def rec(remaining):
        if len(remaining)<3:yield frozenset();return
        i,*tail=remaining
        yield from rec(tail)
        for j,k in it.combinations(tail,2):
            for h in rec([x for x in tail if x not in (j,k)]):yield h|{(i,j,k)}
    return list(rec(list(range(n))))

def main():
    rows=[]
    for n,reps in [(5,30),(6,20)]:
        sim=Simulator(n);cs=candidates(n);plan={}
        direct_recover(n,1,lambda a,b:plan.setdefault((a,b),0),compact=True)
        keys=list(plan);pred=np.array([[[contraction(c,a,b)>>i&1 for i in range(n)] for a,b in keys] for c in cs],dtype=np.int16)
        assert len({tuple(r.flatten()) for r in pred})==len(cs)
        cases=[random_hypergraph(n,1,R) for _ in range(reps)]
        for p in [.001,.005,.01]:
            for shots in [1,5,9]:
                hard=soft=hr=sr=hw=sw=0
                for es in cases:
                    terms=es|{(i,) for i in range(n) if R.random()<.5}|{(0,1),(2,3)};og=oracle_gates(terms);counts=[];m={}
                    for a,b in keys:
                        g=derivative(n,og,(a,b));outs=[sim.run(g,N,p,.002) for _ in range(shots)];c=[sum(x>>i&1 for x in outs) for i in range(n)];counts.append(c);m[a,b]=sum((v>shots//2)<<i for i,v in enumerate(c))
                    try:
                        got,_=direct_recover(n,1,lambda a,b:m[a,b],compact=True);hard+=got==es;hw+=got!=es
                    except (ValueError,AssertionError,KeyError,IndexError,ZeroDivisionError):hr+=1
                    # Negative log-likelihood up to affine scaling under equal independent bit flip probability <1/2;
                    # actual gate noise is correlated, so use as a heuristic rather than exact likelihood.
                    c=np.array(counts);cost=(pred*(shots-2*c)+c).sum(axis=(1,2));idx=np.flatnonzero(cost==cost.min())
                    if len(idx)!=1:sr+=1
                    else:
                        got=cs[int(idx[0])];soft+=got==es;sw+=got!=es
                row=dict(n=n,degree=1,candidates=len(cs),p_gate=p,shots=shots,trials=reps,hard_exact=hard,hard_wrong=hw,hard_reject=hr,soft_exact=soft,soft_wrong=sw,soft_reject=sr,phase_calls_per_case=4*len(keys)*shots);rows.append(row);print(row,flush=True)
    (BASE/'soft_noise_results.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':main()
