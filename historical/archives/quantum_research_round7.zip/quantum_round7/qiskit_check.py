"""External integration test: run after installing qiskit and qiskit-aer.
NOT executed in the research container. Uses Aer simulator, not physical hardware."""
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from circuit import qiskit_probe, learn_unitary
from round4_reference import contraction

def oracle(n,terms):
    qc=QuantumCircuit(n)
    for t in sorted(terms):
        if len(t)==1:qc.z(*t)
        elif len(t)==2:qc.cz(*t)
        elif len(t)==3:qc.ccz(*t)
    return qc

def main():
    n=6;terms={(0,1,2),(2,3,4),(0,4),(1,5),(3,)};backend=AerSimulator()
    def probe(ds,known):return qiskit_probe(oracle(n,terms^known),ds,backend,shots=3)
    cubic={t for t in terms if len(t)==3}
    for a,b in [(3,12),(7,24),(1,2),(0,63)]:assert probe((a,b),set())==contraction(cubic,a,b)
    got,queries=learn_unitary(n,2,2,probe);assert got==terms
    print('Aer test passed',queries,'phase calls per single-shot schedule')
if __name__=='__main__':main()
