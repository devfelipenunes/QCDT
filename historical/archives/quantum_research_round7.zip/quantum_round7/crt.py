"""Finite-size CRT bilinear decomposition; not an asymptotic Chudnovsky implementation."""
from functools import lru_cache
from previous import CompactField

def pmul(a,b):
    r=0
    while b:
        if b&1:r^=a
        a<<=1;b>>=1
    return r

def prem(a,p):
    while a and a.bit_length()>=p.bit_length():a^=p<<(a.bit_length()-p.bit_length())
    return a

def pdiv(a,p):
    q=0
    while a and a.bit_length()>=p.bit_length():
        k=a.bit_length()-p.bit_length();q^=1<<k;a^=p<<k
    assert not a;return q

def irreducibles(maxdeg=5):
    known=[]
    for d in range(1,maxdeg+1):
        for p in range(1<<d,1<<(d+1)):
            if all(prem(p,q) for q in known if q.bit_length()-1<=d//2):known.append(p)
    return known

def poly_terms(a,b):
    if not any(a) or not any(b):return []
    if len(a)==1:return [(a[0],b[0],1)] if a[0] and b[0] else []
    h=(len(a)+1)//2; a0,a1=a[:h],a[h:]+[0]*(2*h-len(a));b0,b1=b[:h],b[h:]+[0]*(2*h-len(b));out=[]
    for x,y,w in poly_terms(a0,b0):out.append((x,y,w^(w<<h)))
    for x,y,w in poly_terms(a1,b1):out.append((x,y,(w<<h)^(w<<(2*h))))
    for x,y,w in poly_terms([x^y for x,y in zip(a0,a1)],[x^y for x,y in zip(b0,b1)]):out.append((x,y,w<<h))
    return out

@lru_cache(None)
def decomposition(m,mod):
    # Include infinity to recover the leading coefficient of the polynomial product.
    # Residue moduli must be distinct and their total degree >= 2m-2.
    target=2*m-2;ps=irreducibles();dp={0:(0,())}
    for p in ps:
        d=p.bit_length()-1;cost=len(poly_terms([1<<i for i in range(d)],[1<<i for i in range(d)]))
        for k,(c,ss) in list(dp.items()):
            kk=min(target,k+d);cc=c+cost
            if kk not in dp or cc<dp[kk][0]:dp[kk]=(cc,ss+(p,))
    _,chosen=dp[target];P=1
    for p in chosen:P=pmul(P,p)
    out=[]
    for p in chosen:
        d=p.bit_length()-1;M=pdiv(P,p);res=prem(M,p);inv=next(v for v in range(1,1<<d) if prem(pmul(v,res),p)==1);coeff=pmul(M,inv)
        forms=[sum(((prem(1<<i,p)>>j)&1)<<i for i in range(m)) for j in range(d)]
        for a,b,w in poly_terms(forms,forms):
            w=prem(prem(pmul(coeff,prem(w,p)),P),mod)
            if a and b and w:out.append((a,b,w))
    # Correct infinity by subtracting its residues from interpolant.
    correction=(1<<(2*m-2))^prem(1<<(2*m-2),P)
    correction=prem(correction,mod)
    if correction:out.append((1<<(m-1),1<<(m-1),correction))
    # If P has degree greater than 2m-2, the interpolation is already exact and correction is zero.
    return tuple(out),chosen

def transform(a,mask):
    out=0
    while mask:
        x=mask&-mask;out^=a[x.bit_length()-1];mask^=x
    return out

def mul_terms(a,b,g,karatsuba=True):
    if not karatsuba:raise ValueError('CRT backend only')
    assert len(a)==len(b)==g.m
    for x,y,w in decomposition(g.m,g.poly)[0]:
        u,v=transform(a,x),transform(b,y)
        if u and v:yield u,v,w

if __name__=='__main__':
    import json,random
    from pathlib import Path
    from previous import mul_terms as old,random_hypergraph
    from round4_reference import contraction
    import weighted
    rng=random.Random(725);rows=[];checks=0
    for m in range(2,12):
        g=CompactField(m);dec,mods=decomposition(m,g.poly)
        for i in range(m):
            for j in range(m):
                v=0
                for a,b,w in dec:
                    if a>>i&1 and b>>j&1:v^=w
                assert v==g.mul(1<<i,1<<j),(m,i,j,v,g.mul(1<<i,1<<j));checks+=1
        rk=len(list(old([1<<i for i in range(m)],[1<<i for i in range(m)],g)))
        print('rank',m,rk,len(dec),mods,flush=True)
        rows.append(dict(m=m,karatsuba_rank=rk,crt_rank=len(dec),moduli=mods))
    tests=[]
    for n,d in [(9,2),(12,4),(32,4),(64,8),(128,8),(256,2)]:
        es=random_hypergraph(n,d,rng);p=lambda a,b:contraction(es,a,b)
        weighted.mul_terms=old;a,q1=weighted.recover(n,d,p);weighted.mul_terms=mul_terms;b,q2=weighted.recover(n,d,p);assert a==b==es
        row=dict(n=n,d=d,karatsuba_phase_calls=q1,crt_phase_calls=q2,exact=True);tests.append(row);print(row,flush=True)
    Path(__file__).with_name('crt_results.json').write_text(json.dumps(dict(basis_products=checks,ranks=rows,tests=tests),indent=2))
