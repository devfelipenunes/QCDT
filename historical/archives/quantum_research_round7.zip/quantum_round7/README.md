# QCDT — round 7 reproducibility and research gate

**Status: research candidate, not peer-reviewed, no priority claim.** QCDT denotes a sequence of constructions for locally sparse cubic Boolean phase oracles. This round extends reconstruction to all nonconstant terms of an unknown Z/CZ/CCZ diagonal unitary and examines practical limitations. Synthetic instances only; no blockchain integration, Qiskit execution or physical QPU. Installation of `qiskit qiskit-aer` failed (no distribution available to this environment). `qiskit_check.py` and `example.qasm` are supplied but not externally verified. No publication or independent review was performed.

## Reproduce

Python 3.13, NumPy (and SciPy for the historical reference code); fixed seeds embedded in scripts. Run without Python `-O` because the experimental code contains assertions.

```
python -m pip install numpy scipy
python run_circuit.py
python crt.py
python soft_noise.py
python compare.py
# Optional externally; not run here:
python -m pip install qiskit qiskit-aer
python qiskit_check.py
```

`circuit_results.json`, `crt_results.json`, `soft_noise_results.json`, `comparison_results.json` and logs contain actual runs. The first CRT run timed out at n=256,d=8; the completed run substitutes d=2. Timing is not a physical runtime comparison. Full learning benchmark uses ideal state vectors and a simulated opaque oracle; learner receives only integer measurements. The simulator has the hidden gate description solely to implement the oracle. In the Qiskit integration example a locally synthesized composite residual oracle is used; replace it with the opaque oracle followed by a known inverse if that is the actual experimental interface.

## Candidate theorem and proof audit

Let f:F2^n→F2 have algebraic degree at most 3. Its cubic coefficients define a simple 3-uniform hypergraph with local degree at most d. Access is to the **repeatable coherent** phase unitary U_f|x>=(-1)^f(x)|x>. It is not merely access to copies of U_f|+>^n. Constant term/global phase is inaccessible under uncontrolled applications. The black-box query model counts every U_f use; arbitrary known gates and classical computation are not free in a physical model.

For directions a,b, the sequence H^n U_f X_a U_f X_b U_f X_a U_f X_b H^n (written in time order) produces |s> up to global phase because the phase polynomial is the second Boolean derivative, affine. Each coefficient s_i=Σ_{j<k}T_ijk(a_j b_k+a_k b_j). This primitive is a direct extension of established derivative/Bernstein–Vazirani techniques, not a claim of novelty.

### Weighted moments (v0.5)
Let K=GF(2^m), m=ceil(log2(n+1)), choose distinct nonzero labels x_j. Let F=K[u]/(u²+u+beta) where absolute trace(beta)=1. Put L_j=u+x_j and z_jk=L_j L_k. Its two coordinates determine s=x_j+x_k and p=x_j x_k, hence the two roots of X²+sX+p and the unordered pair. z is nonzero; s is nonzero for distinct vertices. For link i with at most d edges, define M_i(t)=Σ_{(j,k) in link_i} (x_j+x_k) z_jk^t for t=0,...,2d−1. Each weighted term equals A_j B_k+A_k B_j for A_j=x_j L_j^t and B_j=L_j^t. Decompose multiplication in F over F2 into R(m) products of binary linear forms weighted by constants; each term is obtained for all i using one second derivative probe (4 phase calls). Thus at most 8d R(m) phase calls before cache/zero optimizations. Distinct nonzero nodes z and nonzero weights imply that a sequence of 2d moments uniquely determines the link: if two d-sparse weighted lists differ, their difference has at most 2d nodes and the corresponding Vandermonde system on first moments is injective. Berlekamp–Massey locates nodes; splitting the square-free locator over F by trace pairings is polynomial in d and m. Solve the quadratic over K and check all link consistencies. Direct Karatsuba gives O(d (log n)^log2(3)) queries, with polynomial classical processing for the mathematical construction. Established existence of binary field multiplication rank O(m) gives a query bound O(d log n) given the decomposition. **The current code does not construct uniform asymptotically linear-rank decompositions.** The finite-size CRT alternative is not that construction.

For quadratic residuals with local degree d2, cancel reconstructed cubic terms using known gates, apply a single derivative for a BCH parity-check mask, and decode each neighborhood. This requires O(d2 log n) phase calls (2 per first derivative probe). Finally cancel quadratic terms and use BV once for the linear terms. Total bound with Karatsuba O(d3 (log n)^log2(3)+d2 log n+1), or O((d3+d2) log n+1) when a linear-rank multiplication decomposition is supplied. This extension does not recover constant phase, original gate ordering or redundant pairs of identical gates. No guarantee for non-diagonal gates, higher-degree terms, or unknown continuous phases.

### Lower bound
For n=3m0, d|m0, r=m0/d≥2: choose vertex sets A,B,C each of size m0. Divide A and B into d blocks of r. For each ordered pair of blocks choose an independent perfect matching. For each matched (A_a,B_b) include triple (A_a,B_b,C_a). The resulting degree-d hypergraphs are distinct, M=(r!)^(d²). Classical binary value queries distinguish at most 2^q branches; randomized bounded-error success under uniform input requires 2^q≥(2/3)M, yielding Ω(nd log(n/d)) queries in this family. For quantum phase queries, expand the final state into monomials of degree at most q in the 2^n oracle signs; its span has dimension at most (2^n+1)^q, including coherent identity branches. A POVM discriminates M equiprobable pure states with mean success ≤dim/M; purification handles intermediate measurements. Thus q=Ω(d log(n/d)) for this family. For d≤n^(1−epsilon) and admissible n,d, the upper bound with a supplied linear-rank decomposition matches the lower bound in order. This is a query-complexity statement only. It does not prove practical acceleration, a uniform constructive linear-rank implementation, or originality. The classical lower bound assumes value queries, not direct access to code. For general n,d not satisfying construction conditions no blanket tight bound is claimed.

## Experiments

### Ideal full unitary
17/17 exact (n=4,6,8,10; 5,5,4,3 instances). Full reconstruction requires 31,129,185,185 phase calls respectively; a dense coordinate derivative method needs 19,51,99,163. Classical dense value oracle interpolation uses 15,42,93,176 calls (includes one constant query, which can be omitted if constant known zero). Median primitive gate counts for QCDT 900,9196,20954.5,25102. CCZ independently verified on all eight basis states using seven T/Tdg and ten CNOTs. This simple decomposition is not optimal. Cancellation gates included in simulated primitive counts, but not counted as hidden oracle calls. No routing or hardware durations.

### Gate noise
n=5,d=1; ten synthetic circuits per configuration; independent nonidentity Pauli error on each touched wire after every primitive with probability p and readout flips 0.002. Counts of exact cubic recoveries out of 10, shots 1/5/15: p=0: 10/10/10; p=.001: 7/9/10; p=.005: 0/1/8; p=.01: 0/0/3. Other cases rejected; no wrong accepted in this small experiment, not a guarantee. No correlated drift, relaxation, realistic calibration or device transpilation.

### Soft scoring
For the identical measurement data compare hard majority+algebraic decoder against nearest candidate by raw counts. n=5 or 6, d=1, 11 or 31 possible hypergraphs including empty. Global enumeration not scalable. 450 paired trials. At p=.005, 5 shots: hard 4/50, soft 50/50. At p=.01, 5 shots: hard 0/50, soft 44/50 with 2 incorrect acceptances and 4 ties/rejections. At p=.01, 9 shots: hard 1/50, soft 49/50 with 1 incorrect acceptance. Treat as heuristic, not certified under correlated gate noise. Same 24 phase queries per shot for both.

### CRT rank
Finite-size polynomial CRT over F2 with distinct low-degree irreducibles and optional leading coefficient at infinity. Tested every basis product for m=2..11 (505 checks); bilinearity extends equality to all input pairs. Examples m=5 22→15 products, m=9 62→33, m=11 70→46. m=8 worsens 27→30. Six weighted recovery trials exact using both Karatsuba and CRT on contraction oracle; CRT may need MORE unique probe pairs despite lower rank; n=256,d=2 1072→988 but v0.4 needs 576. Retain adaptive selection by unique probes. This is standard interpolation/CRT technique, no novelty claim; finite set of small moduli does not give asymptotic linear rank.

### Baselines and costs
Dense coordinate schedule for cubic part alone uses 4*C(n−1,2) calls. Planned best QCDT counts for (n,d)=(16,2),(64,2),(256,2): 244,384,576 vs 420,7812,129540. These are plan counts on zero-response probes, not new large state-vector executions or time benchmarks. For degree-one pure cubic functions on n=5,6,7, enumerate all 11,31,106 candidate hypergraphs and choose a value query with maximum split among candidates. Greedy classical exact for all 148 possibilities; worst 4,6,8 calls respectively vs 24 QCDT phase calls. Classical comparator is combinatorial and assumes value oracle, but refutes a small-instance advantage. A fair practical benchmark needs a scalable sparse classical learner, comparable oracle implementation, physical costs and larger instances. If a gate list is known, parity-counting its gate labels is linear-time classical processing: QCDT is meaningful only for an opaque coherent repeatable circuit.

## Related work and novelty boundary
- Montanaro, The quantum query complexity of learning multilinear polynomials (2012), https://arxiv.org/abs/1105.3310 — dense exact learning and derivative principle already known.
- Montanaro & Shao, Quantum algorithms for learning a hidden graph (2022), https://doi.org/10.4230/LIPIcs.TQC.2022.1 — parity graph learning, degree-2 special case and related techniques.
- Arunachalam, Bravyi, Dutt, Yoder, Optimal algorithms for learning quantum phase states (2023), https://doi.org/10.4230/LIPIcs.TQC.2023.3 — explicitly discusses learning Z/CZ/CCZ circuits from copies, sparse monomial learning; different access model, no direct query comparison.
- Ouyang & Tomamichel, Learning quantum graph states with product measurements, https://eprints.whiterose.ac.uk/id/eprint/198734/; De Francesco (12 Nov 2026), https://arxiv.org/abs/2611.16456 — sparse graph states with local Pauli measurements, different input model, degree 2.
- Hypergraph learnability using CUT oracles (2026), https://arxiv.org/abs/2607.01216 — distinct oracle and identifiability.
- Chudnovsky & Chudnovsky (1987), https://pmc.ncbi.nlm.nih.gov/articles/PMC304516/; Ballet (1999), https://doi.org/10.1006/ffta.1999.0255 — linear bilinear complexity in finite fields known.

The specific candidate contribution is shared acquisition of finite-field weighted link moments through coherent directional derivatives, coupled with efficient sparse decoding and a local-degree parameter. Search was focused, not exhaustive; no identical statement found in the examined sources, but this does not prove novelty. Characterization of diagonal circuits, sparse interpolation, BCH, BM, CRT, and BV are established. Do not call QCDT an unprecedented fundamental algorithm or publish claims as established before independent review.

## Publication gate
Ready: precise problem, provisional theorem/proof, runnable Python, gate simulation, reproducibility, negative baselines, manuscript skeleton. Not ready: independent specialist review, exhaustive priority search, true asymptotically linear-rank uniform implementation, executed Qiskit/Aer adapter, physical QPU and calibrated noise, stronger scalable classical comparison, real data or useful blockchain use case. Graph Collision stays secondary: explicit transaction footprints and selections allow O(k) classical incremental update. Do not conflate with quantum advantage. No external execution or publication initiated.
