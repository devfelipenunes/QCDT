import json,random,statistics,itertools as it
from pathlib import Path
import numpy as np
from circuit import *
from previous import random_hypergraph
from round4_reference import contraction
R=random.Random(20261126); N=np.random.default_rng(20261126);BASE=Path(__file__).parent

def edges(n,d):
    es=set();deg=[0]*n;choices=list(it.combinations(range(n),2));R.shuffle(choices)
    for i,j in choices:
        if deg[i]<d and deg[j]<d and R.random()<.7:es.add((i,j));deg[i]+=1;deg[j]+=1
    return es

def classical(n,oracle):
    learned=set();count=0
    for k in range(4):
        for term in it.combinations(range(n),k):
            s=set(term);value=oracle(sum(1<<i for i in term));count+=1
            if value^(sum(set(t)<=s for t in learned)%2):learned.add(term)
    return learned-{()},count

def dense_quantum(n,probe):
    es=set();count=0
    for i,j in it.combinations(range(n-1),2):
        r=probe((1<<i,1<<j),set());count+=4
        for k in range(j+1,n):
            if r>>k&1:es.add((i,j,k))
    qs=set()
    for i in range(n-1):
        r=probe((1<<i,),es);count+=2
        for j in range(i+1,n):
            if r>>j&1:qs.add((i,j))
    r=probe((),es|qs);count+=1
    return es|qs|{(i,) for i in range(n) if r>>i&1},count

def main():
    sim=Simulator(3);g=oracle_gates({(0,1,2)})
    for x in range(8):
        s=np.zeros(8,complex);s[x]=1
        for gate in g:sim.apply(s,gate)
        assert np.allclose(s,np.eye(8)[x]*(-1 if x==7 else 1))
    print('CCZ verified',len(g),flush=True)
    rows=[]
    for n,d3,d2,trials in [(4,1,1,5),(6,2,2,5),(8,2,2,4),(10,2,2,3)]:
        costs=[];dense=[];classical_cost=[];gate_counts=[];sim=Simulator(n)
        for trial in range(trials):
            terms=random_hypergraph(n,d3,R)|edges(n,d2)|{(i,) for i in range(n) if R.random()<.5};og=oracle_gates(terms);ctr=[0]
            def probe(ds,known):
                gates=derivative(n,og+oracle_gates(known),ds);ctr[0]+=len(gates);return sim.run(gates)
            got,q=learn_unitary(n,d3,d2,probe);assert got==terms
            gate_counts.append(ctr[0]);costs.append(q)
            got,q=dense_quantum(n,probe);assert got==terms;dense.append(q)
            got,q=classical(n,lambda x:sum(all(x>>i&1 for i in t) for t in terms)%2);assert got==terms;classical_cost.append(q)
            if n==6 and trial==0:(BASE/'example.qasm').write_text(qasm(n,derivative(n,og,(3,12))))
        row=dict(n=n,d3=d3,d2=d2,trials=trials,exact=trials,phase_calls=costs[0],dense_phase_calls=dense[0],classical_value_calls=classical_cost[0],median_primitive_gates=statistics.median(gate_counts));rows.append(row);print(row,flush=True)
    noise=[];n=5;d=1;sim=Simulator(n)
    instances=[random_hypergraph(n,d,R)|edges(n,1)|{(i,) for i in range(n) if R.random()<.5} for _ in range(10)]
    for p in [0.,.001,.005,.01]:
        for shots in [1,5,15]:
            success=wrong=reject=0;gcounts=[];bits_ok=bits=0
            for terms in instances:
                expected={t for t in terms if len(t)==3};og=oracle_gates(terms);ct=[0]
                def probe(a,b):
                    nonlocal bits_ok,bits
                    gs=derivative(n,og,(a,b));ct[0]+=len(gs)*shots;out=[sim.run(gs,N,p,.002) for _ in range(shots)];v=sum((sum((s>>i)&1 for s in out)>shots//2)<<i for i in range(n));bits_ok+=n-(v^contraction(expected,a,b)).bit_count();bits+=n;return v
                try:
                    rec,q=direct_recover(n,d,probe,compact=True);success+=rec==expected;wrong+=rec!=expected
                except (ValueError,AssertionError,KeyError,ZeroDivisionError,IndexError):reject+=1
                gcounts.append(ct[0])
            row=dict(p_gate_per_wire=p,p_readout=.002,shots=shots,trials=len(instances),exact=success,wrong=wrong,rejected=reject,bit_accuracy=bits_ok/bits,median_primitive_gate_executions=statistics.median(gcounts));noise.append(row);print('noise',row,flush=True)
    (BASE/'circuit_results.json').write_text(json.dumps(dict(full_learning=rows,noise=noise),indent=2))
if __name__=='__main__':main()
