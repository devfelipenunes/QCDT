"""Matching-specific bound and pooled triple vote; synthetic benchmark and proof checks."""
import itertools as it, math, json, time
from pathlib import Path
import numpy as np
from codegree import codegree,p_for,draw,linear,star
from robust import observations,generate
from scale import fast
from certification import dense_obs,verify,holdout_size
from circuit import Simulator,oracle_gates,derivative

def matching_p(d):
 p=np.linspace(.001,.499,499);s=min(d,2)
 bias=(1-2*p)**s*(1-4*p*p)**(d-s)
 i=int(np.argmax(2*p*p*bias*bias))
 return float(p[i]),float(bias[i])

def pooled(A,B,Y,d,l=None):
 M,n=A.shape;u,v=np.triu_indices(n,1);score=np.zeros((n,n,n),np.float32);Y=Y.astype(np.float32)
 for st in range(0,len(u),128):
  j,k=u[st:st+128],v[st:st+128]
  hit=((A[:,j]&B[:,k])|(B[:,j]&A[:,k])).astype(np.float32)
  z=2*(hit.T@Y)-hit.sum(axis=0)[:,None]
  score[:,j,k]=z.T;score[:,k,j]=z.T
 triples=np.array(list(it.combinations(range(n),3)));i,j,k=triples.T
 votes=score[i,j,k]+score[j,i,k]+score[k,i,j]
 if np.any(votes==0):return None
 E=set(map(tuple,triples[votes>0].tolist()));deg=np.bincount([i for e in E for i in e],minlength=n)
 if np.any(deg>d) or (l is not None and codegree(E)>l):return None
 return E

def exact_checks():
 # All simple link graphs on 5 vertices, all 10 queried pairs, all other ternary assignments.
 n=5;ps=list(it.combinations(range(n),2));count=matchcount=0;maxbad=0.;maxdiff=0.
 for bits in range(1,1<<len(ps)):
  E=[e for j,e in enumerate(ps) if bits>>j&1];d=len(E);l=max(sum(v in e for e in E) for v in range(n));p=p_for(d,l)
  for j,k in ps:
   rest=[v for v in range(n) if v not in (j,k)];bad=0;bad2=0;pm,bias=matching_p(d)
   for a in it.product(range(3),repeat=len(rest)):
    z=dict(zip(rest,a));z[j]=1;z[k]=2
    cross=sum({z[u],z[v]}=={1,2} for u,v in E)%2
    err=cross!=int((j,k) in E)
    if err:
     bad+=math.prod(p if x else 1-2*p for x in a);bad2+=math.prod(pm if x else 1-2*pm for x in a)
   assert bad<=.25+1e-12,(E,j,k,bad,p);maxbad=max(maxbad,bad);count+=1
   if l==1:
    R=[e for e in E if e!=(j,k)];s=sum(j in e or k in e for e in R);t=len(R)-s
    expect=(1-(1-2*pm)**s*(1-4*pm*pm)**t)/2
    assert abs(bad2-expect)<1e-12;maxdiff=max(maxdiff,abs(bad2-expect));matchcount+=1
 return dict(general_checks=count,matching_checks=matchcount,max_contamination=maxbad,max_matching_formula_error=maxdiff)

def run():
 rng=np.random.default_rng(2026112511);rows=[]
 for fam,n,d,M,T in [('linear',24,4,3072,20),('linear',32,6,6144,16),('linear',48,8,8192,8),('star',32,6,6144,12),('random',32,4,3072,16)]:
  gen={'linear':linear,'star':star,'random':generate}[fam];Es=[gen(n,d,rng) for _ in range(T)]
  for eta in (0,.15,.25):
   stats={a:[0,0,0] for a in ['old','codegree','matching','pooled_matching','pooled_safe']}
   for E in Es:
    z=rng.random((M,n));flip=rng.random((M,n))<eta;l=max(1,codegree(E));p,bias=matching_p(d)
    for name,p0,decoder,lim in [('old',1/(4*d),fast,None),('codegree',p_for(d,l),fast,None),('matching',p,fast,None),('pooled_matching',p,pooled,1 if fam=='linear' else None),('pooled_safe',p_for(d,l),pooled,l)]:
     A=z<p0;B=(z>=p0)&(z<2*p0);Y=observations(A,B,E,rng)^flip;C=decoder(A,B,Y,d) if decoder==fast else decoder(A,B,Y,d,lim)
     stats[name][2 if C is None else 0 if C==E else 1]+=1
   row=dict(family=fam,n=n,d=d,M=M,eta=eta,trials=T,matching_p=matching_p(d)[0],stats=stats);print(row,flush=True);rows.append(row)
 # Explicit gates: verify outputs independently from algebraic contraction for new densities.
 checks=0
 for n,d in [(5,2),(6,3),(7,3)]:
  sim=Simulator(n)
  for _ in range(8):
   E=generate(n,d,rng);A,B=draw(n,24,p_for(d,max(1,codegree(E))),rng);Y=observations(A,B,E,rng);g=oracle_gates(E|{(0,),(0,1)})
   for a,b,y in zip(A,B,Y):
    mask=lambda x:sum(int(v)<<i for i,v in enumerate(x))
    assert sim.run(derivative(n,g,(mask(a),mask(b))))==mask(y);checks+=1
 result=dict(rows=rows,proof_checks=exact_checks(),gate_checks=checks,stats_order=['exact','wrong','rejected']);Path(__file__).with_name('refinement.json').write_text(json.dumps(result,indent=2));print(result['proof_checks'],checks,flush=True)
if __name__=='__main__':run()
