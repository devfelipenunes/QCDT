"""Conditional voting on disjoint random masks; polynomial decoder."""
import numpy as np, math, json, time
from pathlib import Path

def bound(n,d,eta,delta):
 p=1/(4*d); q=2*p*p; gap=(1-2*eta)/4
 return math.ceil(max(8/q*math.log(2*n**3/delta),math.log(2*n**3/delta)/(q*gap**2)))
def masks(n,d,M,rng):
 p=1/(4*d); z=rng.random((M,n));return z<p,(z>=p)&(z<2*p)
def observations(A,B,edges,rng,eta=0):
 y=np.zeros(A.shape,dtype=bool)
 for i,j,k in edges:
  for a,b,c in [(i,j,k),(j,i,k),(k,i,j)]:y[:,a]^=(A[:,b]&B[:,c])|(B[:,b]&A[:,c])
 if eta:y^=rng.random(y.shape)<eta
 return y

def decode(A,B,Y,d):
 M,n=A.shape;j,k=np.triu_indices(n,1);links=[set() for _ in range(n)];Y=Y.astype(float)
 for st in range(0,len(j),128):
  u,v=j[st:st+128],k[st:st+128];hit=((A[:,u]&B[:,v])|(B[:,u]&A[:,v])).astype(float);cnt=hit.sum(axis=0);votes=hit.T@Y
  if np.any(cnt==0):return None
  for l,(a,b) in enumerate(zip(u,v)):
   for i in range(n):
    if i in (a,b):continue
    if 2*votes[l,i]==cnt[l]:return None
    if 2*votes[l,i]>cnt[l]:links[i].add(tuple(sorted((i,int(a),int(b)))))
 es=set().union(*links)
 if any(len(L)>d for L in links) or any(sum(e in links[i] for i in e)!=3 for e in es):return None
 return es

def generate(n,d,rng):
 E=set();deg=np.zeros(n,int)
 for _ in range(n*d*6):
  e=tuple(sorted(map(int,rng.choice(n,3,replace=False))))
  if e not in E and max(deg[list(e)])<d:E.add(e);deg[list(e)]+=1
 return E

def run():
 rng=np.random.default_rng(260112509);rows=[]
 for n,d,M,trials in [(5,1,256,50),(9,2,1024,30),(16,2,1024,20),(24,3,3072,12),(32,4,6144,8)]:
  eslist=[generate(n,d,rng) if i%7 else set() for i in range(trials)]
  for eta in (0,.05,.15,.25):
   stats=dict(exact=0,wrong=0,rejected=0);timings=[]
   for E in eslist:
    A,B=masks(n,d,M,rng);Y=observations(A,B,E,rng,eta);t=time.perf_counter();R=decode(A,B,Y,d);timings.append(time.perf_counter()-t);stats['rejected' if R is None else 'exact' if R==E else 'wrong']+=1
   row=dict(n=n,d=d,probes=M,phase_calls=4*M,eta=eta,trials=trials,bound_probes=bound(n,d,eta,.01),cpu_median_ms=float(np.median(timings))*1000,**stats);rows.append(row);print(row,flush=True)
 Path(__file__).with_name('robust_results.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':run()
