import numpy as np, random, math, json, time, itertools, collections
from pathlib import Path
R=random.Random(20261125); N=np.random.default_rng(20261125)
def fwht(x):
 x=np.array(x,dtype=complex,copy=True); h=1
 while h<len(x):
  a=x.reshape(-1,2*h); l=a[:,:h].copy(); r=a[:,h:].copy(); a[:,:h]=l+r; a[:,h:]=l-r; h*=2
 return x/np.sqrt(len(x))
class GF:
 def __init__(self,m):
  self.m=m; self.q=1<<m; self.mod=self.q-1; poly={2:7,3:11,4:19,5:37,6:67,7:131,8:285,9:529}[m]; self.exp=[]; v=1
  for _ in range(self.mod):
   self.exp.append(v); v<<=1
   if v&self.q:v^=poly
  assert len(set(self.exp))==self.mod and v==1
  self.log={v:i for i,v in enumerate(self.exp)}; self.exp*=2
 def mul(self,a,b):return self.exp[self.log[a]+self.log[b]] if a and b else 0
 def div(self,a,b):return self.exp[(self.log[a]-self.log[b])%self.mod] if a else 0
 def pow(self,a,t):return self.exp[(self.log[a]*t)%self.mod]
 def decode(self,odd,n,k):
  if not any(odd):return []
  S=[0]*(2*k+1)
  for j in range(1,2*k+1):S[j]=odd[j//2] if j%2 else self.mul(S[j//2],S[j//2])
  seq=S[1:]; C=[1]+[0]*(2*k); B=C.copy(); L=0; shift=1; b=1
  for i,s in enumerate(seq):
   delta=s
   for j in range(1,L+1):delta^=self.mul(C[j],seq[i-j])
   if not delta:shift+=1;continue
   T=C.copy(); coeff=self.div(delta,b)
   for j in range(2*k+1-shift):C[j+shift]^=self.mul(coeff,B[j])
   if 2*L<=i:L=i+1-L;B=T;b=delta;shift=1
   else:shift+=1
  roots=[]
  for j in range(1,n+1):
   inv=self.div(1,j); val=0
   for c in reversed(C[:L+1]):val=self.mul(val,inv)^c
   if val==0:roots.append(j-1)
  assert len(roots)==L<=k
  return roots
def hypergraph(n,d):
 deg=[0]*n; es=set()
 for _ in range(10*n*d):
  pool=[i for i in range(n) if deg[i]<d]
  if len(pool)<3:break
  e=tuple(sorted(R.sample(pool,3)))
  if e not in es:
   es.add(e)
   for i in e:deg[i]+=1
 return es
def contraction(es,a,b):
 out=0
 for e in es:
  for i,j,k in (e,(e[1],e[0],e[2]),(e[2],e[0],e[1])):
   if (((a>>j)&(b>>k))^((a>>k)&(b>>j)))&1:out^=1<<i
 return out
def coded_recover(n,d,probe):
 g=GF(max(2,n.bit_length())); k=2*d; p=k*g.m; masks=[]
 for t in range(1,2*k,2):
  powers=[g.pow(j+1,t) for j in range(n)]
  masks.extend(sum(((v>>bit)&1)<<j for j,v in enumerate(powers)) for bit in range(g.m))
 cache={}; first=[[] for _ in range(n)]
 def query(a,b):
  if not a or not b or a==b:return 0
  key=tuple(sorted((a,b)))
  if key not in cache:cache[key]=probe(*key)
  return cache[key]
 def syndrome(bits):return [sum(v<<j for j,v in enumerate(bits[i:i+g.m])) for i in range(0,p,g.m)]
 for a in masks:
  out=[query(a,b) for b in masks]
  for i in range(n):first[i].append(g.decode(syndrome([(v>>i)&1 for v in out]),n,k))
 es=set()
 for i,lists in enumerate(first):
  for j in set().union(*map(set,lists)):
   for k0 in g.decode(syndrome([int(j in l) for l in lists]),n,k):
    assert len({i,j,k0})==3;es.add(tuple(sorted((i,j,k0))))
 return es,len(cache)*4,p
def exp_hyper():
 rows=[]
 for n,d,reps in [(6,2,12),(9,3,12),(12,3,8),(32,2,6),(128,2,3),(256,2,2)]:
  ts=[];qs=[];total=0
  for _ in range(reps):
   es=hypergraph(n,d);total+=len(es);tt=None
   if n<=12:
    x=np.arange(1<<n);tt=np.zeros(len(x),np.int8)
    for t in list(es)+[(),(0,),(1,2)]:
     mask=sum(1<<i for i in t);tt^=((x&mask)==mask).astype(np.int8)
   def probe(a,b):
    expected=contraction(es,a,b)
    if tt is not None:
     phase=1-2*(tt^tt[x^a]^tt[x^b]^tt[x^a^b]);psi=fwht(phase/np.sqrt(len(tt)));idx=int(np.argmax(np.abs(psi)**2));assert idx==expected and abs(abs(psi[idx])**2-1)<1e-9;return idx
    return expected
   start=time.perf_counter();result,q,p=coded_recover(n,d,probe);ts.append(time.perf_counter()-start);qs.append(q);assert result==es
  rows.append(dict(n=n,d=d,cases=reps,exact=reps,mean_edges=total/reps,queries=qs[0],dense_queries=4*math.comb(n,2),masks=p,mode='statevector' if n<=12 else 'analytic contraction',median_seconds=round(float(np.median(ts)),4)))
  print('Q02',rows[-1],flush=True)
 return rows
def exp_diff():
 rows=[];n=12;xs=np.arange(1<<n);size=len(xs)
 for k in [2,4,6,8,10]:
  plain_ok=amp_ok=class_ok=witness_ok=0;trials=80;shots=math.ceil(math.log2(k/.05));p=2**(-k);theta=math.asin(math.sqrt(p));it=max(0,round(math.pi/(4*theta)-.5));budget=shots*(it+1)*2
  for _ in range(trials):
   support=R.sample(range(n),k);sm=sum(1<<i for i in support);target=sum((R.randrange(2)<<i) for i in support);h=(xs&sm)==target;psi=np.ones(size)/np.sqrt(size)
   for __ in range(it):psi[h]*=-1;psi=2*psi.mean()-psi
   good=psi*h;success=float(good@good);conditional=np.abs(fwht(good))**2/success;plain=np.abs(fwht((1-2*h.astype(float))/np.sqrt(size)))**2
   def union(samples):
    out=0
    for j in samples:out|=int(j)
    return out
   plain_ok+=union(N.choice(size,budget//2,p=plain/plain.sum()))==sm
   outcomes=[N.choice(size,p=conditional/conditional.sum()) for __ in range(shots) if R.random()<success];amp_ok+=union(outcomes)==sm
   samples=N.integers(0,size,max(0,budget//2-n));class_ok+=bool(h[samples].any())
   if budget>=2*(it+1+n):witness_ok+=R.random()<success
  rows.append(dict(k=k,prevalence=p,trials=trials,budget_original_oracles=budget,grover_iterations=it,shots=shots,plain=plain_ok,amplified=amp_ok,classical_random_witness=class_ok,grover_witness_then_flip=witness_ok,grover_witness_cost=2*(it+1+n)))
 print('B08',rows,flush=True);return rows
def quorum(q,ss):return bool(q) and all(any(s&q==s for s in ss[i]) for i in range(len(ss)) if q>>i&1)
def greatest(allowed,ss):
 while allowed:
  old=allowed
  for i in range(len(ss)):
   if allowed>>i&1 and not any(s&allowed==s for s in ss[i]):allowed^=1<<i
  if old==allowed:break
 return allowed
def exp_quorum():
 rows=[]
 for n in [6,8,10,12]:
  reps=50;allm=(1<<n)-1;hits=0
  for _ in range(reps):
   ss=[[1|1<<i|sum(1<<j for j in R.sample(range(n),R.randrange(0,min(3,n)+1))) for __ in range(2)] for i in range(n)];assert all(not quorum(q,ss) or q&1 for q in range(1,1<<n));v=R.randrange(n);ss[v].append(1<<v)
   brute=any(quorum(q,ss) and greatest(allm^q,ss) for q in range(1,1<<n));inc=any(quorum(q,ss) and greatest(allm^q,ss) for q in range(1,1<<n) if q>>v&1);assert brute==inc;hits+=inc
  rows.append(dict(n=n,cases=reps,agreement=reps,unsafe=hits,safe=reps-hits,full_candidates=(1<<n)-1,restricted_candidates=1<<(n-1)))
 print('B01',rows,flush=True);return rows
def gate(state,kind,a,b=None):
 out=state.copy();ids=np.arange(len(state));zero=ids[(ids>>a&1)==0];one=zero|(1<<a)
 if kind=='H':out[zero]=(state[zero]+state[one])/np.sqrt(2);out[one]=(state[zero]-state[one])/np.sqrt(2)
 elif kind=='S':out[one]*=1j
 elif kind=='Z':out[one]*=-1
 elif kind=='X':out=state[ids^(1<<a)]
 elif kind=='CX':out=state[ids^(((ids>>a)&1)<<b)]
 return out
def exp_diag():
 rows=[]
 for n,L in [(3,16),(4,32),(5,64)]:
  reps=20;total=0;collisions=[]
  for _ in range(reps):
   init=np.zeros(1<<(2*n),complex);init[[x|(x<<n) for x in range(1<<n)]]=1/np.sqrt(1<<n);circ=[]
   for __ in range(L):a,b=R.sample(range(n),2);circ.append((R.choice(['H','S','CX']),a,b))
   clean=[init]
   for g in circ:clean.append(gate(clean[-1],*g))
   def faulty(loc,pauli,wire,end):
    state=gate(clean[loc+1],pauli,wire)
    for g in circ[loc+1:end]:state=gate(state,*g)
    return state
   loc=R.randrange(L);pauli=R.choice(['X','Z']);wire=circ[loc][1]
   def detect(end):return end>loc and abs(np.vdot(clean[end],faulty(loc,pauli,wire,end)))**2<.5
   assert detect(L);lo=0;hi=L;calls=1
   while hi-lo>1:
    mid=(lo+hi)//2;calls+=1
    if detect(mid):hi=mid
    else:lo=mid
   assert hi-1==loc;total+=calls;keys=set()
   for j in range(L):
    for p in ['X','Z']:
     z=faulty(j,p,circ[j][1],L);m=np.flatnonzero(np.abs(z)>1e-8)[0];z=z*np.exp(-1j*np.angle(z[m]));keys.add(tuple(np.round(z.real,8)+1j*np.round(z.imag,8)))
   collisions.append(len(keys))
  rows.append(dict(n=n,gates=L,cases=reps,correct=reps,mean_prefix_tests=total/reps,mean_linear_tests=(L+1)/2,mean_distinct_endpoint_signatures=float(np.mean(collisions)),candidate_faults=2*L))
 print('Q04',rows,flush=True);return rows
def exp_collision():
 rows=[]
 for n,k,numkeys in [(32,2,8),(64,3,16),(128,4,16),(256,4,16)]:
  reps=100;ec=[];sizes=[]
  for _ in range(reps):
   footprint=[];groups=collections.defaultdict(list)
   for i in range(n):
    f={j:R.random()<.5 for j in R.sample(range(numkeys),k)};footprint.append(f)
    for j,w in f.items():groups[j].append((i,w))
   edges=[(i,j) for i in range(n) for j in range(i+1,n) if any(footprint[i][a] or footprint[j][a] for a in footprint[i].keys()&footprint[j].keys())];p=R.choice([.02,.1,.3]);chosen=[R.random()<p for i in range(n)]
   direct=any(chosen[i] and chosen[j] for i,j in edges);grouped=any(sum(chosen[i] for i,w in vs)>=2 and any(w and chosen[i] for i,w in vs) for vs in groups.values());assert direct==grouped;ec.append(len(edges));sizes.append(sum(len(v) for v in groups.values()))
  rows.append(dict(n=n,k=k,cases=reps,agreement=reps,mean_edges=round(float(np.mean(ec)),2),incidences=int(np.mean(sizes)),edge_sqrt_proxy=round(float(np.sqrt(np.mean(ec))),2),formula_sqrt_proxy=round(float(np.sqrt(np.mean(sizes))),2)))
 print('Q01',rows,flush=True);return rows
if __name__=='__main__':
 result={}
 for name,fun in [('Q02',exp_hyper),('B08',exp_diff),('B01',exp_quorum),('Q04',exp_diag),('Q01',exp_collision)]:
  result[name]=fun();Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2))
