"""Noisy holdout certificate under a known independent symmetric bit-flip channel."""
import math,json,itertools as it
from pathlib import Path
import numpy as np
from robust import masks,observations,decode,bound,generate

def dense_obs(A,B,edges):
 Y=np.zeros(A.shape,dtype=bool)
 for e in edges:
  for i,j,k in [(e[0],e[1],e[2]),(e[1],e[0],e[2]),(e[2],e[0],e[1])]:Y[:,i]^=(A[:,j]&B[:,k])^(A[:,k]&B[:,j])
 return Y

def holdout_size(n,eta,delta):
 gap=3*(1-2*eta)/16
 return math.ceil(math.log(n/delta)/(2*gap**2))

def verify(candidate,A,B,observed,eta):
 return bool(np.all((observed^dense_obs(A,B,candidate)).mean(axis=0)<=eta+3*(1-2*eta)/16))

def main():
 rng=np.random.default_rng(719032);rows=[];boundrows=[]
 for n,d in [(5,1),(9,2),(16,2),(32,4)]:
  for eta in (.05,.15,.25):
   M=holdout_size(n,eta,.01);valid=bad=0;trials=100
   for k in range(trials):
    E=generate(n,d,rng) if k%7 else set();A=rng.random((M,n))<.5;B=rng.random((M,n))<.5;Y=dense_obs(A,B,E)^(rng.random((M,n))<eta);valid+=verify(E,A,B,Y,eta)
    e=tuple(sorted(map(int,rng.choice(n,3,replace=False))));C=E^{e};bad+=verify(C,A,B,Y,eta)
   row=dict(n=n,d=d,eta=eta,probes=M,calls=4*M,correct_accepted=valid,wrong_accepted=bad,trials=trials);rows.append(row);print(row,flush=True)
 for n,d in [(5,1),(9,2),(16,2)]:
  for eta in (.15,.25):
   M=bound(n,d,eta,.01);count=wrong=0
   for k in range(12):
    E=generate(n,d,rng) if k%4 else set();A,B=masks(n,d,M,rng);Y=observations(A,B,E,rng,eta);C=decode(A,B,Y,d);count+=C==E;wrong+=C is not None and C!=E
   row=dict(n=n,d=d,eta=eta,probes=M,exact=count,wrong=wrong,trials=12);boundrows.append(row);print('bound',row,flush=True)
 Path(__file__).with_name('certification_results.json').write_text(json.dumps(dict(rows=rows,at_bound=boundrows),indent=2))
if __name__=='__main__':main()
