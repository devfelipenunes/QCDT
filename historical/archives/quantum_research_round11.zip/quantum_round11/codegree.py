"""Codegree-aware conditional voting. Reproducible algebraic oracle simulations."""
import numpy as np, math, itertools as it, json, time
from pathlib import Path
from robust import observations,generate
from scale import fast

def codegree(E):
 counts={}
 for e in E:
  for pair in it.combinations(e,2): counts[pair]=counts.get(pair,0)+1
 return max(counts.values(),default=0)

def p_for(d,l):
 s=min(d,2*l);t=d-s
 return .5/(s+math.sqrt(s*s+2*t)) if t else .25/s

def draw(n,M,p,rng):
 z=rng.random((M,n));return z<p,(z>=p)&(z<2*p)
def bound(n,d,l,eta,delta):
 p=p_for(d,l);q=2*p*p;g=(1-2*eta)/4
 return math.ceil(max(8/q,1/(q*g*g))*math.log(2*n**3/delta))

def linear(n,d,rng):
 E=set();pairs=set();degrees=np.zeros(n,int)
 for _ in range(n*d*20):
  e=tuple(sorted(map(int,rng.choice(n,3,replace=False))));ps=set(it.combinations(e,2))
  if max(degrees[list(e)])<d and not (ps&pairs):
   E.add(e);pairs|=ps;degrees[list(e)]+=1
  if min(degrees)>=d:break
 return E

def star(n,d,rng):
 v=rng.permutation(n);return {tuple(sorted(map(int,(v[st],v[st+1],v[j])))) for st in range(0,n-d-1,d+2) for j in range(st+2,st+d+2)}

def trial():
 rng=np.random.default_rng(2026112510);rows=[]
 for family,n,d,M,T in [('linear',24,4,1024,24),('linear',32,6,2048,20),('linear',48,8,4096,12),('star',32,6,2048,20),('random',32,4,2048,20)]:
  gen={'linear':linear,'star':star,'random':generate}[family];Es=[gen(n,d,rng) for _ in range(T)]
  for eta in (0,.15,.25):
   stats={a:{'exact':0,'reject':0,'wrong':0,'seconds':[]} for a in ['old','aware','assume_linear']}
   for E in Es:
    l=max(1,codegree(E)); z=rng.random((M,n));flip=rng.random((M,n))<eta
    for name,p in [('old',1/(4*d)),('aware',p_for(d,l)),('assume_linear',p_for(d,1))]:
     A=z<p;B=(z>=p)&(z<2*p);Y=observations(A,B,E,rng)^flip;t=time.perf_counter();C=fast(A,B,Y,d);stats[name]['seconds'].append(time.perf_counter()-t);stats[name]['reject' if C is None else 'exact' if C==E else 'wrong']+=1
   for a,v in stats.items():v['median_cpu_s']=float(np.median(v.pop('seconds')))
   row=dict(family=family,n=n,d=d,M=M,calls=4*M,trials=T,eta=eta,codegrees=[codegree(e) for e in Es],edges=[len(e) for e in Es],stats=stats);rows.append(row);print(row,flush=True)
 Path(__file__).with_name('benchmark.json').write_text(json.dumps(rows,indent=2))

if __name__=='__main__':trial()
