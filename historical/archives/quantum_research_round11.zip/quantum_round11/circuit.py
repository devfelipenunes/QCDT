import numpy as np
from previous import direct_recover, CompactField, masks

def oracle_gates(terms):
    g=[]
    for t in sorted(terms):
        if len(t)==1:g.append(('Z',*t))
        elif len(t)==2:g.append(('CZ',*t))
        elif len(t)==3:
            a,b,c=t;g.extend(('T',q) for q in t)
            for i,j in ((a,b),(a,c),(b,c)):g.extend([('CX',i,j),('TDG',j),('CX',i,j)])
            g.extend([('CX',a,c),('CX',b,c),('T',c),('CX',b,c),('CX',a,c)])
        else:raise ValueError('degree must be 1–3')
    return g

def shifts(n,ds):
    r=len(ds)
    for k in range(1<<r):
        if not r:yield [];continue
        j=k^(k>>1);l=(k+1)%(1<<r);l^=l>>1
        a=ds[(j^l).bit_length()-1];yield [('X',i) for i in range(n) if a>>i&1]

def derivative(n,oracle,ds):
    h=[('H',i) for i in range(n)];g=list(h)
    for x in shifts(n,ds):g+=oracle+x
    return g+h

class Simulator:
    def __init__(self,n):
        self.n=n;self.ids=np.arange(1<<n);self.one=[self.ids[(self.ids>>i&1)==1] for i in range(n)];self.zero=[v^(1<<i) for i,v in enumerate(self.one)];self.perm={}
    def apply(self,s,g):
        k,*q=g;a=q[0];one=self.one[a];zero=self.zero[a]
        if k=='H':x=s[zero].copy();y=s[one].copy();s[zero]=(x+y)/np.sqrt(2);s[one]=(x-y)/np.sqrt(2)
        elif k=='X':s[:]=s[self.ids^(1<<a)]
        elif k=='Y':s[:]=s[self.ids^(1<<a)];s[zero]*=-1j;s[one]*=1j
        elif k=='Z':s[one]*=-1
        elif k=='T':s[one]*=np.exp(1j*np.pi/4)
        elif k=='TDG':s[one]*=np.exp(-1j*np.pi/4)
        elif k=='CX':
            if g not in self.perm:self.perm[g]=self.ids^(((self.ids>>a)&1)<<q[1])
            s[:]=s[self.perm[g]]
        elif k=='CZ':s[one[(one>>q[1]&1)==1]]*=-1
        else:raise ValueError(k)
    def run(self,gates,rng=None,p=0.,readout=0.):
        s=np.zeros(len(self.ids),complex);s[0]=1
        for g in gates:
            self.apply(s,g)
            if p:
                for q in g[1:]:
                    if rng.random()<p:self.apply(s,(rng.choice(('X','Y','Z')),q))
        probs=abs(s)**2;probs/=probs.sum()
        if rng is None:
            result=int(np.argmax(probs));assert probs[result]>1-1e-10;return result
        result=int(rng.choice(len(probs),p=probs))
        for q in range(self.n):
            if readout and rng.random()<readout:result^=1<<q
        return result

def qasm(n,gates):
    lines=['OPENQASM 2.0;','include "qelib1.inc";',f'qreg q[{n}];',f'creg c[{n}];']
    lines.extend(k.lower()+' '+','.join(f'q[{i}]' for i in qs)+';' for k,*qs in gates)
    return '\n'.join(lines+['measure q -> c;'])+'\n'

def qiskit_probe(oracle,ds,backend,shots=1):
    from qiskit import QuantumCircuit, transpile
    n=oracle.num_qubits;qc=QuantumCircuit(n,n);qc.h(range(n));g=oracle.to_gate() if isinstance(oracle,QuantumCircuit) else oracle
    for xs in shifts(n,ds):
        qc.append(g,list(range(n)))
        for _,i in xs:qc.x(i)
    qc.h(range(n));qc.measure(range(n),range(n));counts=backend.run(transpile(qc,backend),shots=shots).result().get_counts()
    return sum((sum(v for key,v in counts.items() if int(key.replace(' ',''),2)>>i&1)>shots//2)<<i for i in range(n))

def learn_quadratic(n,d,probe):
    g=CompactField(max(2,n.bit_length()));out=[[] for _ in range(n)];cache={}
    for t in range(1,2*d,2):
        z=[0]*n
        for j,a in enumerate(masks([g.pow(i+1,t) for i in range(n)],g.m)):
            if a and a not in cache:cache[a]=probe(a)
            v=cache.get(a,0)
            for i in range(n):z[i]|=((v>>i)&1)<<j
        for i in range(n):out[i].append(z[i])
    links=[]
    for i,synd in enumerate(out):
        link=set(g.decode(synd,n,d));assert i not in link;links.append(link)
    assert all(i in links[j] for i,L in enumerate(links) for j in L)
    return {(i,j) for i,L in enumerate(links) for j in L if i<j},2*len(cache)

def learn_unitary(n,d3,d2,probe):
    cubic,q3=direct_recover(n,d3,lambda a,b:probe((a,b),set()),compact=True)
    quadratic,q2=learn_quadratic(n,d2,lambda a:probe((a,),cubic))
    lin=probe((),cubic|quadratic)
    return cubic|quadratic|{(i,) for i in range(n) if lin>>i&1},q3+q2+1
