"""Two-stage sparse cubic-phase reconstruction, independent BSC output noise."""
import numpy as np, math, itertools as it, time, json, tracemalloc
from pathlib import Path
from robust import observations, generate
from codegree import p_for, draw, linear, star
from refinement import pooled

def contraction(A,B,E):
    Y=np.zeros(A.shape,dtype=bool)
    for i,j,k in E:
        for x,y,z in ((i,j,k),(j,i,k),(k,i,j)):
            Y[:,x]^=(A[:,y]&B[:,z])^(A[:,z]&B[:,y])
    return Y

def shadow(E,n):
    N=[set() for _ in range(n)]
    for e in E:
        for i,j in it.combinations(e,2):N[i].add(j);N[j].add(i)
    return N

def shadow_probe(n,d,M,E,eta,rng):
    B=rng.random((M,n))<1/(8*d);A=rng.integers(0,2,(M,n),dtype=np.int8).astype(bool)
    return B,contraction(A,B,E)^(rng.random((M,n))<eta)

def infer_shadow(B,Y,d,eta):
    n=B.shape[1];N=[set() for _ in range(n)];Y=Y.astype(np.float32);tau=eta+(1-2*eta)/4
    for lo in range(0,n,32):
        b=B[:,lo:lo+32].astype(np.float32);counts=b.sum(0);v=b.T@Y
        if np.any(counts==0):return None
        for j,i in zip(*np.nonzero(v>counts[:,None]*tau)):
            if i!=lo+j:N[i].add(int(lo+j))
    if any(len(s)>2*d for s in N) or any(i not in N[j] for i,s in enumerate(N) for j in s):return None
    return N

def triangles(N):
    return [(i,j,k) for i,s in enumerate(N) for j in sorted(s) if j>i for k in sorted(s&N[j]) if k>j]

def decode_candidates(A,B,Y,N,d,lam):
    C=triangles(N);out=set();counts=[0]*len(N);pcounts={}
    for lo in range(0,len(C),64):
        T=np.asarray(C[lo:lo+64]);score=np.zeros(len(T),np.int64)
        for a,b,c in ((0,1,2),(1,0,2),(2,0,1)):
            i,j,k=T[:,a],T[:,b],T[:,c];hit=(A[:,j]&B[:,k])|(A[:,k]&B[:,j]);score+=np.sum(hit & Y[:,i],0,dtype=np.int64)*2-hit.sum(0,dtype=np.int64)
        if np.any(score==0):return None
        for e in T[score>0]:
            e=tuple(map(int,e));out.add(e)
            for i in e:counts[i]+=1
            for p in it.combinations(e,2):pcounts[p]=pcounts.get(p,0)+1
    if max(counts,default=0)>d or max(pcounts.values(),default=0)>lam or shadow(out,len(N))!=N:return None
    return out

def measure(f,*args):
    tracemalloc.start();t=time.perf_counter();r=f(*args);dt=time.perf_counter()-t;_,peak=tracemalloc.get_traced_memory();tracemalloc.stop();return r,dt,peak

def exhaustive():
    n=5;ps=list(it.combinations(range(n),2));checks=0;min_true=1.;max_false=0.
    for bits in range(1,1<<len(ps)):
        E=[e for j,e in enumerate(ps) if bits>>j&1];d=len(E);p=1/(8*d)
        for j in range(n):
            rest=[k for k in range(n) if k!=j];prob=0.
            for z in it.product((0,1),repeat=n-1):
                b=dict(zip(rest,z));b[j]=1;v=[0]*n
                for u,w in E:v[u]^=b[w];v[w]^=b[u]
                if any(v):prob+=.5*math.prod(p if x else 1-p for x in z)
            if any(j in e for e in E):assert prob>=.375-1e-12;min_true=min(min_true,prob)
            else:assert prob<=.125+1e-12;max_false=max(max_false,prob)
            checks+=1
    return dict(checks=checks,min_true=min_true,max_false=max_false)

def run():
    rng=np.random.default_rng(2026112512);rows=[]
    for fam,n,d,T in [('linear',24,4,6),('star',32,6,4),('random',48,4,4),('linear',64,4,3),('random',128,2,3),('linear',256,2,2),('random',512,1,2)]:
        es=[{'linear':linear,'star':star,'random':generate}[fam](n,d,rng) for _ in range(T)]
        for eta in (0,.15,.25):
            M1=math.ceil(384*d*math.log2(n)/(1-2*eta)**2);M2=math.ceil(384*(d+min(d,2)**2)*math.log2(n)/(1-2*eta)**2)
            lam=1 if fam=='linear' else d
            if fam=='star':M2*=2
            results=[]
            for E in es:
                B,Y=shadow_probe(n,d,M1,E,eta,rng);N,t1,m1=measure(infer_shadow,B,Y,d,eta);del B,Y
                A,B=draw(n,M2,p_for(d,lam),rng);Y=observations(A,B,E,rng,eta)
                R,t2,m2=measure(decode_candidates,A,B,Y,N,d,lam) if N is not None else (None,0,0)
                full,tf,mf=measure(pooled,A,B,Y,d,lam) if n<=64 else (None,None,None)
                results.append(dict(shadow_exact=N==shadow(E,n),exact=R==E,wrong=R is not None and R!=E,full_exact=full==E if tf is not None else None,full_wrong=full is not None and full!=E,triangles=len(triangles(N)) if N is not None else None,possible=math.comb(n,3),sparse_cpu=t1+t2,sparse_peak=max(m1,m2),full_cpu=tf,full_peak=mf,edges=len(E)))
            row=dict(family=fam,n=n,d=d,lambda_bound=lam,eta=eta,trials=T,M_shadow=M1,M_triples=M2,phase_calls=4*(M1+M2),results=results);rows.append(row)
            print(fam,n,d,eta,M1,M2,'shadow',sum(r['shadow_exact'] for r in results),'exact',sum(r['exact'] for r in results),'full',sum(r['full_exact'] or 0 for r in results),'triangles',np.median([r['triangles'] or 0 for r in results]),flush=True)
            Path(__file__).with_name('results.json').write_text(json.dumps(dict(rows=rows),indent=2))
    proof=exhaustive();print(proof,flush=True);Path(__file__).with_name('results.json').write_text(json.dumps(dict(rows=rows,proof=proof),indent=2))
if __name__=='__main__':run()
