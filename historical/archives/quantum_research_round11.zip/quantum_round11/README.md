# QCDT — rodada 11: recuperação por projeção e poda de candidatos

Pesquisa experimental, não certificação de originalidade. Data: 25/11/2026 (Brasília). Modelo: oráculo coerente de fase (-1)^f(x), f booleana de grau <=3. Recuperamos apenas termos cúbicos. Saída de cada dupla derivada/Bernstein–Vazirani é um vetor de n bits, quatro chamadas lógicas de fase. Hipergrafo E, grau local máximo d>=1, codegree lambda>=1. Ruído BSC com taxa eta conhecida, independente entre sondagens, eta<1/2. Não é modelo de ruído de portas em hardware.

## 1. Proposição candidata: aquisição da projeção de pares

Para cada i, L_i é a matriz de adjacência alternante do link de i, e a sonda retorna s_i=a^T L_i b sobre F2. Escolher a uniforme, b com bits Bernoulli(p=1/(8d)), independentes. O conjunto S_i de colunas não nulas tem no máximo 2d elementos. Condicionar b_j=1. Se j pertence a S_i, o evento todos os outros elementos de S_i zerados tem probabilidade >=1-(2d-1)p>=3/4; nele L_i b=L_i e_j !=0, de modo que s_i=1 com probabilidade 1/2 sobre a. Logo P(s_i=1|b_j=1)>=3/8. Se j não pertence a S_i, L_i b só pode ser não nulo quando ao menos um elemento de S_i foi selecionado, probabilidade <=2dp<=1/4. Assim P(s_i=1|b_j=1)<=1/8. Com BSC a probabilidade observada é eta+(1-2eta)P(s_i=1|b_j=1). Usar limiar tau=eta+(1-2eta)/4, gap g=(1-2eta)/8. Para M sondagens independentes, contagem condicionada N~Binomial(M,p); Chernoff dá P(N<Mp/2)<=exp(-Mp/8). Hoeffding condicionado dá erro <=exp(-Mp*g²) se N>=Mp/2. União sobre n² pares ordenados: basta M>=max(8/p,1/(p*g²))*ln(2n²/delta_1), arredondado para cima. Logo O(d log(n/delta_1)/(1-2eta)^2) consultas. Simetria e grau <=2d verificados; inconsistência rejeitada. Limite teórico conservador; orçamentos empíricos menores não garantem delta_1.

## 2. Recuperação restrita a triângulos

A projeção G liga i,j se existe k com {i,j,k} em E. Todo termo cúbico gera triângulo de G; o inverso não é necessariamente verdadeiro. Como deg(G)<=2d, há no máximo n*binom(2d,2)/3=O(nd²) triângulos. Listar triângulos por interseção de listas de vizinhos e aplicar votação combinada da v0.8 só aos candidatos, com novas sondagens e o limite da rodada 10. Se a projeção estiver correta, todo termo verdadeiro está entre candidatos. Distribuir delta=delta_1+delta_2. Complexidade de consultas permanece O((d+lambda²) log(n/delta)/(1-2eta)^2). Para shadow.py, tempo clássico O(M1 n²+M2 nd²+nd²) e memória O(n*max(M1,M2)+nd²), com blocos de tamanho fixo; não há tensor denso n³. Modelo de operações RAM, não custo de QPU. A estimativa de memória do benchmark mede alocações rastreadas por tracemalloc durante decodificação, exclui buffers de entrada, geração de máscaras e memória nativa não rastreada; não é pico RSS.

## 3. Propagação e certificação

Um par presente em exatamente um triângulo ainda admissível obriga esse triângulo, se a projeção estiver correta. Se os triângulos já obrigatórios saturam o grau de um vértice ou o codegree de um par, remover outros candidatos incidentes. Invariante por indução: F subset E subset F union U. Se U vazio, resultado único sem etapa 2. Caso contrário cancelar a contração de F e votar apenas sobre U; a estrutura residual mantém os limites d,lambda. Implementação iterativa ingênua pode usar O((nd²)^2) operações adicionais no pior caso; não reivindicamos tempo quase linear. Contraexemplo Pasch: E1={(0,1,2),(0,3,4),(1,3,5),(2,4,5)}, E2={(0,1,3),(0,2,4),(1,2,5),(3,4,5)}. Projeção, d=2 e lambda=1 iguais. Oito candidatos permanecem; segunda etapa necessária. A garantia de poda depende de projeção exata e promessas válidas.

Holdout independente conforme rodada 9: candidato incorreto difere em algum link alternante não nulo; sob máscaras a,b uniformes, discrepância ideal >=3/8 para aquele bit. Com BSC, taxa de desacordo correta eta, incorreta >=eta+3(1-2eta)/8. Limiar no meio; g'=3(1-2eta)/16; M3>=ln(n/delta_3)/(2g'^2). Falsa rejeição <=delta_3, falsa aceitação <=delta_3/n. A taxa delta_3=.01 usada nos testes não implica que os orçamentos empíricos das etapas 1 e 2 garantam a mesma probabilidade de recuperação. Verificação não protege contra ruído adversarial dependente da máscara.

## 4. Experimentos executados

Sementes 2026112512, 2026112513, 2026112514. Instâncias sintéticas, mesmas instâncias-base reutilizadas entre taxas em shadow.py, resultados não independentes. Sem pré-registro; resultados exploratórios.

- shadow.py: 72 observações (24 instâncias-base x 3 taxas); 72 projeções corretas e reconstruções corretas, zero erros aceitos. 5.115 verificações exaustivas de probabilidade condicionada (1023 links não vazios de cinco vértices x 5 vértices). Menor probabilidade verdadeira .45736885; maior falsa .1171875. Contração algébrica, não statevector de centenas de qubits.
- n=64,d=4,eta=.25: 3/3; mediana 118 triângulos vs 41.664 possíveis; decodificação em duas etapas ~0,144 s, pico incremental rastreado ~23,60 MB; v0.8 pooled com as mesmas sondagens da segunda etapa ~0,873 s e 104,92 MB. Comparação NÃO tem orçamento total igual: novo 442.368 chamadas vs antigo 294.912. CPU inclui decodificação da projeção + candidatos, não aquisição; amostra pequena.
- n=512,d=1,eta=.25: 2/2, mediana 142 candidatos vs 22.238.720 triplas, 165.888 chamadas, ~0,252 s e ~32,04 MB incrementais. Não executada v0.8 densa neste tamanho; não simulação de 512 qubits.
- pruning.py: 1024/1024 hipergrafos n=5, com sombra exata e grau/codegree verdadeiros fornecidos, invariante confirmado; 141 resolvidos apenas por propagação. 270 observações novas (90 por nível de ruído, eta=0,.15,.25), todas corretas, zero errados aceitos; 210 dispensaram etapa 2, 60 Pasch precisaram. Os 60 Pasch são repetições de duas estruturas com máscaras novas; não 60 hipergrafos distintos. Todos com holdout. Em n=64,d=2,eta=.25, 16/16, 75.724 chamadas com holdout. Em n=128,d=4 linear, eta=.25: 12/12, 174.188 chamadas, etapa 2 omitida.
- audit.py: 192/192 sondagens de máscaras sobrepostas conferidas por simulador explícito de portas H,X,Z,CZ,CNOT,T,T†, n=4,5,6, termos lineares e quadráticos adicionais. 54 comparações novas com mesmo número total de chamadas, eta=.25: nova variante 53/54, uma rejeição; v0.8 pooled 54/54, sem holdout, orçamento todo para votação. Sem vantagem de acerto demonstrada; não comparação com algoritmos de literatura. Sem estimativas de significância inferencial para a amostra pequena.

## 5. Literatura e originalidade

- Montanaro (2012), The quantum query complexity of learning multilinear polynomials: https://arxiv.org/abs/1105.3310. Derivadas e BV conhecidos.
- Montanaro/Shao (2022), Quantum Algorithms for Learning a Hidden Graph: https://doi.org/10.4230/LIPIcs.TQC.2022.1. Grafos, oráculos OR e paridade.
- From Graphs to Hypergraphs (ICLR 2024): https://proceedings.iclr.cc/paper_files/paper/2024/hash/e92b8441b702d142435f243806f9ec5a-Abstract-Conference.html. Projeção não injetiva, reconstrução com informação adicional.
- Bresler et al. (COLT 2024/2025): https://proceedings.mlr.press/v247/bresler24a.html e https://proceedings.mlr.press/v291/bresler25a.html. Limiares de recuperação em hipergrafos aleatórios por projeções.
- Query Complexity of Hypergraph Connectivity and Learnability using CUT Oracles (2026): https://arxiv.org/abs/2607.01216. Barreira de identificabilidade em modelo CUT diferente.
- Hypergraph reconstruction from uncertain pairwise observations (2023): https://www.nature.com/articles/s41598-023-48081-w.

Projeção e ambiguidade são conhecidas. Contribuição candidata mais específica: obter projeção por dupla derivada coerente e resolver ambiguidades com sondagens adicionais sob BSC. Não houve revisão sistemática nem comparação executada com implementações publicadas. Nenhuma alegação de ineditismo comprovado, vantagem física ou robustez a ruído arbitrário. Qiskit e Aer ausentes; hardware não executado. Não reexecutada suíte histórica nem testes blockchain. Multiplicação de posto linear v0.5 ainda pendente e não necessária para v0.8/v0.9. Prioridade futura: reduzir constantes/orçamento de consultas, revisão independente, avaliação de hardware e concorrentes do mesmo modelo. Código experimental.

## Reprodução

```bash
pip install -r requirements.txt
OPENBLAS_NUM_THREADS=2 python shadow.py
OPENBLAS_NUM_THREADS=2 python pruning.py
OPENBLAS_NUM_THREADS=2 python audit.py
```

Resultados em results.json, pruning.json e audit.json; logs de execução incluídos. Requisitos e versões do ambiente em requirements.txt e environment.json. Scripts auxiliares da rodada anterior incluídos para reprodução, não todos reexecutados.
