"""Sound propagation given exact pair shadow, and independent BSC holdout."""
from shadow import *
from certification import holdout_size, verify
from collections import Counter

def propagate(N,d,lam):
    possible=set(triangles(N));forced=set();pairs={(i,j) for i,S in enumerate(N) for j in S if i<j}
    while True:
        old=(len(possible),len(forced));degree=Counter(i for e in forced for i in e);cd=Counter(p for e in forced for p in it.combinations(e,2))
        if any(v>d for v in degree.values()) or any(v>lam for v in cd.values()):return None
        possible={e for e in possible if e in forced or (all(degree[i]<d for i in e) and all(cd[p]<lam for p in it.combinations(e,2)))}
        cover={p:[] for p in pairs}
        for e in possible:
            for p in it.combinations(e,2):cover[p].append(e)
        if any(not c for c in cover.values()):return None
        forced|={c[0] for c in cover.values() if len(c)==1}
        if old==(len(possible),len(forced)):return forced,possible-forced

def test_propagate():
    T=list(it.combinations(range(5),3));solved=0
    for m in range(1<<len(T)):
        E={e for i,e in enumerate(T) if m>>i&1};d=max(1,max(Counter(i for e in E for i in e).values(),default=0));lam=max(1,max(Counter(p for e in E for p in it.combinations(e,2)).values(),default=0));F,U=propagate(shadow(E,5),d,lam)
        assert F<=E<=F|U
        if not U:assert F==E;solved+=1
    E1={(0,1,2),(0,3,4),(1,3,5),(2,4,5)};E2={(0,1,3),(0,2,4),(1,2,5),(3,4,5)}
    assert shadow(E1,6)==shadow(E2,6)
    F,U=propagate(shadow(E1,6),2,1);assert F<=E1&E2 and E1|E2<=F|U and U
    return dict(exhaustive=1024,solved_by_propagation=solved,pasch_forced=len(F),pasch_unresolved=len(U))

def infer_unresolved(A,B,Y,F,U):
    # subtract known terms; vote only on remaining possible triples.
    Y=Y^observations(A,B,F,None);T=sorted(U);out=set(F)
    for lo in range(0,len(T),64):
        t=np.asarray(T[lo:lo+64]);s=np.zeros(len(t),np.int64)
        for a,b,c in ((0,1,2),(1,0,2),(2,0,1)):
            i,j,k=t[:,a],t[:,b],t[:,c];h=(A[:,j]&B[:,k])|(A[:,k]&B[:,j]);s+=2*(h&Y[:,i]).sum(0)-h.sum(0)
        if np.any(s==0):return None
        out.update(tuple(map(int,e)) for e in t[s>0])
    return out

def run():
    rng=np.random.default_rng(2026112513);rows=[];check=test_propagate();print(check,flush=True)
    for fam,n,d,lam,T in [('random',32,1,1,20),('linear',64,2,1,16),('linear',128,4,1,12),('random',128,2,2,12),('star',64,6,6,10),('pasch',6,2,1,20)]:
        for eta in (0,.15,.25):
            stats=[]
            for t in range(T):
                E=({(0,1,2),(0,3,4),(1,3,5),(2,4,5)} if t%2 else {(0,1,3),(0,2,4),(1,2,5),(3,4,5)}) if fam=='pasch' else {'random':generate,'linear':linear,'star':star}[fam](n,d,rng)
                M1=math.ceil(384*d*math.log2(n)/(1-2*eta)**2);B,Y=shadow_probe(n,d,M1,E,eta,rng);N=infer_shadow(B,Y,d,eta)
                r=propagate(N,d,lam) if N is not None else None;C=None;M2=0;F=U=set()
                if r is not None:
                    F,U=r
                    if not U:C=F
                    else:
                        M2=math.ceil(384*(d+lam**2)*math.log2(n)/(1-2*eta)**2);A,B=draw(n,M2,p_for(d,lam),rng);Y=observations(A,B,E,rng,eta);C=infer_unresolved(A,B,Y,F,U)
                if C is not None and (shadow(C,n)!=N or max(Counter(i for e in C for i in e).values(),default=0)>d or max(Counter(p for e in C for p in it.combinations(e,2)).values(),default=0)>lam):C=None
                M3=holdout_size(n,eta,.01) if C is not None else 0
                if C is not None:
                    A=rng.random((M3,n))<.5;B=rng.random((M3,n))<.5;Y=contraction(A,B,E)^(rng.random((M3,n))<eta)
                    if not verify(C,A,B,Y,eta):C=None
                stats.append(dict(exact=C==E,wrong=C is not None and C!=E,shadow_exact=N==shadow(E,n),forced=len(F),unresolved=len(U),stage2_skipped=r is not None and not U,calls=4*(M1+M2+M3),M1=M1,M2=M2,M3=M3))
            row=dict(family=fam,n=n,d=d,lam=lam,eta=eta,trials=T,stats=stats);rows.append(row);print(fam,n,d,eta,'exact',sum(x['exact'] for x in stats),'skipped',sum(x['stage2_skipped'] for x in stats),'calls',np.median([x['calls'] for x in stats]),flush=True)
    Path(__file__).with_name('pruning.json').write_text(json.dumps(dict(check=check,rows=rows),indent=2))
if __name__=='__main__':run()
