"""Vectorized equivalent decoder; stress tests of fixed-degree scaling."""
from robust import masks,observations,decode,generate,bound
import numpy as np, json,time,math
from pathlib import Path

def fast(A,B,Y,d):
 M,n=A.shape;j,k=np.triu_indices(n,1);links=[set() for _ in range(n)];Y=Y.astype(float)
 for st in range(0,len(j),128):
  u,v=j[st:st+128],k[st:st+128];hit=((A[:,u]&B[:,v])|(B[:,u]&A[:,v])).astype(float);cnt=hit.sum(axis=0);votes=hit.T@Y
  if np.any(cnt==0):return None
  z=2*votes-cnt[:,None];idx=np.arange(len(u));z[idx,u]=-1;z[idx,v]=-1
  if np.any(z==0):return None
  for l,i in zip(*np.nonzero(z>0)):links[i].add(tuple(sorted((int(i),int(u[l]),int(v[l])))))
 es=set().union(*links)
 if any(len(L)>d for L in links) or any(sum(e in links[i] for i in e)!=3 for e in es):return None
 return es

def run():
 rng=np.random.default_rng(26112510);checks=0;rows=[]
 for n,d in [(5,1),(9,2),(16,3)]:
  for i in range(20):
   E=generate(n,d,rng);A,B=masks(n,d,256,rng);Y=observations(A,B,E,rng,.1);assert fast(A,B,Y,d)==decode(A,B,Y,d);checks+=1
 for n,d,trials in [(32,1,8),(64,1,6),(128,1,4),(256,1,2),(64,2,4),(128,2,3)]:
  M=math.ceil(384*d*d*math.log2(n));Elist=[generate(n,d,rng) for _ in range(trials)]
  for eta in (.05,.15):
   times=[];count=wrong=0
   for E in Elist:
    A,B=masks(n,d,M,rng);Y=observations(A,B,E,rng,eta);t=time.perf_counter();C=fast(A,B,Y,d);times.append(time.perf_counter()-t);count+=C==E;wrong+=C is not None and C!=E
   row=dict(n=n,d=d,trials=trials,eta=eta,probes=M,phase_calls=4*M,exact=count,wrong=wrong,rejected=trials-count-wrong,cpu_median_s=float(np.median(times)));rows.append(row);print(row,flush=True)
 Path(__file__).with_name('scale_results.json').write_text(json.dumps(dict(equivalence_checks=checks,rows=rows),indent=2))
if __name__=='__main__':run()
