import itertools as it, math, random, time, json
from pathlib import Path
import numpy as np
from round4_reference import GF, coded_recover, contraction, fwht
class Field(GF):
 def __init__(self,m):
  if m<=9: super().__init__(m);return
  self.m=m;self.q=1<<m;self.mod=self.q-1
  poly={10:0x409,12:0x1053,14:0x4443,16:0x1100b,18:0x40027}[m];self.exp=[];v=1
  for _ in range(self.mod):
   self.exp.append(v);v<<=1
   if v&self.q:v^=poly
  assert len(set(self.exp))==self.mod and v==1
  self.log={v:i for i,v in enumerate(self.exp)};self.exp*=2
 def locator(self,odd,k):
  S=[0]*(2*k+1)
  for t in range(1,2*k+1):S[t]=odd[t//2] if t%2 else self.mul(S[t//2],S[t//2])
  seq=S[1:];C=[1]+[0]*(2*k);B=C.copy();L=0;shift=1;b=1
  for i,s in enumerate(seq):
   delta=s
   for j in range(1,L+1):delta^=self.mul(C[j],seq[i-j])
   if not delta:shift+=1;continue
   T=C.copy();coeff=self.div(delta,b)
   for j in range(2*k+1-shift):C[j+shift]^=self.mul(coeff,B[j])
   if 2*L<=i:L=i+1-L;B=T;b=delta;shift=1
   else:shift+=1
  assert L<=k
  return C[:L+1]
class CompactField(Field):
 def __init__(self,m):
  self.m=m;self.q=1<<m;self.mod=self.q-1
  self.poly={2:7,3:11,4:19,5:37,6:67,7:131,8:285,9:529,10:0x409,11:0x805,12:0x1053,14:0x4443,16:0x1100b,18:0x40027,20:0x100009,22:0x400003}[m]
  # Rabin-style irreducibility check: gcd(x^(2^i)-x,p)=1 for i<=m/2; x^(2^m)=x.
  x=2
  for i in range(1,m+1):
   x=self.mul(x,x)
   if i<=m//2:
    a,b=self.poly,x^2
    while b:
     while a.bit_length()>=b.bit_length():a^=b<<(a.bit_length()-b.bit_length())
     a,b=b,a
    assert a==1
  assert x==2
  self.exp=[self.pow(2,i) for i in range(2*m+1)]
 def mul(self,a,b):
  r=0
  while b:
   if b&1:r^=a
   b>>=1;a<<=1
   if a&self.q:a^=self.poly
  return r
 def pow(self,a,t):
  r=1
  while t:
   if t&1:r=self.mul(r,a)
   t>>=1;a=self.mul(a,a)
  return r
 def div(self,a,b):
  assert b
  if not a:return 0
  u,v=b,self.poly;g1,g2=1,0
  while u!=1:
   j=u.bit_length()-v.bit_length()
   if j<0:u,v=v,u;g1,g2=g2,g1;j=-j
   u^=v<<j;g1^=g2<<j
  while g1.bit_length()>self.m:g1^=self.poly<<(g1.bit_length()-self.m-1)
  return self.mul(a,g1)
def trim(p):
 while p and not p[-1]:p.pop()
 return p
def rem(a,b,g):
 a=trim(a.copy())
 while a and len(a)>=len(b):
  w=g.div(a[-1],b[-1]);off=len(a)-len(b)
  for j,v in enumerate(b):a[off+j]^=g.mul(w,v)
  trim(a)
 return a
def gcd(a,b,g):
 while b:a,b=b,rem(a,b,g)
 return [g.div(x,a[-1]) for x in a] if a else []
def quotient(a,b,g):
 a=a.copy();q=[0]*(len(a)-len(b)+1)
 while len(a)>=len(b):
  k=len(a)-len(b);w=g.div(a[-1],b[-1]);q[k]=w
  for j,v in enumerate(b):a[k+j]^=g.mul(w,v)
  trim(a)
 assert not a
 return q
def roots(C,g):
 # All roots promised distinct and in field. Trace pairing separates any two.
 def split(p,bit):
  if len(p)<=1:return []
  if len(p)==2:return [g.div(p[0],p[1])]
  for j in range(bit,g.m):
   power=rem([0,1<<j],p,g);trace=[0]*len(p)
   for _ in range(g.m):
    for k,v in enumerate(power):trace[k]^=v
    squared=[0]*max(0,2*len(power)-1)
    for k,v in enumerate(power):squared[2*k]=g.mul(v,v)
    power=rem(squared,p,g)
   factor=gcd(p,trim(trace),g)
   if 1<len(factor)<len(p):return split(factor,j+1)+split(quotient(p,factor,g),j+1)
  raise ValueError('could not separate distinct field roots')
 return split(C,0)
def masks(values,m):return [sum(((v>>i)&1)<<j for j,v in enumerate(values)) for i in range(m)]
def mul_terms(a,b,g,karatsuba=True):
 if not karatsuba:
  for i,x in enumerate(a):
   for j,y in enumerate(b):
    if x and y:yield x,y,g.exp[(i+j)%g.mod]
  return
 size=1<<(len(a)-1).bit_length();a=a+[0]*(size-len(a));b=b+[0]*(size-len(b))
 def rec(a,b,w):
  if not any(a) or not any(b) or not w:return
  if len(a)==1:yield a[0],b[0],w;return
  h=len(a)//2;shift=g.exp[h%g.mod];shift2=g.mul(shift,shift)
  yield from rec(a[:h],b[:h],g.mul(w,1^shift))
  yield from rec(a[h:],b[h:],g.mul(w,shift^shift2))
  yield from rec([x^y for x,y in zip(a[:h],a[h:])],[x^y for x,y in zip(b[:h],b[h:])],g.mul(w,shift))
 yield from rec(a,b,1)
def direct_recover(n,d,probe,karatsuba=True,verify=None,compact=False):
 m=max(2,n.bit_length());cls=CompactField if compact else Field;base=cls(m);g=cls(2*m)
 labels=[j|(base.pow(j,3)<<m) for j in range(1,n+1)]
 pairs=None if compact else {labels[j]^labels[k]:(j,k) for j,k in it.combinations(range(n),2)}
 if pairs is not None:assert len(pairs)==math.comb(n,2) and 0 not in pairs
 def pair_decode(z):
  if pairs is not None:return pairs[z]
  s=z&((1<<m)-1);t=z>>m;assert s
  p=base.div(t^base.pow(s,3),s)
  pair=tuple(sorted(x-1 for x in roots([p,s,1],base)))
  assert len(pair)==2 and 0<=pair[0]<pair[1]<n and labels[pair[0]]^labels[pair[1]]==z
  return pair
 a_cache={};q_cache={};moments=[[] for _ in range(n)]
 def powers(r):
  if r not in a_cache:a_cache[r]=masks([g.pow(z,r) for z in labels],g.m)
  return a_cache[r]
 def query(a,b):
  if not a or not b or a==b:return 0
  key=tuple(sorted((a,b)))
  if key not in q_cache:q_cache[key]=probe(*key)
  return q_cache[key]
 for t in range(1,2*d,2):
  out=[0]*n
  for r in range((t+1)//2):
   if r&t!=r:continue
   for a,b,w in mul_terms(powers(r),powers(t-r),g,karatsuba and r!=0):
    bits=query(a,b)
    while bits:
     low=bits&-bits;out[low.bit_length()-1]^=w;bits^=low
  if verify is not None:
   expected=[0]*n
   for e in verify:
    for i,j,k in (e,(e[1],e[0],e[2]),(e[2],e[0],e[1])):expected[i]^=g.pow(labels[j]^labels[k],t)
   assert out==expected,(n,d,t)
  for i,v in enumerate(out):moments[i].append(v)
 links=[]
 for i,odd in enumerate(moments):
  C=g.locator(odd,d);found=[]
  if len(C)>1:
   found=[pair_decode(g.div(1,z)) for z in roots(C,g)]
  assert len(found)==len(C)-1 and all(i not in pair for pair in found)
  links.append(found)
 es={tuple(sorted((i,*pair))) for i,link in enumerate(links) for pair in link}
 assert sum(map(len,links))==3*len(es)
 return es,4*len(q_cache)
def random_hypergraph(n,d,rng):
 deg=[0]*n;es=set()
 for _ in range(15*n*d):
  pool=[i for i in range(n) if deg[i]<d]
  if len(pool)<3:break
  e=tuple(sorted(rng.sample(pool,3)))
  if e not in es:
   es.add(e)
   for i in e:deg[i]+=1
 return es
def statevector_probe(n,es,rng):
 x=np.arange(1<<n);tt=np.zeros(len(x),dtype=np.int8)
 for e in list(es)+[(),(rng.randrange(n),),tuple(rng.sample(range(n),2))]:
  mask=sum(1<<i for i in e);tt^=((x&mask)==mask).astype(np.int8)
 def probe(a,b):
  phase=1-2*(tt^tt[x^a]^tt[x^b]^tt[x^a^b]);psi=fwht(phase/np.sqrt(len(tt)))
  idx=int(np.argmax(abs(psi)**2));assert abs(abs(psi[idx])**2-1)<1e-9 and idx==contraction(es,a,b)
  return idx
 return probe
def run():
 rng=random.Random(20261125);rows=[]
 for n,d,reps in [(6,1,10),(6,2,10),(9,3,10),(12,3,6),(32,2,5),(32,4,4),(64,2,4),(128,2,3),(256,2,2)]:
  q=[];ts=[]
  for _ in range(reps):
   es=random_hypergraph(n,d,rng);probe=statevector_probe(n,es,rng) if n<=12 else lambda a,b:contraction(es,a,b)
   now=time.perf_counter();new,qn=direct_recover(n,d,probe,verify=es);tnew=time.perf_counter()-now
   now=time.perf_counter();school,qs=direct_recover(n,d,probe,karatsuba=False);tschool=time.perf_counter()-now
   now=time.perf_counter();old,qo,_=coded_recover(n,d,probe);told=time.perf_counter()-now
   assert new==school==old==es
   q.append((qn,qs,qo));ts.append((tnew,tschool,told))
  row=dict(n=n,d=d,cases=reps,correct=reps,queries_karatsuba=q[0][0],queries_schoolbook=q[0][1],queries_v02=q[0][2],median_seconds=list(map(float,np.median(ts,axis=0))),mode='statevector' if n<=12 else 'analytic contraction')
  assert len(set(q))==1;rows.append(row);print(row,flush=True)
 triples=list(it.combinations(range(5),3));cases=0
 for code in range(1<<len(triples)):
  es={e for j,e in enumerate(triples) if code>>j&1}
  if any(sum(i in e for e in es)>2 for i in range(5)):continue
  assert direct_recover(5,2,lambda a,b:contraction(es,a,b),verify=es)[0]==es;cases+=1
 e1={(0,1,2),(0,3,4),(1,3,5),(2,4,5)};e2={(0,1,3),(0,2,4),(1,2,5),(3,4,5)}
 for es in [e1,e2]:assert direct_recover(6,2,lambda a,b:contraction(es,a,b),verify=es)[0]==es
 result=dict(seed=20261125,rows=rows,exhaustive_cases=cases,prior_counterexamples=2)
 Path(__file__).with_name('results.json').write_text(json.dumps(result,indent=2));print('exhaustive',cases,flush=True)
if __name__=='__main__':run()
