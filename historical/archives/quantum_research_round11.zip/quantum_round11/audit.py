from pruning import *
from circuit import Simulator,oracle_gates,derivative

def run():
 rng=np.random.default_rng(2026112514);gates=0;rows=[]
 for n in (4,5,6):
  sim=Simulator(n)
  for _ in range(4):
   E=generate(n,2,rng);A=rng.random((16,n))<.5;B=rng.random((16,n))<.2;Y=contraction(A,B,E);g=oracle_gates(E|{(0,),(0,1)})
   for a,b,y in zip(A,B,Y):
    mask=lambda v:sum(int(x)<<i for i,x in enumerate(v))
    assert sim.run(derivative(n,g,(mask(a),mask(b))))==mask(y);gates+=1
 for fam,n,d,lam,T in [('random',32,1,1,20),('linear',64,2,1,12),('linear',48,4,1,12),('star',32,6,6,10)]:
  eta=.25;M1=math.ceil(384*d*math.log2(n)/(1-2*eta)**2);M3=holdout_size(n,eta,.01);out=[]
  for t in range(T):
   E={'random':generate,'linear':linear,'star':star}[fam](n,d,rng);B,Y=shadow_probe(n,d,M1,E,eta,rng);N=infer_shadow(B,Y,d,eta);r=propagate(N,d,lam) if N is not None else None;C=None;M2=0
   if r is not None:
    F,U=r
    if not U:C=F
    else:
     M2=math.ceil(384*(d+lam**2)*math.log2(n)/(1-2*eta)**2);A,B=draw(n,M2,p_for(d,lam),rng);Y=observations(A,B,E,rng,eta);C=infer_unresolved(A,B,Y,F,U)
   if C is not None:
    A=rng.random((M3,n))<.5;B=rng.random((M3,n))<.5;Y=contraction(A,B,E)^(rng.random((M3,n))<eta)
    if not verify(C,A,B,Y,eta):C=None
   # same total budget: use all for original pooled, no independent holdout for baseline
   M=M1+M2+M3;A,B=draw(n,M,p_for(d,lam),rng);Y=observations(A,B,E,rng,eta);R,t0,m0=measure(pooled,A,B,Y,d,lam)
   out.append(dict(exact=C==E,wrong=C is not None and C!=E,baseline_exact=R==E,baseline_wrong=R is not None and R!=E,calls=4*M,baseline_peak=m0,baseline_cpu=t0))
  row=dict(family=fam,n=n,d=d,eta=eta,trials=T,results=out);rows.append(row);print(fam,n,d,'new',sum(x['exact'] for x in out),'old',sum(x['baseline_exact'] for x in out),flush=True)
 result=dict(gate_checks=gates,rows=rows);Path(__file__).with_name('audit.json').write_text(json.dumps(result,indent=2));print('gates',gates,flush=True)
if __name__=='__main__':run()
