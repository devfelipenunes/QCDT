# Quantum algorithm research — Round 5

Status: research prototype and candidate theorems, not peer reviewed. No claim of novelty or practical quantum advantage. Reproduction: Python 3 with NumPy; no Qiskit or quantum hardware used.

## Reproduce

```sh
python -m pip install numpy
python research.py
python compact_validation.py
python stress.py
python graph_validation.py
```

The four JSON files record the executed results; logs are included. Seeds: 20261125, 92821, 82923, 9734. Timings are exploratory CPU times, not quantum execution times. `round4_reference.py` and `qcdt_v01.py` are the prior baselines. `research.py` includes both the v0.3 table-based direct method and v0.4 compact variant.

## 1. QCDT v0.3: direct edge syndromes

### Model
An exact coherent phase oracle for an unknown Boolean function f of degree at most 3 over F2. Every variable belongs to at most d cubic monomials. The algorithm recovers only cubic coefficients; lower-degree terms are eliminated. It does not learn arbitrary programs or implement real smart-contract oracles. A probe D(a,b) returns n bits, via four phase-oracle calls and Bernstein–Vazirani interference. For variable i, D_i(a,b)=sum over its link edges {j,k} of (a_j b_k + a_k b_j) in F2. The same measurement supplies all links simultaneously.

### Lemma 1: injective pair labels
Let m=ceil(log2(n+1)), assign distinct nonzero x_j in K=GF(2^m). Embed the binary vector pair L_j=(x_j,x_j^3) in F=GF(2^(2m)) by any fixed F2-linear bijection (in code concatenate polynomial-basis coordinates). The pair label z_jk=L_j+L_k is nonzero and determines the unordered pair. Its two coordinates are s=x_j+x_k != 0 and t=x_j^3+x_k^3. In characteristic two, t=s^3+s*x_j*x_k. Hence p=(t+s^3)/s is the product; the roots of X^2+sX+p are exactly x_j,x_k. This proof uses the base field for the coordinates and does not require it to be a subfield of F under the chosen embedding.

### Lemma 2: moments from bilinear probes
For link i define M_i,t = sum_(j,k in link i) (L_j+L_k)^t in F. For odd t, Lucas's theorem in characteristic 2 yields

M_i,t = sum_(0<=r<t-r, r bitwise-submask of t) sum_(j,k in link i) [ L_j^r L_k^(t-r) + L_k^r L_j^(t-r) ].

Every product over F has a binary bilinear decomposition uv=sum_l c_l A_l(u) B_l(v), where A_l and B_l are binary linear forms. Use masks a_j=A_l(L_j^r), b_j=B_l(L_j^(t-r)); the inner sum is exactly sum_l c_l D_i(a,b). Symmetry of D permits caching and zero/equal masks cost zero. Karatsuba on polynomial basis coordinates supplies at most O(M^log2(3)) binary products for extension degree M=2m, with padding to a power of two. The r=0 terms cost only M probes. Code independently verifies every field moment against the hidden hypergraph (test instrumentation only, not part of the decoder).

### Lemma 3: exact sparse decoding
For a link with h<=d edges, the d odd power sums t=1,3,...,2d-1 determine all first 2d moments, since M_(2u)=M_u^2. If two subsets of distinct nonzero pair labels of size <=d had equal moments, their symmetric difference would give a homogeneous Vandermonde system with <=2d distinct nonzero columns, impossible for a nonempty difference. Berlekamp–Massey recovers the minimal recurrence for the sum of h distinct nonzero exponential sequences; its locator polynomial is product_(z in link)(1+z X). Find the inverse roots and decode pairs. Symmetry across three link lists is checked. v0.3 uses a pair dictionary, v0.4 uses Lemma 1 directly.

### Query bound
For each t odd, there are 2^(popcount(t)-1) unordered binomial terms. Summing over t<2d is O(d^log2(3)), by the identity sum_(t<2^l) 2^popcount(t)=3^l. With Karatsuba, at most O(d^log2(3) * (log n)^log2(3)) logical phase queries, four per probe. This is a uniform constructive upper bound in the ideal model. For d=1, only the r=0 term is needed, yielding O(log n). The known existence of linear-rank binary finite-field multiplication decompositions (Chudnovsky and Chudnovsky 1987; Ballet 1999) implies an O(d^log2(3) log n) **query upper bound**, assuming the decomposition is supplied; an efficient uniform construction, constants and physical gate costs for that improved bound have not been implemented. The classical processing using the implemented Karatsuba variant and compact decoding is polynomial. Neither bound is asserted to be new in the literature. The v0.1 randomized method already achieves O(d log n) queries but has combinatorial decoding; the new deterministic construction addresses decoding and the v0.2 query count.

### Lower bounds for fixed d>=1
Consider n divisible by 3 and the M=n!/(6^(n/3)*(n/3)!) disjoint-triple hypergraphs. log2 M=Theta(n log n). With classical value queries each oracle response gives one bit; at most 2^q transcripts, so q=Omega(n log n) for worst-case success >=2/3 (average over uniform functions suffices). For quantum phase queries, purify an adaptive algorithm to a pure-state algorithm with q queries. Its final state is a linear combination of fixed vectors with coefficients monomials of degree <=q in the 2^n oracle signs (each query is diagonal in the query register, with work registers untouched). The span dimension is at most (2^n+1)^q, independent of workspace. For equiprobable M states supported on a D-dimensional subspace, average identification success <=D/M by the POVM trace bound. Thus q>=log2(2M/3)/log2(2^n+1)=Omega(log n). Padding handles other n. Consequently the theoretical linear-rank upper bound gives Theta(log n) quantum query complexity for constant d in this promise problem. This is query-optimal in order, not a claim of globally optimal gate count, time, or novelty. The phase oracle has n address qubits; no free classical access to the hidden function is assumed.

## 2. v0.4: eliminate quadratic tables

The first direct implementation scanned all pair labels for each locator. Replaced root search by deterministic trace splitting: for square-free polynomial p whose roots all belong to GF(2^M), take gcd(p,Tr(cX) mod p) over each binary basis element c. The field trace pairing is nondegenerate, so for distinct roots u,v some c separates them. Recursively split and solve degree-one factors; traces use repeated squaring modulo p. Pair decode uses Lemma 1 and the same trace splitting in K. Compact field arithmetic uses polynomial reduction and extended Euclid, not exp/log tables; supplied irreducible polynomials checked at construction. No pair dictionary or field-size lookup table. Masks and output data still need polynomial storage; finite set of field degrees in the prototype limits tested range. Root factorization is polynomial in d and log n; processing across n links is polynomial, and for fixed d is n times polylogarithmic field-operation overhead (apart from oracle implementation). This does not imply physical runtime advantage.

## 3. Experiments

### v0.3 (research.py)
54 generated instances, 36 of them with ideal statevectors (n<=12), 18 with algebraic contractions; every reconstruction correct in all 3 implementations (Karatsuba, schoolbook, v0.2). 86 exhaustive admissible n=5,d=2 cases and both prior counterexamples recovered. Selected logical calls:

| n | d | v0.3 Karatsuba | direct schoolbook | v0.2 |
|---:|---:|---:|---:|---:|
|6|1|24|24|60|
|6|2|116|168|112|
|9|3|300|488|612|
|12|3|304|488|612|
|32|2|308|648|1104|
|32|4|1260|2880|4140|
|64|2|384|884|1512|
|128|2|448|1152|1984|
|256|2|576|1440|2520|

Not uniformly better: at n=6,d=2, v0.2 uses fewer queries. A nonuniform strategy could choose the cheaper mask schedule. v0.1 remains lower in queries on the tested small instances.

### v0.4 (compact_validation.py)
390 pairs of finite-field multiplication/division checks (both operations compared), 34 generated instances all correct, and a repeat of the 86 exhaustive small cases. 512 variables,d=2: 660 phase calls, 2/2. 1024 variables,d=2: 760 phase calls, 1/1. Large cases are exact algebraic probes, not statevector simulation. A single large instance is insufficient to establish statistical performance.

### Stress (stress.py)
16 paired v0.1 vs v0.4 instances using analytic contractions; all correct. At n=16,d=3, v0.1 used 168 phase calls and median ~0.605s CPU; v0.4 448 calls and ~0.0103s. CPU includes local simulated probes and decoding, not hardware; tiny sample, no performance guarantee. At n=6,d=2 the old method was faster. 40 additional independent ideal gate-sequence simulations at n=8 confirmed the H–phase–X sequence. A quartic monomial counterexample gives four equiprobable outputs after double differentiation (max probability 0.25); degree<=3 is essential.

Noise: independently flip each measured bit with probability p. Repeated odd shots and majority vote, followed by the normal decoder, 30 instances per configuration. At p=1%, exact counts for 1,3,5,9 shots are 1,28,29,30; p=5%: 0,1,23,29; p=10%: 0,0,1,20. Other runs rejected; no wrong accept observed, not a proof of no wrong accepts. 168 ideal phase calls per case; 1512 with 9 repetitions. No gate noise, coherent errors or real calibration model; majority voting is not quantum error correction. For p<1/2 and r independent repeats, a union bound over n*P measured bits gives failure <=nP exp(-2r(1/2-p)^2). No assumption of independent probes beyond the measurement model is needed for this bound.

## 4. Graph Collision: stronger query bound, not a novel primitive

Known footprints with n transactions, each accessing <=k keys. For each key j, s_j transactions access it, some writing. Local collision g_j iff at least two distinct marked accessing transactions and at least one marked writer. Search for a marked writer and another marked distinct accessing transaction takes O(sqrt(s_j)) bounded-error bit queries (standard quantum search with verification). Omit groups with no writers or fewer than 2 transactions. Introduce copies of the marking bits for each key incidence; these copies can be queried coherently via their known map to the original mark bits at one original oracle call, ignoring the computation cost of addressing as usual in the query model. The composition is OR of disjoint-input copies of g_j. Weighted general adversary composition and tightness (Høyer–Lee–Špalek 2007; Reichardt 2011) imply Q=O(sqrt(sum_j s_j))=O(sqrt(nk)). Weighted OR bound: for costs c_j, L=sqrt(sum c_j^2), choose dual vector of magnitude sqrt(c_j/L) for all-zero input and reciprocal at one marked bit for each positive input; weighted squared norms <=L. Compose with costs Adv±(g_j)=O(sqrt(s_j)). Cap by O(n) via direct reading. This improves the previous formula bound by a logarithmic factor, but follows known query-theoretic tools and does not resolve general Graph Collision. For k=1, disjoint pairs (fix first writer marked, second input bit) give OR_(n/2), hence worst-case Theta(sqrt n) for fixed k. No explicit circuit for the weighted adversary construction has been synthesized. 320 synthetic footprint cases and 2046 OR-restriction assignments checked classically, no divergences. The graph and selections are often explicit in blockchain memory: then O(nk) classical scan is likely more useful. No real Soroban trace or hardware benchmark.

## 5. Literature and decision

- Montanaro (2012), learning multilinear polynomials: https://arxiv.org/abs/1105.3310
- Montanaro & Shao, hidden graphs/parity model: https://arxiv.org/abs/2011.08611
- Learning bounded-degree graph, OR model: https://arxiv.org/abs/2402.18714
- Sparse Polynomial Learning and Graph Sketching (2014), different model: https://proceedings.neurips.cc/paper_files/paper/2014/hash/78812290b46192ce379f0349a4ef0758-Abstract.html
- Hypergraph learnability with CUT oracles (2026), different model: https://arxiv.org/abs/2607.01216
- Chudnovsky & Chudnovsky (1987), linear bilinear complexity: https://pmc.ncbi.nlm.nih.gov/articles/PMC304516/
- Ballet (1999), linear finite-field multiplication complexity: https://doi.org/10.1006/ffta.1999.0255
- Høyer, Lee & Špalek (2007), weighted adversary composition: https://arxiv.org/abs/quant-ph/0611054
- Reichardt (2011), adversary tightness: https://arxiv.org/abs/1005.1601
- Parameterized Graph Collision: https://arxiv.org/abs/1305.1021
- Variable time quantum search (2023): https://arxiv.org/abs/2302.06749
- General Graph Collision gap: https://qiqc-op.com/problem/op_39721600d81c6992/
- CAP-0063: https://github.com/stellar/stellar-protocol/blob/master/core/cap-0063.md

QCDT v0.4 remains the strongest research candidate. The specific combination of pair-label moments and binary bilinear probes requires systematic prior-art review and independent mathematical review. The components (BV, BCH decoding, Karatsuba, trace splitting, Sidon labels, bilinear rank bounds) are known. Graph Collision result is a useful structural specialization of known theorems, not a fundamental discovery. Retain it as a potential applied note. Stop gate before claiming novelty: compare directly with sparse Boolean polynomial learning in the identical oracle model; implement Qiskit circuit and noise model, use stronger classical baselines including known-circuit symbolic inspection, quantify reversible synthesis and physical resources, test real applications. User asked for recursive refinement; this package is a completed bounded cycle, not an ongoing background process.
