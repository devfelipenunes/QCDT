"""Checks the footprint reduction and lower-bound restriction; NOT quantum execution."""
import random,itertools,json
from pathlib import Path
rng=random.Random(9734)
rows=[]
for n,k,numkeys in [(16,1,16),(32,2,16),(64,4,8),(128,8,16)]:
 edges=[];inc=[];cases=80
 for _ in range(cases):
  groups={};fs=[]
  for i in range(n):
   f={j:rng.randrange(2) for j in rng.sample(range(numkeys),k)};fs.append(f)
   for j,w in f.items():groups.setdefault(j,[]).append((i,w))
  e=[(i,j) for i,j in itertools.combinations(range(n),2) if any(fs[i][key] or fs[j][key] for key in fs[i].keys()&fs[j].keys())]
  x=[rng.random()<rng.choice([.01,.1,.5]) for _ in range(n)]
  expected=any(x[i] and x[j] for i,j in e)
  got=any(sum(x[i] for i,w in g)>=2 and any(x[i] and w for i,w in g) for g in groups.values());assert expected==got
  edges.append(len(e));inc.append(sum(len(g) for g in groups.values() if len(g)>1 and any(w for i,w in g)))
 rows.append(dict(n=n,k=k,cases=cases,agreement=cases,mean_edges=sum(edges)/cases,mean_relevant_incidence=sum(inc)/cases))
# Restrict disjoint two-transaction key groups: first writer always marked, second is input bit.
for m in range(1,11):
 for bits in range(1<<m):
  x=[b for j in range(m) for b in (1,(bits>>j)&1)]
  assert any(x[2*j] and x[2*j+1] for j in range(m))==bool(bits)
result=dict(rows=rows,or_restriction_cases=sum(1<<m for m in range(1,11)))
Path(__file__).with_name('graph_results.json').write_text(json.dumps(result,indent=2));print(result)
