import random, json, time
from pathlib import Path
import numpy as np
import qcdt_v01 as old
from research import direct_recover,random_hypergraph,contraction,fwht
rng=random.Random(82923);N=np.random.default_rng(82923)
rows=[]
for n,d in [(6,2),(9,3),(12,3),(16,3)]:
 times=[[],[]];qs=[[],[]];correct=[0,0]
 for i in range(4):
  es=random_hypergraph(n,d,rng);probe=lambda a,b:contraction(es,a,b)
  t=time.perf_counter();got,q=direct_recover(n,d,probe,compact=True);times[0].append(time.perf_counter()-t);qs[0].append(q);correct[0]+=got==es
  t=time.perf_counter();num=old.num_probes(n,d);pairs=[(rng.getrandbits(n),rng.getrandbits(n)) for _ in range(num)]
  try:got=old.recover(n,d,pairs,[probe(*p) for p in pairs]);correct[1]+=got==es
  except ValueError:pass
  times[1].append(time.perf_counter()-t);qs[1].append(4*num)
 rows.append(dict(n=n,d=d,trials=4,correct=correct,queries=[q[0] for q in qs],median_seconds=list(map(float,np.median(times,axis=1)))))
 print('baseline',rows[-1],flush=True)
# Simulate gate order independently of derivative formula, 40 cases.
for i in range(40):
 n=8;es=random_hypergraph(n,3,rng);x=np.arange(1<<n);a,b=rng.getrandbits(n),rng.getrandbits(n)
 state=np.ones(len(x),dtype=complex)/np.sqrt(len(x))
 for shift in (a,b,a,b):
  for edge in list(es)+[(),(0,),(1,2)]:
   mask=sum(1<<j for j in edge);state[(x&mask)==mask]*=-1
  state=state[x^shift]
 state=fwht(state);assert np.isclose(abs(state[contraction(es,a,b)])**2,1)
# Out-of-promise quartic gives non-deterministic result for some masks.
x=np.arange(16);f=((x&15)==15).astype(int);a,b=1,2;phase=1-2*(f^f[x^a]^f[x^b]^f[x^a^b]);p=abs(fwht(phase/4))**2;assert np.isclose(p.max(),.25)
noise=[];n,d=9,2
for prob in [.01,.05,.1]:
 for reps in [1,3,5,9]:
  success=rejected=wrong=0;queries=[]
  for i in range(30):
   es=random_hypergraph(n,d,rng);calls=[0]
   def probe(a,b):
    calls[0]+=1;v=contraction(es,a,b);bits=np.array([(v>>j)&1 for j in range(n)]);counts=(bits^(N.random((reps,n))<prob)).sum(0);return sum(int(c>reps//2)<<j for j,c in enumerate(counts))
   try:
    got,q=direct_recover(n,d,probe,compact=True)
    if got==es:success+=1
    else:wrong+=1
   except (AssertionError,ValueError,KeyError,ZeroDivisionError):rejected+=1
   queries.append(calls[0]*4*reps)
  row=dict(p=prob,repeats=reps,cases=30,exact=success,rejected=rejected,wrong=wrong,max_phase_calls=max(queries));noise.append(row);print('noise',row,flush=True)
Path(__file__).with_name('stress_results.json').write_text(json.dumps(dict(baseline=rows,explicit_gate_sequence_cases=40,quartic_max_probability=float(p.max()),noise=noise),indent=2))
