import random,time,json,itertools
from pathlib import Path
from research import direct_recover,random_hypergraph,statevector_probe,CompactField,Field,contraction
rng=random.Random(92821);rows=[]
for m in [2,3,4,5,6,7,8,9,10,12,14,16,18]:
 a=CompactField(m);b=Field(m)
 for _ in range(30):
  x=rng.randrange(1,a.q);y=rng.randrange(1,a.q);assert a.mul(x,y)==b.mul(x,y) and a.div(x,y)==b.div(x,y)
for n,d,reps in [(6,2,8),(9,3,8),(12,3,5),(32,4,5),(128,2,3),(256,2,2),(512,2,2),(1024,2,1)]:
 ts=[]
 for _ in range(reps):
  es=random_hypergraph(n,d,rng);p=statevector_probe(n,es,rng) if n<=12 else lambda a,b:contraction(es,a,b)
  start=time.perf_counter();got,q=direct_recover(n,d,p,compact=True,verify=es);ts.append(time.perf_counter()-start);assert got==es
 rows.append(dict(n=n,d=d,cases=reps,correct=reps,queries=q,seconds=ts));print(rows[-1],flush=True)
tr=list(itertools.combinations(range(5),3));count=0
for code in range(1<<len(tr)):
 es={e for j,e in enumerate(tr) if code>>j&1}
 if any(sum(i in e for e in es)>2 for i in range(5)):continue
 assert direct_recover(5,2,lambda a,b:contraction(es,a,b),compact=True)[0]==es;count+=1
Path(__file__).with_name('compact_results.json').write_text(json.dumps(dict(field_checks=390,rows=rows,exhaustive_cases=count),indent=2));print('exhaustive',count)
