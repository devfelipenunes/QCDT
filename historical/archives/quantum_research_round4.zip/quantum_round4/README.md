# Quantum research — rodada 4 (25/11/2026)

## Reprodução

Descompacte mantendo a estrutura. Requer Python 3.10+, NumPy e SciPy. Execute na raiz:

```bash
python -m pip install -r quantum_round4/requirements.txt
python quantum_round4/research.py
python quantum_round4/validation.py
```

Os dois scripts foram efetivamente executados com sementes fixas; arquivos `results.json` e `validation.json` são os resultados observados. Os tempos de CPU variam por máquina. Qiskit não instalado, nenhum hardware quântico. Instâncias sintéticas; nenhuma alteração na Stellar ou no SDK. O código é protótipo científico, não software de produção.

## Resultado decisório

1. **Q02 — continuar:** construção determinística por síndromes de campo finito, recupera hipergrafos sobrepostos e substitui a busca combinatória do decodificador QCDT v0.1 por decodificação polinomial. Não é adaptativa; usa mais consultas que o QCDT aleatório anterior. Originalidade científica não comprovada.
2. **Q01 — continuar como linha teórica:** redução de conflitos read/write a fórmula booleana sobre footprints. Demonstra estrutura útil, mas não supera os teoremas gerais de avaliação de fórmulas. Não implementamos o circuito quântico dessa redução; apenas testamos a equivalência clássica.
3. **B01 — manter como aplicação clássica/híbrida:** regra de restrição após alteração de um nó; MILP já eficaz. Não implementamos um oráculo reversível nem demonstramos vantagem quântica.
4. **B08 — suspender variante:** amplificação de Fourier supera Fourier puro em mudanças raras, mas perde ou empata com Grover seguido de testes locais nas famílias testadas. A prevalência é fornecida ao algoritmo, condição favorável; as funções são sintéticas, não contratos reais.
5. **Q04 — suspender reivindicação de novidade:** a busca binária por prefixos é anterior; diagnóstico funciona apenas no modelo de uma falha Pauli e acesso a prefixos, não é nova técnica.

## Q02: algoritmo candidato e prova de correção

Seja f uma função booleana de grau máximo 3, T seu tensor simétrico de coeficientes cúbicos, com índices distintos. Cada vértice pertence a no máximo d hipera-restas. Para cada i, L_i[j,k]=T_ijk é a matriz simétrica (diagonal nula) do grafo de ligação. Há no máximo d arestas, logo no máximo 2d coordenadas não nulas em L_i a e no máximo d por linha. A dupla derivada D_b D_a f é afim, e Bernstein–Vazirani devolve s_i=b^T L_i a em uma execução de quatro consultas de fase. A constante é fase global e não é recuperada. Termos inferiores ao grau três não afetam o resultado.

Escolha m=ceil(log2(n+1)) (m>=2 na implementação), campo F=GF(2^m), rótulos distintos não nulos alpha_j, k=2d. Para qualquer vetor binário z de peso <=k, as síndromes S_t=sum_j z_j alpha_j^t para t=1,3,...,2k-1 determinam as restantes via S_2t=S_t². Os 2k momentos consecutivos permitem recuperar o polinômio localizador por Berlekamp–Massey e encontrar as raízes por varredura dos n rótulos inversos. Isso é decodificação BCH conhecida. A unicidade também segue de Vandermonde: a diferença de duas palavras de peso <=k tem peso <=2k; se os 2k momentos fossem nulos, a matriz de Vandermonde dos rótulos distintos não nulos teria posto pleno, uma contradição.

Cada momento ímpar tem m bits, produzindo p=km=2dm máscaras binárias. Para cada a entre as p máscaras, consultamos todas as máscaras b e decodificamos L_i a para todos i. Depois, para cada i e cada j observado na primeira etapa, coletamos os bits (L_i a)_j para todas as máscaras a; são as síndromes da linha j de L_i. A segunda decodificação recupera todos os k0 com T_ijk0=1. Se a linha não aparece em nenhuma primeira recuperação, seu síndrome é zero e a unicidade garante que é nula. Reunimos os trios, sem duplicação. A prova não requer trios disjuntos. O código usa Berlekamp–Massey e busca de raízes, sem enumeração combinatória de subconjuntos. O campo na implementação é limitado por tabela de polinômios primitivos m=2..9; não é limitação teórica do método.

A simetria e a alternância permitem reutilizar consultas (a,b) e (b,a) e ignorar a=b ou máscara zero. Limite de 4*binom(p,2) chamadas de fase = O(d² log² n). O custo clássico é polinomial em n e d; no código a busca de raízes custa O(nk) operações de campo por decodificação. Comparar com a versão aleatória QCDT original, O(d log n) sondagens mas decodificação combinatória. Em n pequeno, usar derivadas por pares de coordenadas pode ser mais barato. O algoritmo recupera somente a parte cúbica e pressupõe grau <=3, oráculo coerente exato, limite local d conhecido e dados sem ruído.

Limite inferior clássico no modelo de consultas booleanas: para n múltiplo de 3, a família de partições em trios disjuntos tem M=n!/(6^(n/3)*(n/3)!) funções distintas. Uma árvore clássica de q consultas binárias tem no máximo 2^q folhas, portanto recuperação exata exige q>=log2 M=Omega(n log n). Mesmo para sucesso médio >=2/3, a contagem dá q>=log2(2M/3). O algoritmo tem O(log² n) consultas quânticas para d fixo. Essa separação é do modelo de consultas, não de tempo, não é necessariamente inédita e não implica vantagem em instâncias finitas testadas. A literatura de aprendizagem de polinômios, grafos e estados de fase é próxima; os modelos de cópias de estados e oráculos de contagem/OR não devem ser confundidos com oráculo coerente de paridade.

Resultados: 43/43 instâncias aleatórias (32 por vetor de estados, 11 por contração algébrica em n=32,128,256); 86/86 hipergrafos admissíveis exaustivos n=5,d=2; dois contraexemplos prévios distinguidos; 15/15 comparações pareadas com QCDT v0.1. A redução 130560 -> 2520 consultas em n=256,d=2 é contra derivação densa por pares, não contra o melhor método nem contra QCDT aleatório. A versão aleatória continua mais econômica em consultas nos três testes comparativos. Não se simulou um estado de 256 qubits.

## Q01: conflitos de transações

Para cada chave de estado j, S_j é o conjunto de transações que a leem ou escrevem; W_j é o subconjunto de escritoras. Para seleção x, existe conflito nessa chave sse (alguma escritora marcada) AND (pelo menos duas transações distintas marcadas em S_j). Prova por escolha de escritora e outra transação. OR sobre todas as chaves. Este predicado distingue read/read de read/write e write/write. Não representa todo o agendamento CAP-63, nem suas restrições de custo ou estágios.

A fórmula AND/OR para threshold-2 em s bits tem O(s log s) folhas: dividir em metades, testar threshold-2 nas duas e OR-esquerda AND OR-direita. Somando as ocorrências por chave, se cada transação acessa <=k chaves, são O(n k log n) folhas. Pelo teorema de avaliação quântica de fórmulas, isso fornece O(sqrt(n k log n)) consultas no modelo de grafo/footprints conhecidos e bits de seleção consultáveis coerentemente. A redução é simples e deriva de um teorema conhecido; não resolve Graph Collision geral, não demonstra que o limite parametrizado é novo, e não é uma implementação quântica. A comparação de sqrt(arestas) e sqrt(incidências) em JSON é apenas indicador estrutural; não é contagem de consultas executadas. Se as marcas são explícitas, a varredura por chave já resolve em O(nk) tempo clássico; custo de carregar os bits no oráculo é decisivo.

Resultados: 400 grafos sintéticos e 7776 combinações exaustivas de papéis e marcas em uma chave, equivalência 100%.

## B01: análise incremental de FBAS

Se a rede anterior tem interseção de quóruns e somente as fatias de um nó v são relaxadas, qualquer quórum novo que não era quórum antes contém v. Assim, qualquer testemunha de dois quóruns disjuntos na nova rede possui um lado que contém v. A busca pode fixar v num lado. Para cada candidato Q contendo v, o maior quórum contido no complemento é calculado removendo repetidamente nós cujas fatias não cabem no conjunto restante; se não vazio, é testemunha. Só relaxamentos de uma configuração previamente verificada estão cobertos. Restringir fatias preserva interseção, mas não necessariamente disponibilidade.

200 casos gerados com hub antigo obrigatório, 48 comparações independentes com MILP exato incluindo versão restrita. A regra reduz espaço nominal de 2^n-1 para 2^(n-1); não é prova de ganho temporal universal. A implementação clássica de enumeração com encerramento antecipado foi mais rápida que MILP nos pequenos casos fáceis; MILP restrito foi mais rápido que MILP irrestrito na mediana observada. Nenhum circuito quântico foi implementado. Stellar Quorum Analyzer usa SAT, não foi executado neste ambiente. A comparação com SAT incremental real continua pendente.

## B08: auditoria diferencial

h=f XOR g. Fourier puro usa fase (-1)^h. Amplificar a subpopulação h=1 e medir uma flag, depois aplicar Hadamard, produz amostras proporcionais a |h_hat(S)|²/p, p=Pr(h=1). Para bit i, a probabilidade marginal condicional é Inf_i(h)/(4p), enquanto na amostragem de fase pura é Inf_i(h); vantagem relativa em p pequeno não prova vantagem sobre outros métodos. Assume-se prevalência conhecida e oráculos XOR reversíveis de ambas as funções; as contagens incluem duas chamadas por fase ou computação de flag, não portas físicas. Para mintermos, Grover encontra uma testemunha e os flips locais identificam o suporte com n testes; com duas ramificações, repetir testemunhas e flips pode recuperar união. O baseline forte venceu/empatou nos casos raros e bifurcados. 400 instâncias de mintermo, 120 de duas ramificações com duas variáveis irrelevantes. SAT/SMT em contratos reais não avaliado; não sustentar alegação de originalidade.

## Q04: diagnóstico de falha única

Prepare pares de Bell para representar o estado de Choi do circuito em cada prefixo; uma falha Pauli não trivial única torna o estado ortogonal ao ideal a partir do prefixo defeituoso. Em condições ideais, um teste de projeção (inverter o prefixo ideal e medir Bell) permite busca binária. O experimento usa overlap de vetores de estados, não contagem física de shots. Prefixos devem ser acessíveis e a falha reproduzível. 60/60 localizações; 5,6,7 testes para 16,32,64 portas, incluindo confirmação final. O número médio de assinaturas finais distintas foi 15.15/32,27.1/64,51.9/128, evidência de não-identificabilidade da localização só pelo canal completo (erros diferentes podem propagar ao mesmo Pauli). Duas falhas podem cancelar e invalidar a monotonicidade. Literatura de 2023 já descreve diagnóstico por busca binária. Sem novidade demonstrada.

## Referências prioritárias

- Montanaro, *The quantum query complexity of learning multilinear polynomials* (2012): https://arxiv.org/abs/1105.3310
- Montanaro e Shao, *Quantum algorithms for learning a hidden graph and beyond*: https://arxiv.org/abs/2011.08611 (também usa Fourier e amplificação em juntas).
- Arunachalam, Bravyi, Dutt e Yoder, *Optimal algorithms for learning quantum phase states*: https://arxiv.org/abs/2208.07851
- Erginbas et al., *Adaptive Sparse Möbius Transforms for Learning Polynomials* (2026): https://arxiv.org/abs/2602.06246 (oráculo real, distinto de paridade).
- Atici e Servedio, *Quantum Algorithms for Learning and Testing Juntas*: https://www1.cs.columbia.edu/~rocco/papers/qipjunta.html
- Stellar Quorum Analyzer: https://github.com/stellar/stellar-quorum-analyzer
- Mathematical Analysis and Algorithms for Federated Byzantine Agreement Systems: https://arxiv.org/abs/1912.01365
- Diagnosis of Quantum Circuits in the NISQ Era (2023): https://inspirehep.net/literature/2666766
- Graph Collision, problema aberto: https://qiqc-op.com/problem/op_39721600d81c6992/ ; https://arxiv.org/abs/2611.05356
- Parameterized Quantum Query Complexity of Graph Collision: https://arxiv.org/abs/1305.1021
- Reichardt, *Reflections for quantum query algorithms*: https://arxiv.org/abs/1005.1601
- CAP-0063: https://github.com/stellar/stellar-protocol/blob/master/core/cap-0063.md

## Gate científico

Pesquisa de anterioridade não sistemática. Nenhum candidato aprovado como algoritmo inédito publicável. Priorizar verificação formal independente da construção Q02, comparação com métodos esparsos no mesmo modelo de oráculo e recursos de síntese, e busca de resultados prévios sobre códigos/derivadas para tensores booleanos. Manter Q01 como aplicação teórica e B01 como oportunidade de engenharia. Não anunciar vantagem em hardware. O código não contém implementação Qiskit validada; o arquivo original contém construtor de circuito opcional. Não publicar sem revisão independente.
