import sys,itertools,math,json,time,random
from pathlib import Path
import numpy as np
from research import GF, coded_recover, contraction, fwht, quorum, greatest, gate
from scipy.optimize import milp, Bounds, LinearConstraint
sys.path.insert(0,str(Path(__file__).parents[1]))
import qcdt
R=random.Random(92821);N=np.random.default_rng(92821)
def hyper():
 n=5; E=list(itertools.combinations(range(n),3));cnt=0
 for bits in range(1<<len(E)):
  edges={e for i,e in enumerate(E) if bits>>i&1}
  if max(sum(i in e for e in edges) for i in range(n))>2:continue
  got,_,_=coded_recover(n,2,lambda a,b:contraction(edges,a,b));assert got==edges;cnt+=1
 e1={(0,1,2),(0,3,4),(1,3,5),(2,4,5)};e2={(0,1,3),(0,2,4),(1,2,5),(3,4,5)}
 assert all(contraction(e1,63,b)==contraction(e2,63,b) for b in range(64))
 assert all(coded_recover(6,2,lambda a,b:contraction(e,a,b))[0]==e for e in [e1,e2])
 baseline=[]
 for n,d in [(6,2),(9,3),(12,3)]:
  old=[];new=[];oldq=[];newq=[]
  for i in range(5):
   edges=set(); degree=[0]*n;es=list(itertools.combinations(range(n),3));R.shuffle(es)
   for e in es:
    if all(degree[j]<d for j in e):
     edges.add(e)
     for j in e:degree[j]+=1
   f=qcdt.make_truth_table(n,list(edges)+[(),(0,),(1,2)])
   t=time.perf_counter();got,q=qcdt.qcdt(f,n,d,seed=i);old.append(time.perf_counter()-t);oldq.append(q);assert got==edges
   t=time.perf_counter();got,q,_=coded_recover(n,d,lambda a,b:qcdt.derivative_bv(f,a,b));new.append(time.perf_counter()-t);newq.append(q);assert got==edges
  baseline.append(dict(n=n,d=d,cases=5,old_queries=oldq[0],coded_queries=newq[0],old_median_s=float(np.median(old)),coded_median_s=float(np.median(new))))
 return dict(exhaustive_n5_d2=cnt,old_collision_pair_resolved=2,baseline=baseline)
def milp_check(ss,v=None):
 n=len(ss);pairs=[(i,s) for i in range(n) for s in ss[i]];m=len(pairs);D=2*n+2*m; A=[];low=[];high=[]
 def add(items,l=-np.inf,h=np.inf):
  a=np.zeros(D)
  for i,c in items:a[i]+=c
  A.append(a);low.append(l);high.append(h)
 for side in range(2):
  x0=side*n;z0=2*n+side*m;add([(x0+i,1) for i in range(n)],1)
  for i in range(n):add([(x0+i,1)]+[(z0+j,-1) for j,(u,s) in enumerate(pairs) if u==i],h=0)
  for j,(i,s) in enumerate(pairs):
   for k in range(n):
    if s>>k&1:add([(z0+j,1),(x0+k,-1)],h=0)
 for i in range(n):add([(i,1),(n+i,1)],h=1)
 if v is not None:add([(v,1)],1,1)
 out=milp(np.zeros(D),integrality=np.ones(D),bounds=Bounds(np.zeros(D),np.ones(D)),constraints=LinearConstraint(np.array(A),low,high),options={'time_limit':5})
 assert out.status in (0,2),out.message
 return out.status==0

def scp():
 rows=[]
 for n in [6,8,10,12]:
  times=[[],[],[]];bad=0
  for _ in range(12):
   ss=[[1|1<<i|sum(1<<j for j in R.sample(range(n),R.randrange(0,4))) for __ in range(2)] for i in range(n)];v=R.randrange(n);ss[v].append(1<<v);allm=(1<<n)-1
   t=time.perf_counter();b=any(quorum(q,ss) and greatest(allm^q,ss) for q in range(1,1<<n));times[0].append(time.perf_counter()-t)
   for j,w in [(1,None),(2,v)]:
    t=time.perf_counter();got=milp_check(ss,w);times[j].append(time.perf_counter()-t);assert got==b
   bad+=b
  rows.append(dict(n=n,cases=12,agreement=12,unsafe=bad,enumeration_median_ms=float(np.median(times[0])*1e3),milp_median_ms=float(np.median(times[1])*1e3),restricted_milp_median_ms=float(np.median(times[2])*1e3)))
 return rows

def diff():
 rows=[]
 for k in [3,5,6]:
  n=2*k+3;xs=np.arange(1<<n);size=len(xs);p=2**(-k);theta=math.asin(math.sqrt(p));it=round(math.pi/(4*theta)-.5);shots=math.ceil(math.log2(n/.05))*2;budget=2*shots*(it+1);counts=[0,0,0];reps=40
  for _ in range(reps):
   chosen=R.sample(range(n),2*k+1);sel=1<<chosen[0];a=chosen[1:k+1];b=chosen[k+1:];target_support=sum(1<<j for j in chosen);am=sum(1<<i for i in a);bm=sum(1<<i for i in b);at=sum(R.randrange(2)<<i for i in a);bt=sum(R.randrange(2)<<i for i in b);h=((xs&sel==0)&(xs&am==at))|((xs&sel!=0)&(xs&bm==bt));psi=np.ones(size)/np.sqrt(size)
   for __ in range(it):psi[h]*=-1;psi=2*psi.mean()-psi
   good=psi*h;succ=float(good@good);dist=np.abs(fwht(good))**2/succ;plain=np.abs(fwht((1-2*h.astype(float))/np.sqrt(size)))**2
   def union(z):
    r=0
    for x in z:r|=int(x)
    return r
   counts[0]+=union(N.choice(size,budget//2,p=plain/plain.sum()))==target_support
   counts[1]+=union([N.choice(size,p=dist/dist.sum()) for __ in range(shots) if R.random()<succ])==target_support
   seen=0
   for __ in range(budget//(2*(it+1+n))):
    if R.random()<succ:
     x=int(N.choice(xs[h]));seen|=sum((1<<j) for j in range(n) if not h[x^(1<<j)])
   counts[2]+=seen==target_support
  rows.append(dict(k_per_branch=k,n=n,cases=reps,budget=budget,plain=counts[0],amplified=counts[1],grover_witness_repeated=counts[2]))
 return rows

def exhaustive_collision():
 n=5;cnt=0
 # exhaustive single-key roles: 0 absent, 1 read, 2 write, all possible selected sets
 for roles in itertools.product(range(3),repeat=n):
  for mask in range(1<<n):
   a=[i for i in range(n) if mask>>i&1 and roles[i]]
   assert any(roles[i]==2 or roles[j]==2 for i,j in itertools.combinations(a,2))==(len(a)>=2 and any(roles[i]==2 for i in a));cnt+=1
 return cnt
if __name__=='__main__':
 r={}
 for name,fn in [('hyper',hyper),('scp',scp),('diff',diff),('exhaustive_collision',exhaustive_collision)]:
  r[name]=fn();print(name,r[name],flush=True);Path(__file__).with_name('validation.json').write_text(json.dumps(r,indent=2))
