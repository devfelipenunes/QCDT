"""Experimental fallback for missing irreducible-polynomial table entries."""
from functools import lru_cache
import random,json
from pathlib import Path
import previous,weighted,circuit
from round4_reference import contraction
from stress_validation import polynomial_product
Original=previous.CompactField

def mod(a,b):
 while a and a.bit_length()>=b.bit_length():a^=b<<(a.bit_length()-b.bit_length())
 return a

def gcd(a,b):
 while b:a,b=b,mod(a,b)
 return a

@lru_cache(None)
def find_poly(m):
 for p in range((1<<m)|1,1<<(m+1),2):
  x=2;ok=True
  for k in range(1,m+1):
   x=polynomial_product(x,x,p)
   if k<=m//2 and gcd(p,x^2)!=1:ok=False;break
  if ok and x==2:return p
 raise ValueError('no irreducible polynomial')

class ExtendedField(Original):
 def __init__(self,m):
  try:super().__init__(m)
  except KeyError:
   if not 2<=m<=32:raise ValueError('experimental fallback supports 2..32')
   self.m=m;self.q=1<<m;self.mod=self.q-1;self.poly=find_poly(m)
   self.exp=[self.pow(2,i) for i in range(2*m+1)]

def test():
 rng=random.Random(92071);rows=[];arithmetic=0
 for m in (13,15,24,26,32):
  g=ExtendedField(m)
  for _ in range(200):
   a,b=rng.randrange(g.q),rng.randrange(1,g.q)
   assert g.mul(a,b)==polynomial_product(a,b,g.poly) and g.mul(g.div(a,b),b)==a;arithmetic+=1
 previous.CompactField=weighted.CompactField=circuit.CompactField=ExtendedField
 try:
  for n in (2048,4096):
   for j in range(3):
    vs=list(range(n));rng.shuffle(vs);es={tuple(sorted(vs[i:i+3])) for i in range(0,(n//(3*(j+1)))*3,3)};p=lambda a,b:contraction(es,a,b)
    got,q=previous.direct_recover(n,1,p,compact=True);assert got==es;rows.append(dict(n=n,edges=len(es),queries=q,exact=True))
 finally:previous.CompactField=weighted.CompactField=circuit.CompactField=Original
 out=dict(arithmetic=arithmetic,results=rows);Path('extended_field_r8.json').write_text(json.dumps(out,indent=2));print(out)
if __name__=='__main__':test()
