# QCDT — Rodada 8: auditoria científica experimental

Data: 25/11/2026 (Brasília). Pesquisa exploratória, não revisão por pares. Todas as execuções novas abaixo ocorreram em Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, CPU. Sementes fixadas nos scripts antes de suas respectivas execuções; não houve pré-registro externo. As tabelas reportam inclusive falhas. Não existe teste que, isoladamente, certifique a originalidade científica. O modelo usa oráculo de fase coerente, ideal e repetível, U_f|x>=(-1)^f(x)|x>, f booleana de grau <=3; a esparsidade d é o máximo de trios incidentes a uma variável. O modelo clássico usa uma consulta de valor por bit; o oráculo de valor reversível permite uma consulta de fase por kickback. Isso não compara custos físicos, nem acesso clássico ao código do circuito. Dados sintéticos, sem hardware real.

## Reproduzir

```sh
python -m pip install -r requirements_round8.txt
python qcdt_v01.py
python run_circuit.py
python scientific_tests.py exhaustive promise
python scientific_tests.py independent_full
python scientific_tests.py compare
python stress_validation.py
python checked_recovery.py
python field_extension.py
python adaptive.py
OPENBLAS_NUM_THREADS=1 python noise_validation.py
python structural_tests.py
```

A ordem indicada para `scientific_tests.py` usa processos independentes, como nas execuções desta rodada; agrupar os comandos altera a sequência de RNG. Resultados novos em `*_r8.json`, logs em `../logs/`. JSON e logs anteriores presentes como referências. Código com assert internos: executar sem `-O`. A integração externa `qiskit_check.py` permanece não executada; pip não encontrou Qiskit/Aer neste ambiente, tanto em modo local quanto na tentativa padrão. Não afirmar compatibilidade validada. O arquivo example.qasm é um exemplo, não um teste em QPU.

## 1. Correção ideal e reprodução

- v0.1 reproduzida: 50/50, n=9,d=2, 112 consultas.
- v0.6 anterior reproduzida: 17/17 circuitos completos; 120 casos de ruído Pauli reproduzidos com mesmas sementes, não evidência independente.
- Reconstrução exaustiva de todos os 16 hipergrafos n=4 e 1024 hipergrafos n=5, inclusive vazios e densos, d verdadeiro fornecido (mínimo 1). Cada um foi testado por v0.4 e v0.5 usando FWHT de tabela verdade com termos inferiores; 1040/1040 em cada versão. Não são todos os circuitos com termos inferiores arbitrários.
- Verificação independente de 26624 combinações de monômio de grau 0..3 e máscaras a,b em n=5 (26 monômios x 1024 pares). A identidade afim é verificada em todos os 32 pontos. Por linearidade, a identidade vale para toda combinação dos monômios nesse n. Isso não substitui demonstração para n arbitrário.
- 176/176 circuitos completos novos Z,CZ,CCZ: 64 n=3, 64 n=4, 32 n=6, 16 n=8; decodificação por simulação de portas e avaliação de todos os estados de base contra a fase booleana. A ordem de portas e fase global não identificáveis. A fase global foi multiplicada no teste de estados de base, não foi inserida no teste de recuperação.
- 4236 pares de produtos em 16 corpos finitos (graus 2..22 disponíveis) comparados com multiplicação polinomial independente; também testadas distributividade e divisão quando denominador não nulo. 200 testes de canais de ruído de 1 qubit contra matrizes de Kraus/unitárias explícitas.
- Adaptativo: 94/94, reprodução da rodada 6 com as mesmas sementes.

## 2. Baseline clássico esparso novo

Terceira derivada de f em direções a,b,c, avaliada em 0 com oito consultas de valor, é trilinear (termos inferiores cancelam). Se o tensor residual é não nulo, uma amostra de máscaras independentes uniformes resulta em 1 com probabilidade >=1/8 (polinômio multilinear não nulo de grau <=3). Uma vez detectado 1, dividir cada máscara em duas metades, consultar uma metade e conservar a que mantém o resultado 1. Trilinearidade garante existência; após três sequências de divisões, recuperar uma aresta de três índices distintos. Cancelar a aresta encontrada do oráculo residual sem nova consulta física. Parar após ceil(log(delta/(floor(nd/3)+1))/log(7/8)) testes negativos consecutivos. União sobre no máximo floor(nd/3)+1 estágios dá falha <=delta=0.01 sob promessa e oracle ideal. Reutilizar avaliações de valor já consultadas. Este é um baseline construído para auditoria, não reivindicação de novidade ou melhor algoritmo clássico possível. Contagens incluem certificação de término. QCDT recebe d verdadeiro, v0.1 usa delta=.01 e custo planejado; v0.4/5 sem verificações extras. 90 instâncias pareadas; cada método acerta todos os casos em que foi executado. Tempos medidos em CPU incluem simulação por contração e consultas clássicas sintéticas; não comparar com hardware.

| n,d | casos | clássico mediana | v0.1 | v0.4 | v0.5 |
|---|---:|---:|---:|---:|---:|
| 6,1 | 20 | 64 | 76 | 24 | 52 |
| 9,2 | 20 | 344.5 | 112 | 168 | 260 |
| 12,2 | 12 | 623 | 124 | 168 | 260 |
| 16,2 | 10 | 867 | 140 | 244 | 424 |
| 32,2 | 10 | 1677.5 | — | 308 | 528 |
| 64,2 | 8 | 3517.5 | — | 384 | 664 |
| 128,2 | 5 | 7777 | — | 448 | 780 |
| 64,4 | 5 | 6431 | — | 1592 | 1672 |

v0.4: ~17.36x menos chamadas que este baseline em n=128,d=2, mas a baseline clássica tem garantia de parada com erro e a v0.4 tem promessa de d exato. Certificação adicional da v0.4 com 10 sondagens adiciona 40 chamadas e ainda resulta em ~15.94x nesse cenário (projeção, não novo benchmark pareado). Em n=64,d=2 CPU mediana v0.4 ~35 ms vs clássico ~23 ms; n=128,d=2 ~90 ms vs 98 ms, amostra pequena. Não extrapolar. v0.1 é mais econômica em consultas para n=9..16, com custo combinatório. Literatura de aprendizagem clássica esparsa inclui Schapire/Sellie 1996 (membership + equivalence queries) e Bshouty 2023 (aproximação sob distribuição uniforme); os modelos devem ser distinguidos. Não afirmar comparação com o estado da arte inteiro.

## 3. Testes de violação de promessa — defeitos e mitigação

Quando se informa d=1 mas o grau local é maior, v0.4 aceita 165 reconstruções incorretas entre 1013 hipergrafos inválidos n=5; v0.5 rejeita 1013/1013 nesta amostra exaustiva. Verificar apenas sondagens já adquiridas não resolve as 165 colisões. O wrapper `checked_recovery.py` faz validação explícita de parâmetros, tamanho de resposta, grau e consistência e depois 10 sondagens aleatórias novas independentes, 40 consultas extras. Para resíduo cúbico não nulo, alguma matriz de link alternante tem posto >=2; P de detectar diferença >=3/8 por sonda, logo falsa aceitação <=(5/8)^10=0.009095. Essa é garantia sob o modelo ideal e grau <=3, não sob ruído ou polinômios de grau arbitrário. Em uma nova execução exaustiva com sementes próprias: 11/11 válidos aceitos e 1013/1013 inválidos rejeitados em ambas as versões, 5/5 entradas inválidas rejeitadas. Não se prova falsa aceitação zero. Máximo observado de falso passe de uma sonda sobre todos os 15 resíduos cúbicos não nulos n=4: 88/256=0.34375 (limite geral 0.625).

Fora de grau <=3: monômio quártico n=4 produz segunda derivada não afim em 210/256 pares de máscaras, mas 46 pares ainda são afins. Em 200 funções sintéticas com pelo menos um termo quártico n=5, amostrar a distribuição Fourier (sem exigir determinismo) levou ambas versões a rejeitar todos os 200 casos. Não prova detecção universal de grau. Atenção: o cache do experimento quártico compartilha uma medida por máscara entre versões e holdout; não é teste de certificação independente. A verificação ideal não pode detectar fase global. Para contratos públicos, acesso clássico ao código continua mais natural.

## 4. Escala e implementação

22/22 casos novos de contração algébrica v0.4: 6 n=128,d=1 (64 chamadas); 6 n=256,d=2 (576); 5 n=512,d=2 (660); 5 n=1024,d=2 (760); distribuição de graus não saturada e instâncias vazias. Não são estados quânticos simulados em 1024 qubits. n=2048 anteriormente lança KeyError 24. `field_extension.py` encontra polinômios irredutíveis por busca determinística limitada a graus 2..32; 1000 produtos/divisões verificados e 6/6 instâncias de trios disjuntos n=2048 (96 chamadas) e n=4096 (104 chamadas), por contração algébrica. Extensão experimental por substituição temporária de classe, não integrada como produção, busca ingênua não é algoritmo uniforme de multiplicação de posto linear. Mantém-se pendente implementação de decomposição linear.

## 5. Ruído, estatística e segurança da aceitação

Simulação independente por matriz densidade de 5 qubits (verificar hermiticidade, traço e positividade), 60 instâncias uniformes da classe local d=1, incluindo vazio, termos inferiores aleatórios. Mesmos 60 casos reutilizados nas sete condições e três orçamentos aninhados: 1260 observações cenário-orçamento, não 1260 instâncias independentes. Comparação pareada de decodificador algébrico (hard), custo de Hamming sobre contagens brutas e enumeração de todos os 11 candidatos (soft) e soft com três sondagens novas de validação por maioria (holdout). O soft é combinatório e não escalável. Ruído: amortecimento de amplitude por fio tocado após cada porta (gamma); rotação sistemática Rx(theta) por fio tocado após cada porta (theta em radianos, não probabilidade); flip simultâneo de todos os bits por shot (probabilidade), adicional 0.2% flip independente por bit exceto ideal. Não equivalem a dados de calibração. 24 chamadas de fase por shot base, 12 adicionais para holdout, logo 360 vs 540 para 15 shots. Intervalos Wilson 95% e McNemar exato pareado exploratório (sem correção de múltiplas comparações) no JSON; não tratar como confirmação inferencial independente entre condições.

| Modelo (15 shots) | hard certo | soft certo | soft errado | holdout certo | holdout errado |
|---|---:|---:|---:|---:|---:|
| Ideal | 60 | 60 | 0 | 60 | 0 |
| Damping gamma=.005 | 59 | 60 | 0 | 59 | 0 |
| Damping gamma=.02 | 5 | 60 | 0 | 20 | 0 |
| Rx theta=.05 | 50 | 60 | 0 | 52 | 0 |
| Rx theta=.15 | 4 | 21 | 34 | 4 | 0 |
| Flip conjunto p=.05 | 60 | 60 | 0 | 60 | 0 |
| Flip conjunto p=.2 | 59 | 60 | 0 | 60 | 0 |

No erro coerente forte, aumentar shots de 1 para 15 aumenta aceitações incorretas soft de 27/60 para 34/60, indicando erro sistemático não mitigado por repetição. Verificador não aceita nenhuma errada nos cenários testados, mas rejeita 56/60 nessa condição, incluindo 17 resultados inicialmente corretos do soft. 60/60 tem IC Wilson 95% [93.98%,100%]; 0/60 falhas tem IC superior ~6.02%. 21/60 tem IC [24.17%,47.64%]; 4/60 [2.62%,15.93%]. Não prometer robustez certificada, falsos negativos/positivos sob ruído real continuam abertos. Em gamma=.02 15 shots, soft vs hard McNemar p=5.55e-17 (exploratório, não corrigido); soft+holdout paga custo maior e tem recuperação baixa. O simulador de portas Pauli anterior foi reproduzido, não considerado amostra nova.

## 6. Revisão científica e gate

As provas candidatas dos limites das rodadas anteriores permanecem condicionadas a modelo de oráculo, promessa e construção de multiplicação de posto linear; testes não provam originalidade. O método novo de validação e extensão de campo melhora a confiabilidade do protótipo, não comprova inovação fundamental. Literatura próxima: Montanaro 2012 https://arxiv.org/abs/1105.3310 ; Montanaro/Shao https://arxiv.org/abs/2011.08611 ; Arunachalam et al. https://arxiv.org/abs/2208.07851 ; aprendizado clássico esparso https://arxiv.org/abs/0805.1765 ; Bshouty https://doi.org/10.4230/LIPIcs.STACS.2023.16 ; Schapire/Sellie https://collaborate.princeton.edu/en/publications/learning-sparse-multivariate-polynomials-over-a-field-with-querie-2/ ; modelos de ruído https://quantum.cloud.ibm.com/docs/en/qiskit/build-noise-models .

Gate: aprovado para investigação em modelo ideal, reprovado para alegação de robustez geral ou vantagem física. Pendências: Qiskit/Aer real, QPU e oráculo opaco físico, teste de ruído com calibração, decodificador robusto polinomial, revisão de anterioridade sistemática, comparação com implementações publicadas no mesmo modelo, revisão por pesquisador independente, prova/implementação uniforme de posto linear, análise de roteamento/depth/latência real. Graph Collision permanece secundário; nenhum teste novo nessa linha. Não foi iniciada automação nem publicado artigo. Não confundir validação interna com revisão por pares.
