"""Checked wrapper for an ideal, repeatable degree<=3 oracle. Not a guarantee under noise or arbitrary functions."""
import random,math,itertools as it,json
from pathlib import Path
from previous import direct_recover
from weighted import recover as weighted
from round4_reference import contraction
from scientific_tests import E

def checked_recover(n,d,probe,rng,delta=.01,version='v04'):
    if n<3 or not 1<=d<=math.comb(n-1,2):raise ValueError('invalid dimensions or bound')
    if not 0<delta<1:raise ValueError('invalid failure tolerance')
    if version not in ['v04','v05']:raise ValueError('invalid version')
    cache={};calls=0
    def q(a,b):
        nonlocal calls
        key=tuple(sorted((a,b)))
        if key not in cache:
            word=probe(*key);calls+=4
            if not isinstance(word,int) or not 0<=word<1<<n:raise ValueError('malformed probe result')
            cache[key]=word
        return cache[key]
    try:es,_=(direct_recover(n,d,q,compact=True) if version=='v04' else weighted(n,d,q))
    except E as exc:raise ValueError('decoder rejected') from exc
    if any(sum(i in e for e in es)>d for i in range(n)):raise ValueError('degree bound violated')
    if any(contraction(es,a,b)!=v for (a,b),v in cache.items()):raise ValueError('inconsistent acquired probes')
    r=math.ceil(math.log(delta)/math.log(5/8))
    for _ in range(r):
        a,b=rng.getrandbits(n),rng.getrandbits(n)
        # Always use fresh executions, not cached measurements, with independently chosen masks.
        calls+=4
        if probe(a,b)!=contraction(es,a,b):raise ValueError('failed independent certification')
    return es,calls

def test():
    n=5;edges=list(it.combinations(range(n),3));rng=random.Random(882277);rows={x:dict(valid=0,wrong=0,rejected=0,cache_only_wrong=0,cache_only_rejected=0) for x in ['v04','v05']}
    for code in range(1<<len(edges)):
        es={e for i,e in enumerate(edges) if code>>i&1};valid=max(sum(i in e for e in es) for i in range(n))<=1
        p=lambda a,b:contraction(es,a,b)
        for name,fn in [('v04',lambda q:direct_recover(n,1,q,compact=True)),('v05',lambda q:weighted(n,1,q))]:
            cache={}
            def q(a,b):return cache.setdefault((a,b),p(a,b))
            try:
                got,_=fn(q);bad=any(contraction(got,a,b)!=v for (a,b),v in cache.items())
                if bad:rows[name]['cache_only_rejected']+=1
                elif not valid and got!=es:rows[name]['cache_only_wrong']+=1
            except E:rows[name]['cache_only_rejected']+=1
            try:
                got,_=checked_recover(n,1,p,rng,version=name)
                if not valid or got!=es:rows[name]['wrong']+=1
                else:rows[name]['valid']+=1
            except ValueError:
                assert not valid
                rows[name]['rejected']+=1
    # Malformed inputs must reject explicitly, independently of assert optimization.
    bad=0
    for n,d,delta in [(2,1,.01),(5,0,.01),(5,7,.01),(5,1,0),(5,1,1)]:
        try:checked_recover(n,d,lambda a,b:0,rng,delta)
        except ValueError:bad+=1
    assert bad==5
    out=dict(total=1024,valid=11,invalid=1013,results=rows,input_validation=bad,holdout_probes=math.ceil(math.log(.01)/math.log(5/8)))
    print(out);Path('checked_r8.json').write_text(json.dumps(out,indent=2))
if __name__=='__main__':test()
