"""Promise violations, random certification and independent finite-field arithmetic."""
import numpy as np,random,itertools as it,json,math,time
from pathlib import Path
from previous import CompactField,direct_recover
from weighted import recover as weighted
from round4_reference import contraction,fwht
from adaptive import adaptive
from scientific_tests import tm,truth,E,independent_contraction
R=random.Random(629888);N=np.random.default_rng(629888)
def polynomial_product(a,b,p):
 z=0
 for j in range(b.bit_length()):
  if b>>j&1:z^=a<<j
 while z.bit_length()>=p.bit_length():z^=p<<(z.bit_length()-p.bit_length())
 return z

def fields():
 checks=0;out=[]
 for m in [2,3,4,5,6,7,8,9,10,11,12,14,16,18,20,22]:
  g=CompactField(m)
  pairs=list(it.product(range(g.q),repeat=2)) if m<=4 else [(R.randrange(g.q),R.randrange(g.q)) for _ in range(300)]
  for a,b in pairs:
   c=R.randrange(g.q);assert g.mul(a,b)==polynomial_product(a,b,g.poly)
   assert g.mul(a,b^c)==g.mul(a,b)^g.mul(a,c)
   if b:assert g.mul(g.div(a,b),b)==a
  checks+=len(pairs);out.append(dict(m=m,pairs=len(pairs)))
 return dict(pairs=checks,fields=out)
def under_bound():
 n=5;edges=list(it.combinations(range(n),3));rows={x:dict(exact=0,wrong=0,rejected=0,wrong_passed_holdout=0) for x in ['v04','v05']};total=0
 for code in range(1<<len(edges)):
  es={e for i,e in enumerate(edges) if code>>i&1}
  if max(sum(i in e for e in es) for i in range(n))<=1:continue
  total+=1;p=lambda a,b:contraction(es,a,b);masks=[(R.getrandbits(n),R.getrandbits(n)) for _ in range(8)]
  for key,fn in [('v04',lambda:direct_recover(n,1,p,compact=True)),('v05',lambda:weighted(n,1,p))]:
   try:got,_=fn()
   except E:rows[key]['rejected']+=1;continue
   status='exact' if got==es else 'wrong';rows[key][status]+=1
   if status=='wrong' and all(p(a,b)==contraction(got,a,b) for a,b in masks):rows[key]['wrong_passed_holdout']+=1
 return dict(total=total,results=rows)
def quartic():
 n=5;total=200;rows={x:dict(rejected=0,accepted_incorrect_unitary=0,accepted_after_holdout=0) for x in ['v04','v05']}
 for _ in range(total):
  pool=[e for k in range(1,5) for e in it.combinations(range(n),k)];terms={tm(e) for e in pool if R.random()<.15};terms.add(tm(R.sample(range(n),4)));tt=truth(n,terms);xs=np.arange(len(tt));cache={}
  def p(a,b):
   key=tuple(sorted([a,b]))
   if key not in cache:
    state=fwht((1-2*(tt^tt[xs^a]^tt[xs^b]^tt[xs^a^b]).astype(float))/np.sqrt(len(tt)));pr=abs(state)**2;cache[key]=int(N.choice(len(tt),p=pr/pr.sum()))
   return cache[key]
  hs=[(R.getrandbits(n),R.getrandbits(n)) for _ in range(8)]
  for key,fn in [('v04',lambda:direct_recover(n,2,p,compact=True)),('v05',lambda:weighted(n,2,p))]:
   try:got,_=fn()
   except E:rows[key]['rejected']+=1;continue
   rows[key]['accepted_incorrect_unitary']+=1 # quartic term is present; cubic model cannot match.
   if all(p(a,b)==contraction(got,a,b) for a,b in hs):rows[key]['accepted_after_holdout']+=1
 return dict(total=total,results=rows)
def large():
 rows=[]
 for n,d,reps in [(128,1,6),(256,2,6),(512,2,5),(1024,2,5)]:
  for j in range(reps):
   # Non-saturated, random uneven degree profile; include isolated vertices and empty instance.
   es=set();deg=[0]*n
   for _ in range(0 if j==0 else n*(1+j%3)):
    e=tuple(sorted(R.sample(range(n),3)))
    if e not in es and all(deg[i]<d for i in e):
     es.add(e)
     for i in e:deg[i]+=1
   p=lambda a,b:contraction(es,a,b)
   start=time.perf_counter();got,q=direct_recover(n,d,p,compact=True);assert got==es
   rows.append(dict(n=n,d=d,j=j,edges=len(es),calls=q,seconds=time.perf_counter()-start))
  print('large',n,d,reps,flush=True)
 try:direct_recover(2048,1,lambda a,b:0,compact=True);limit='unexpected support'
 except KeyError as ex:limit=f'KeyError {ex}'
 return dict(rows=rows,unsupported_2048=limit)
if __name__=='__main__':
 import sys
 for name in sys.argv[1:] or ['fields','under_bound','quartic','large']:
  res=globals()[name]();Path(name+'_r8.json').write_text(json.dumps(res,indent=2));print(name,res if name!='large' else res['unsupported_2048'],flush=True)
