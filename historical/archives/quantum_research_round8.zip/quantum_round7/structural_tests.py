"""Independent monomial-basis identity and channel checks."""
import itertools as it,json
import numpy as np
from pathlib import Path
from scientific_tests import tm,truth
from round4_reference import contraction
from noise_validation import Density

def run():
 n=5;ids=np.arange(1<<n);cases=0
 for k in range(4):
  for e in it.combinations(range(n),k):
   tt=truth(n,{tm(e)});es={e} if k==3 else set()
   for a,b in it.product(range(1<<n),repeat=2):
    w=tt^tt[ids^a]^tt[ids^b]^tt[ids^a^b];s=contraction(es,a,b);expected=np.array([int(x&s).bit_count()&1 for x in ids],dtype=np.uint8)^w[0];assert np.array_equal(w,expected);cases+=1
 sim=Density(1);rng=np.random.default_rng(543);checks=0
 for p in (0,.005,.02,.2,1):
  for _ in range(20):
   z=rng.normal(size=(2,2))+1j*rng.normal(size=(2,2));r=z@z.conj().T;r/=np.trace(r)
   K0=np.diag([1,np.sqrt(1-p)]);K1=np.array([[0,np.sqrt(p)],[0,0]]);expected=K0@r@K0.conj().T+K1@r@K1.conj().T;assert np.allclose(sim.channel(r.copy(),0,'damping',p),expected)
   U=np.cos(p/2)*np.eye(2)-1j*np.sin(p/2)*np.array([[0,1],[1,0]]);assert np.allclose(sim.channel(r.copy(),0,'coherent_rx',p),U@r@U.conj().T);checks+=2
 out=dict(monomial_direction_cases=cases,noise_channel_checks=checks);Path('structural_r8.json').write_text(json.dumps(out,indent=2));print(out)
if __name__=='__main__':run()
