"""Round 8 preregistered fixed seeds; independent oracle truth table and classical baseline."""
import itertools as it, math, random, time, json, statistics as st
from pathlib import Path
import numpy as np
from previous import direct_recover, CompactField, random_hypergraph
from weighted import recover as weighted
from qcdt_v01 import recover as random_decode, num_probes, derivative_bv
from circuit import Simulator, oracle_gates, derivative, learn_unitary
from adaptive import adaptive
R=random.Random(20261126)
E=(ValueError,AssertionError,KeyError,ZeroDivisionError,IndexError)

def tm(e):return sum(1<<i for i in e)
def value(terms,x):return sum(x&m==m for m in terms)&1

def truth(n,terms):
    x=np.arange(1<<n,dtype=np.uint64);v=np.zeros(len(x),np.uint8)
    for m in terms:v^=(x&m==m)
    return v

def classical_sparse(n,d,oracle,rng,delta=.01):
    # Third Boolean derivative is a trilinear tensor; binary-split a nonzero contraction.
    # A nonzero trilinear form on independent uniform masks is nonzero with probability >=1/8.
    # Union bound over at most floor(nd/3)+1 runs of all-negative tests.
    max_edges=n*d//3;checks=math.ceil(math.log(delta/(max_edges+1))/math.log(7/8));cache={};es=set();calls=0
    def query(x):
        nonlocal calls
        if x not in cache:cache[x]=oracle(x);calls+=1
        return cache[x]
    def residual(x):return query(x)^value(es,x)
    def p(a,b,c):return residual(0)^residual(a)^residual(b)^residual(c)^residual(a^b)^residual(a^c)^residual(b^c)^residual(a^b^c)
    for _ in range(max_edges+1):
        found=False
        for _ in range(checks):
            ds=[rng.getrandbits(n) for _ in range(3)]
            if p(*ds):found=True;break
        if not found:return {tuple(i for i in range(n) if x>>i&1) for x in es},calls
        for j in range(3):
            while ds[j].bit_count()>1:
                bits=[i for i in range(n) if ds[j]>>i&1];lo=sum(1<<i for i in bits[:len(bits)//2]);hi=ds[j]^lo;ds[j]=lo
                if not p(*ds):ds[j]=hi
        assert len(set(ds))==3 and p(*ds)==1
        e=ds[0]|ds[1]|ds[2];assert e not in es;es.add(e)
    raise ValueError('promise violated')

def independent_contraction(terms,a,b):
    # Analytic independent evaluation of the four-point finite difference at 0 and e_i.
    def z(x):return value(terms,x)^value(terms,x^a)^value(terms,x^b)^value(terms,x^a^b)
    c=z(0);return sum((z(1<<i)^c)<<i for i in range(max(1, max((m.bit_length() for m in terms),default=0))))

def exhaustive():
    results=[]
    for n in [4,5]:
        edges=list(it.combinations(range(n),3));count=0;qc=[0,0];start=time.perf_counter()
        for code in range(1<<len(edges)):
            es={e for i,e in enumerate(edges) if code>>i&1};d=max(1,max(sum(i in e for e in es) for i in range(n)))
            terms={tm(e) for e in es}|{0,1,3};tt=truth(n,terms);p=lambda a,b:derivative_bv(tt,a,b)
            for j,fn in enumerate([lambda:direct_recover(n,d,p,compact=True),lambda:weighted(n,d,p)]):
                got,q=fn();assert got==es,(n,code,j);qc[j]+=q
            count+=1
        row=dict(n=n,all_hypergraphs=count,correct_both=count,queries_sum=qc,seconds=time.perf_counter()-start);results.append(row);print('exhaustive',row,flush=True)
    return results

def independent_full():
    rows=[]
    for n,trials in [(3,64),(4,64),(6,32),(8,16)]:
        sim=Simulator(n);pool=[e for k in range(1,4) for e in it.combinations(range(n),k)];out=0
        for _ in range(trials):
            es={e for e in pool if R.random()<.22};d2=max(1,max(sum(len(e)==2 and i in e for e in es) for i in range(n)));d3=max(1,max(sum(len(e)==3 and i in e for e in es) for i in range(n)))
            gates=oracle_gates(es);count=[0];phase=R.choice([1,-1,1j,-1j])
            def p(ds,known):
                gs=derivative(n,gates+oracle_gates(known),ds);count[0]+=len(gs);return sim.run(gs)
            got,q=learn_unitary(n,d3,d2,p);assert got==es
            # Compare full effective diagonal independently by evaluating each basis state; global phase normalized.
            for x in range(1<<n):
                s=np.zeros(1<<n,complex);s[x]=phase
                for g in gates:sim.apply(s,g)
                expected=phase*(-1)**value({tm(e) for e in got},x);assert abs(s[x]-expected)<1e-8 and abs(np.linalg.norm(s)-1)<1e-8
            out+=1
        row=dict(n=n,trials=trials,exact=out);rows.append(row);print('full',row,flush=True)
    return rows

def compare():
    from round4_reference import contraction
    rows=[]
    for n,d,reps in [(6,1,20),(9,2,20),(12,2,12),(16,2,10),(32,2,10),(64,2,8),(128,2,5),(64,4,5)]:
        samples=[]
        for trial in range(reps):
            es=random_hypergraph(n,d,R);terms={tm(e) for e in es}|{0,1,3};p=lambda a,b:contraction(es,a,b)
            # Cross-check 5 random probes independently using value oracle; not an actual quantum execution.
            for _ in range(5):
                a,b=R.getrandbits(n),R.getrandbits(n);assert p(a,b)==independent_contraction(terms,a,b)
            item={}
            t=time.perf_counter();c,cq=classical_sparse(n,d,lambda x:value(terms,x),R);item['classical']=[int(c==es),cq,time.perf_counter()-t]
            for name,fn in [('v04',lambda:direct_recover(n,d,p,compact=True)),('v05',lambda:weighted(n,d,p))]:
                t=time.perf_counter();got,q=fn();item[name]=[int(got==es),q,time.perf_counter()-t]
            if n<=16:
                t=time.perf_counter();tq=num_probes(n,d);m=[(R.getrandbits(n),R.getrandbits(n)) for _ in range(tq)]
                try:got=random_decode(n,d,m,[p(a,b) for a,b in m]);ok=got==es
                except E:ok=False
                item['v01']=[int(ok),4*tq,time.perf_counter()-t]
            samples.append(item)
        row=dict(n=n,d=d,reps=reps,methods={m:dict(exact=sum(x[m][0] for x in samples),median_calls=st.median(x[m][1] for x in samples),median_seconds=st.median(x[m][2] for x in samples)) for m in samples[0]},raw=samples);rows.append(row);print('compare',n,d,row['methods'],flush=True)
    return rows

def promise():
    n=4;tt=truth(n,{15});bad=0;ps=[]
    for a,b in it.product(range(1<<n),repeat=2):
        try:derivative_bv(tt,a,b)
        except ValueError:bad+=1
    from round4_reference import contraction
    # Max full-vector false-accept rate over all nonzero cubic residuals n=4.
    edges=list(it.combinations(range(4),3));rates=[]
    for code in range(1,16):
        es={e for j,e in enumerate(edges) if code>>j&1};rates.append(sum(contraction(es,a,b)==0 for a,b in it.product(range(16),repeat=2))/256)
    return dict(quartic_nonaffine_probes=bad,total_probes=256,max_false_pass_n4=max(rates),theory_bound=.625)

def main():
    out={}
    import sys
    for name in sys.argv[1:] or ['exhaustive','independent_full','compare','promise']:
        out[name]=globals()[name]();Path(f'{name}_r8.json').write_text(json.dumps(out[name],indent=2));print(name,'DONE',flush=True)
if __name__=='__main__':main()
