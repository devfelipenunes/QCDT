"""Exploratory quantum-algorithm screening, not proof of novelty or hardware speedup.
Run alongside qcdt.py: python quantum_research.py > quantum_results.json
Requires numpy. Fixed RNG seed; all quantum experiments are ideal statevectors,
except explicitly labeled synthetic independent measurement bit flips.
"""
import json, itertools, math
import numpy as np
from qcdt import make_truth_table, derivative_bv, recover, num_probes, pair_signature
RNG = np.random.default_rng(20261125)

def random_matching(n):
    p = RNG.permutation(n)
    return {tuple(sorted(map(int,p[i:i+3]))) for i in range(0,n-2,3)}

def lower(n):
    return [t for k in range(3) for t in itertools.combinations(range(n),k) if RNG.integers(2)]

def cube(x):
    def mul(a,b):
        r=0
        while b:
            if b&1: r^=a
            a<<=1; b>>=1
        return r
    return mul(mul(x,x),x)

def coded_probes(n):
    k=(n-1).bit_length()
    labels=[i | (cube(i)<<k) for i in range(n)]
    pairs={}
    for i,j in itertools.combinations(range(n),2):
        sig=labels[i]^labels[j]
        assert sig and sig not in pairs
        pairs[sig]=(i,j)
    bits=[b for b in range(max(labels).bit_length()) if any(l>>b&1 for l in labels)]
    probes=[((1<<n)-1,sum(((l>>b)&1)<<i for i,l in enumerate(labels))) for b in bits]
    return labels,pairs,bits,probes

def decode_matching(n,pairs,bits,words):
    edges=set()
    for i in range(n):
        sig=sum(((w>>i)&1)<<b for b,w in zip(bits,words))
        if sig:
            p=pairs[sig]
            if i in p: raise ValueError('invalid local pair')
            edges.add(tuple(sorted((i,*p))))
    if len({i for t in edges for i in t}) != 3*len(edges): raise ValueError('overlap')
    return edges

def coded_test():
    results=[]
    for n in (6,9,12):
        labels,pairs,bits,probes=coded_probes(n)
        t=num_probes(n,1); ok=old=0
        for _ in range(20):
            e=random_matching(n)
            f=make_truth_table(n,list(e)+lower(n))
            w=[derivative_bv(f,a,b) for a,b in probes]
            ok+=decode_matching(n,pairs,bits,w)==e
            p=[tuple(map(int,x)) for x in RNG.integers(0,1<<n,size=(t,2))]
            try: old+=recover(n,1,p,[derivative_bv(f,a,b) for a,b in p])==e
            except ValueError: pass
        results.append(dict(n=n,trials=20,coded_success=ok,random_success=old,coded_phase_calls=4*len(probes),random_phase_calls=4*t))
    # Exact collision: two distinct 3-uniform hypergraphs with identical pair parity.
    e1=[(0,1,2),(0,3,4),(1,3,5),(2,4,5)]
    e2=[(0,1,3),(0,2,4),(1,2,5),(3,4,5)]
    f,g=(make_truth_table(6,e) for e in (e1,e2))
    collision=all(derivative_bv(f,63,b)==derivative_bv(g,63,b) for b in range(64))
    assert collision
    return dict(results=results,fixed_direction_collision=collision,collision_edges=[e1,e2])

def spectrum(f):
    s=(1.-2.*f)/np.sqrt(len(f)); h=1
    while h<len(s):
        v=s.reshape(-1,2*h); a,b=v[:,:h].copy(),v[:,h:].copy()
        v[:,:h]=(a+b)/np.sqrt(2); v[:,h:]=(a-b)/np.sqrt(2); h*=2
    p=s*s; return p/p.sum()

def drift_test():
    n=12; x=np.arange(1<<n); trials=100
    rows=[]
    for shots in (4,8,16,32):
        qok=cok=sok=0
        for _ in range(trials):
            a,b,c,d=map(int,RNG.choice(n,4,replace=False)); support={a,b,c,d}
            f=make_truth_table(n,lower(n)); g=f^make_truth_table(n,[(a,b),(c,d)])
            delta=f^g
            # Each Fourier shot costs one phase query to f and one to g.
            observed=RNG.choice(len(x),shots,p=spectrum(delta)); union=int(np.bitwise_or.reduce(observed))
            qok+={i for i in range(n) if union>>i&1}==support
            # Budget-matched classical baseline: one shared x per round and n flips;
            # use remaining evaluations for a partial round. Two function calls per delta evaluation.
            found=set(); remaining=shots
            while remaining>=2:
                z=int(RNG.integers(len(x))); remaining-=1
                for i in RNG.permutation(n)[:min(n,remaining)]:
                    i=int(i); remaining-=1
                    if delta[z]!=delta[z^(1<<i)]: found.add(i)
            cok+=found==support
            # Structure-aware classical comparison: D_all(delta) is affine with
            # support of size 4 for this promised matching. Budget counts offset.
            full=(1<<n)-1; offset=int(delta[0]^delta[full]); m=max(0,shots//2-1)
            masks=list(map(int,RNG.integers(0,1<<n,size=m)))
            observed=[int(delta[z]^delta[z^full])^offset for z in masks]
            matches=[set(c) for c in itertools.combinations(range(n),4)
                     if all((sum((z>>i)&1 for i in c)%2)==v for z,v in zip(masks,observed))]
            sok+=len(matches)==1 and matches[0]==support
        rows.append(dict(n=n,trials=trials,original_function_calls=2*shots,fourier_exact=qok,coordinate_exact=cok,structured_parity_exact=sok))
    return rows

def noise_test():
    n=9; t=24; trials=60; rows=[]
    for p in (0,.02,.05,.10):
        exact=nearest=0
        for _ in range(trials):
            edges=random_matching(n); f=make_truth_table(n,list(edges)+lower(n))
            probes=[tuple(map(int,v)) for v in RNG.integers(0,1<<n,size=(t,2))]
            w=[derivative_bv(f,a,b) for a,b in probes]
            w=[v ^ sum(int(z)<<i for i,z in enumerate(RNG.random(n)<p)) for v in w]
            try: exact+=recover(n,1,probes,w)==edges
            except ValueError: pass
            got=set(); valid=True
            for i in range(n):
                target=sum(((v>>i)&1)<<j for j,v in enumerate(w))
                candidates=[(target.bit_count(),())]+[((target^pair_signature(a,b,probes)).bit_count(),(a,b)) for a,b in itertools.combinations([j for j in range(n) if j!=i],2)]
                candidates.sort()
                if candidates[0][0]==candidates[1][0]: valid=False; break
                if candidates[0][1]: got.add(tuple(sorted((i,*candidates[0][1]))))
            # Enforce consistency across all three endpoints, including empty decisions.
            if valid and len({i for e in got for i in e})==3*len(got):
                # A missing local decision can create a false edge; verify all endpoints independently.
                for e in got:
                    for i in e:
                        target=sum(((v>>i)&1)<<j for j,v in enumerate(w)); pair=tuple(j for j in e if j!=i)
                        dist=(target^pair_signature(*pair,probes)).bit_count()
                        opts=[target.bit_count()]+[(target^pair_signature(a,b,probes)).bit_count() for a,b in itertools.combinations([j for j in range(n) if j!=i],2)]
                        if dist!=min(opts): valid=False
                nearest+=valid and got==edges
        rows.append(dict(n=n,trials=trials,phase_calls=4*t,synthetic_bit_flip_probability=p,exact_decoder=exact,nearest_decoder=nearest))
    return rows

if __name__=='__main__':
    print(json.dumps(dict(coded_matching=coded_test(),differential_fourier=drift_test(),noise=noise_test()),indent=2))
