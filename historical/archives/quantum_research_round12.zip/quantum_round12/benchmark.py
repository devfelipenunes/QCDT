import json, math, time
from pathlib import Path
import numpy as np
from asymmetric import *
from codegree import linear,star,codegree,p_for,draw
from robust import generate,observations
from previous import direct_recover
from shadow import shadow_probe,infer_shadow,contraction
from pruning import infer_unresolved
from certification import holdout_size,verify
PASCH=[{(0,1,2),(0,3,4),(1,3,5),(2,4,5)},{(0,1,3),(0,2,4),(1,2,5),(3,4,5)}]
def status(C,E):return 'exact' if C==E else 'rejected' if C is None else 'wrong'
def certified(C,E,n,eta,rng):
    if C is None:return None,0
    M=holdout_size(n,eta,.005);A=rng.random((M,n))<.5;B=rng.random((M,n))<.5;Y=contraction(A,B,E)^(rng.random((M,n))<eta)
    return (C if verify(C,A,B,Y,eta) else None),4*M
def new(E,n,d,lam,eta,rng,actual=None):
    P=cap_probes(n,d,lam);r=repetitions(n,P,eta,.005);p=Probe(n,actual or (lambda a,b:contract(E,a,b)),eta,r,rng)
    t=time.perf_counter();C,extra=recover(n,d,lam,p);dt=time.perf_counter()-t;R,cq=certified(C,E,n,eta,rng)
    assert p.calls<=4*r*P
    return dict(result=status(C,E),certified=status(R,E),calls=p.calls,holdout=cq,shots=r,seconds=dt,**extra)
def old(E,n,d,lam,eta,rng,budget=None):
    full1=math.ceil(384*d*math.log2(n)/(1-2*eta)**2);full2=math.ceil(384*(d+lam**2)*math.log2(n)/(1-2*eta)**2)
    M1=full1 if budget is None else max(1,int(budget*full1/(full1+full2)))
    M2=full2 if budget is None else max(1,budget-M1)
    t=time.perf_counter();B,Y=shadow_probe(n,d,M1,E,eta,rng);N=infer_shadow(B,Y,d,eta);C=None;used=M1
    if N is not None:
        r=propagate(N,d,lam)
        if r is not None:
            F,U=r
            if not U:C=F
            else:
                A,B=draw(n,M2,p_for(d,lam),rng);Y=observations(A,B,E,rng,eta);C=infer_unresolved(A,B,Y,F,U);used+=M2
            if C is not None:
                try:validate(C,n,d,lam)
                except Reject:C=None
                if C is not None and shadow(C,n)!=N:C=None
    dt=time.perf_counter()-t;R,cq=certified(C,E,n,eta,rng)
    return dict(result=status(C,E),certified=status(R,E),calls=4*used,holdout=cq,seconds=dt)
def algebraic(E,n,d,lam,eta,rng):
    _,q=direct_recover(n,d,lambda a,b:0,compact=True);r=repetitions(n,q//4,eta,.005);p=Probe(n,lambda a,b:contract(E,a,b),eta,r,rng)
    t=time.perf_counter()
    try:C,_=direct_recover(n,d,p,compact=True);validate(C,n,d,lam)
    except (AssertionError,ValueError,KeyError,ZeroDivisionError,IndexError):C=None
    dt=time.perf_counter()-t;R,cq=certified(C,E,n,eta,rng)
    return dict(result=status(C,E),certified=status(R,E),calls=p.calls,holdout=cq,shots=r,seconds=dt)
def run():
    rng=np.random.default_rng(2026112612);rows=[]
    for fam,n,d,lam,T in [('pasch',6,2,1,10),('linear',24,4,1,8),('linear',64,4,1,6),('linear',128,2,1,4),('star',32,6,6,4),('random',32,4,4,4),('random',64,2,2,4)]:
        Es=[PASCH[i%2] if fam=='pasch' else {'linear':linear,'star':star,'random':generate}[fam](n,d,rng) for i in range(T)]
        for eta in (0,.15,.25):
            cases=[]
            for E in Es:
                a=new(E,n,d,lam,eta,rng);b=old(E,n,d,lam,eta,rng);c=old(E,n,d,lam,eta,rng,max(2,a['calls']//4));z=algebraic(E,n,d,lam,eta,rng)
                cases.append(dict(edges=len(E),codegree=codegree(E),new=a,old=b,matched=c,algebraic=z))
            rows.append(dict(family=fam,n=n,d=d,lam=lam,eta=eta,cases=cases))
            print(fam,n,d,eta,[(key,sum(x[key]['certified']=='exact' for x in cases),float(np.median([x[key]['calls'] for x in cases]))) for key in ('new','old','matched','algebraic')],flush=True)
            Path(__file__).with_name('results.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':run()
