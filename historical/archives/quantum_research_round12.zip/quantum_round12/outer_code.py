"""Binary simplex outer code for syndrome acquisition. No hardware claim."""
import math,json,time
from pathlib import Path
from functools import lru_cache
import numpy as np
from scipy.stats import binom
from asymmetric import *
from benchmark import new, certified, status, PASCH
from codegree import linear,star
from robust import generate

@lru_cache(None)
def block_plan(width,n,P,eta,delta):
    plans={}
    for k in range(1,min(width,6)+1):
        D=1<<(k-1);r=1
        while n*P*((1<<k)-1)*binom.sf(math.ceil(r*D/2)-1,r*D,eta)>delta:r+=1
        plans[k]=(r,((1<<k)-1)*r)
    dp=[(0,[])]+[(math.inf,[])]*width
    for i in range(1,width+1):
        for k,(r,cost) in plans.items():
            if k<=i and dp[i-k][0]+cost<dp[i][0]:dp[i]=(dp[i-k][0]+cost,dp[i-k][1]+[(k,r)])
    return tuple(dp[width][1])
@lru_cache(None)
def codebook(k):return np.array([[(x&c).bit_count()&1 for c in range(1,1<<k)] for x in range(1<<k)],np.int32)
class OuterProbe:
    def __init__(self,n,fn,eta,P,delta,rng):self.n=n;self.fn=fn;self.eta=eta;self.P=P;self.delta=delta;self.rng=rng;self.calls=0;self.blocks=[]
    def block_acquire(self,a,bs):
        out=[];off=0
        for k,r in block_plan(len(bs),self.n,self.P,self.eta,self.delta):
            self.blocks.append((k,r));B=bs[off:off+k];off+=k;counts=[]
            for c in range(1,1<<k):
                b=0
                for j,v in enumerate(B):
                    if c>>j&1:b^=v
                if not a or not b or a==b:ones=np.zeros(self.n,np.int32)
                else:
                    y=self.fn(a,b);bit=np.fromiter((y>>i&1 for i in range(self.n)),dtype=np.int32,count=self.n);flip=self.rng.binomial(r,self.eta,self.n).astype(np.int32);ones=np.where(bit,r-flip,flip);self.calls+=4*r
                counts.append(ones)
            counts=np.asarray(counts);score=codebook(k)@(r-2*counts);idx=score.argmin(0)
            if np.any((score==score.min(0)).sum(0)>1):raise Reject('outer code tie')
            for j in range(k):out.append(pack(np.flatnonzero(idx>>j&1)))
        return out

def outer(E,n,d,lam,eta,rng):
    P=cap_probes(n,d,lam);p=OuterProbe(n,lambda a,b:contract(E,a,b),eta,P,.005,rng);t=time.perf_counter();C,extra=recover(n,d,lam,p);dt=time.perf_counter()-t;R,cq=certified(C,E,n,eta,rng)
    return dict(result=status(C,E),certified=status(R,E),calls=p.calls,holdout=cq,seconds=dt,blocks=p.blocks,**extra)

def run():
    rng=np.random.default_rng(2026112614);rows=[];checks=0
    for k in range(1,7):
        C=codebook(k)
        for i in range(len(C)):
            assert all(np.sum(C[i]!=C[j])==1<<(k-1) for j in range(i));checks+=i
    print('code distances',checks,flush=True)
    for fam,n,d,lam,T in [('pasch',6,2,1,8),('linear',32,4,1,8),('linear',128,2,1,6),('star',24,4,4,4),('random',32,2,2,6)]:
        es=[PASCH[j%2] if fam=='pasch' else {'linear':linear,'star':star,'random':generate}[fam](n,d,rng) for j in range(T)]
        for eta in (.15,.25):
            cases=[]
            for E in es:cases.append(dict(repetition=new(E,n,d,lam,eta,rng),outer=outer(E,n,d,lam,eta,rng)))
            rows.append(dict(family=fam,n=n,d=d,lam=lam,eta=eta,cases=cases))
            print(fam,n,d,eta,[(k,sum(x[k]['certified']=='exact' for x in cases),float(np.median([x[k]['calls'] for x in cases]))) for k in ('repetition','outer')],flush=True)
            Path(__file__).with_name('outer.json').write_text(json.dumps(dict(distance_checks=checks,rows=rows),indent=2))
if __name__=='__main__':run()
