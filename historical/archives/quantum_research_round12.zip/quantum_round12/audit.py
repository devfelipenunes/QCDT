import json, time, math, itertools as it
from pathlib import Path
import numpy as np
from asymmetric import *
from benchmark import new, PASCH, status
from codegree import linear,codegree
from robust import generate
from circuit import Simulator,oracle_gates,derivative

def audit():
    rng=np.random.default_rng(2026112613);res={}
    T=list(it.combinations(range(5),3));counts=Counter();maximum=0
    for z in range(1<<len(T)):
        E={e for i,e in enumerate(T) if z>>i&1};d=max(1,max(Counter(i for e in E for i in e).values(),default=0));lam=max(1,codegree(E));p=Probe(5,lambda a,b:contract(E,a,b),0,1,rng);C,extra=recover(5,d,lam,p)
        assert C==E,(z,E,C);counts['linear' if lam==1 else 'general']+=1;maximum=max(maximum,p.calls)
    res['exhaustive']=dict(counts=counts,maximum=maximum);Path(__file__).with_name('audit.json').write_text(json.dumps(res,indent=2));print('exhaustive',res['exhaustive'],flush=True)
    # All linear hypergraphs on 6 vertices, recursively avoiding pair conflicts.
    T=list(it.combinations(range(6),3));counts=Counter()
    def visit(start,E,pairs):
        d=max(1,max(Counter(i for e in E for i in e).values(),default=0));p=Probe(6,lambda a,b:contract(E,a,b),0,1,rng);C,extra=recover(6,d,1,p);assert C==E;counts['total']+=1;counts['extra']+=bool(extra['stage2'])
        for i in range(start,len(T)):
            e=T[i];ps=set(it.combinations(e,2))
            if not pairs&ps:visit(i+1,E|{e},pairs|ps)
    visit(0,set(),set());res['linear6']=counts;Path(__file__).with_name('audit.json').write_text(json.dumps(res,indent=2));print('linear6',counts,flush=True)
    gates=Counter()
    for n,d,lam in ((5,1,1),(6,2,1),(6,2,2),(7,3,3)):
        for j in range(4):
            E=PASCH[j%2] if n==6 and lam==1 else (linear(n,d,rng) if lam==1 else generate(n,d,rng));terms=E|{(0,),(1,2)};sim=Simulator(n);oracle=oracle_gates(terms)
            def actual(a,b):
                out=sim.run(derivative(n,oracle,(a,b)));assert out==contract(E,a,b);gates['probes']+=1;return out
            p=Probe(n,actual,0,1,rng);C,_=recover(n,d,lam,p);assert C==E;gates['circuits']+=1
    res['gates']=gates;Path(__file__).with_name('audit.json').write_text(json.dumps(res,indent=2));print('gates',gates,flush=True)
    scale=[]
    for n,d,T in ((256,2,4),(512,4,3),(1024,2,2)):
        Es=[linear(n,d,rng) for _ in range(T)]
        for eta in (0,.15,.25):
            vals=[new(E,n,d,1,eta,rng) for E in Es];scale.append(dict(n=n,d=d,eta=eta,rows=vals));print('scale',n,d,eta,[(x['certified'],x['calls'],x['holdout'],x['stage2']) for x in vals],flush=True)
    res['scale']=scale;Path(__file__).with_name('audit.json').write_text(json.dumps(res,indent=2))
    # Explicit codegree violation: a star has two or more edges per central pair.
    adversarial=[]
    for n,d in ((6,2),(9,3),(12,4)):
        for j in range(30):
            E=generate(n,d,rng)
            if codegree(E)<=1:continue
            p=Probe(n,lambda a,b:contract(E,a,b),0,1,rng);C,_=recover(n,d,1,p)
            r=new(E,n,d,1,0,rng);adversarial.append(dict(n=n,d=d,codegree=codegree(E),raw=status(C,E),checked=r['certified']))
    res['outside_promise']=adversarial;print('outside',Counter((x['raw'],x['checked']) for x in adversarial),flush=True)
    Path(__file__).with_name('audit.json').write_text(json.dumps(res,indent=2))
if __name__=='__main__':audit()
