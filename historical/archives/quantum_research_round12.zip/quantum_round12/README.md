# QCDT — Round 12: exact sparse projection and coded acquisition

Research candidate, not an established original quantum algorithm. All numerical experiments below are synthetic; no QPU or Qiskit/Aer execution. This round concerns the cubic coefficients only. Lower-order terms disappear under second differences. The decoder receives a phase-probe callback, not the hidden edge list. The simulator uses the hidden list to generate measurements; certification uses independent random masks. The phase-query unit is one call to U_f, not a gate or a unit of elapsed physical time.

## 1. Model and exact construction

Let f:{0,1}^n -> F2 have algebraic degree <=3 and cubic coefficients T_ijk. Let L_i[j,k]=T_ijk for distinct i,j,k, zero otherwise. L_i is symmetric with zero diagonal. Let d bound the number of triples incident to each vertex; lambda bound the number incident to each unordered pair (codegree). A second derivative followed by Bernstein–Vazirani yields D_i(a,b)=b^T L_i a for every i in four phase calls. All operations on these bits are over F2. In particular D(a,b)=D(b,a), and D(a,a)=D(a,0)=0; no oracle call is necessary for known zero responses.

For m=max(2,ceil(log2(n+1))), choose distinct nonzero labels alpha_j in GF(2^m). H_k is the binary expansion of moments sum_j x_j alpha_j^t for odd t=1,3,...,2k-1. It has k*m binary rows (some masks may be redundant); moments of even order follow by squaring. H_k distinguishes vectors of weight <=k: their nonzero difference would have weight <=2k, and the Vandermonde matrix of the first 2k moments has full column rank for distinct nonzero labels. Berlekamp–Massey and finite-field trace factorization decode the locator; recompute the syndrome and reject inconsistent results. This is standard BCH syndrome decoding, not a new coding theorem.

### Asymmetric construction for general lambda

Set B=H_min(2d,n), A=H_min(lambda,n). For each row a of A, query D(a,b) for every row b of B. Decode B L_i a to obtain L_i a (support <=2d). For every nonzero row j in these contractions, collect its bits across A and decode via A to obtain the row L_i[j,:] (weight <=lambda). A zero syndrome cannot hide a nonzero row under the promise. Reconstruct all triples and require all six ordered witnesses per triple. At most 4*(2d*m)*(lambda*m) calls before caching: O(d lambda log^2 n). This refines the symmetric double-BCH construction from round 4, but is not generally better than v0.4/v0.5. Polynomial arithmetic and sparse dictionaries replace a cubic tensor. Implementation uses a finite table of irreducible polynomials inherited from previous.py; not an unrestricted-size field constructor.

### Linear hypergraphs (lambda=1)

L_i*1 has bit j equal to the parity of the number of edges containing i,j. Under lambda=1 it is exactly the adjacency of the graph projection. Acquire just B L_i*1; recover all neighbors with one family of at most 2d*m probes, not one individual query. If projection plus forced-triangle propagation determines all triples, stop.

If ambiguous, let F be the set of forced triples and U remaining candidate triangles. Given exact projection, F subset E subset F union U. Since each pair is covered by exactly one true triple, any pair occurring in U has exactly one remaining true triple (all candidates sharing a pair covered by F were removed). For each such pair (i,j), its third vertices form a choice set. Build a conflict graph joining distinct vertices in the same choice set and greedily color it. Every conflict connects vertices at distance at most two in the projection G; degree of G <=2d, hence max conflict degree <=(2d)^2. At most (2d)^2+1 colors suffice. Let a_t be the bit mask of color bit t. For each color bit, query B L_i a_t, subtract known F contractions, and BCH-decode the residual vectors. For pair (i,j), the bit at j is exactly the t-th bit of the unique true third vertex's color. Coloring separates all candidates; zero color is allowed because the pair is already known to exist. Validate symmetry, three pair witnesses, degree, codegree, and projection. Cost at most

4*(2d*m)*(1+ceil(log2((2d)^2+1))) = O(d log n log(d+1)).

If all triangles forced, cost <=8d*m. This is deterministic, ideal model only. For constant d it is O(log n), matching the earlier Omega(log n) query lower bound on disjoint triples, without the unimplemented linear-rank field multiplication. For lambda>1, L_i*1 gives parity, NOT projection; this shortcut is not valid. The classical computation is polynomial: sparse candidate triangles O(nd^2), conflict graph at most O(nd^2) edges (distance-two bound), finite-field decoding, and naive iterative propagation (may be quadratic in candidates). Probe cache contains at most O(n P) bits ignoring Python overhead, P number of planned probes; no explicit n^3 tensor. No CPU or QPU speedup claimed.

## 2. Noise and outer code

Known stationary independent binary symmetric channel (BSC), eta<1/2. For at most P logical probes before repetition, pick odd R such that n P Pr[Bin(R,eta)>R/2] <= .005. For adaptive selection of masks, conditional independence of subsequent errors and the deterministic bound P allow union bound over the at most P query events. Cache reuse does not add independent information. Acquisition failure probability <=.005 under the promise. A separate dense-mask holdout (round 9) uses delta=.005, gap g=3(1-2eta)/16 and ceil(log(n/delta)/(2g^2)) fresh probes; false rejection <=.005, false acceptance <=.005/n for an independent fixed incorrect candidate. Total failure (recovery or rejection of true answer) <=.01 in model. Zero false acceptances in experiments do not prove probability zero. Outside lambda promise, holdout can still reject wrong cubic candidates under the BSC model. It does not guarantee identifying a violated promise if a candidate happens to be correct, nor detect arbitrary higher-degree or adversarial noise.

For a block of k<=6 syndrome masks b_j at fixed a, linearity gives D(a, XOR_{j:c_j=1} b_j)=XOR_j c_j D(a,b_j). Query all nonzero c, obtaining a binary simplex code of length 2^k-1 and minimum distance 2^(k-1), repeated r times. Decode each output bit's block by minimum Hamming distance on raw shot counts, rejecting ties. Distinct codewords differ in D=r*2^(k-1) positions; the probability a fixed competitor ties or beats true codeword is at most Pr[Bin(D,eta)>=ceil(D/2)]. Known zero probe responses are filled noiselessly, which can only improve this bound. Union over 2^k-1 competitors and at most nP blocks; choose r so this bound <=.005. Dynamic programming chooses a partition into widths 1..6 minimizing planned query count. Codeword distance validated exhaustively for k=1..6. No physical error correction or gate-level twirling is implied; this is classical error correction over logical probe outputs. Worst-case asymptotic noise overhead still O(log(nP/delta)/(1-2eta)^2) for fixed block width, unlike v0.8's statistical approach, which has a better log-n scaling in the bounded-degree BSC regime. Savings here concern constants and tested sizes. Outer code has no caching between blocks; small instances may lose to repetition with mask reuse.

## 3. Results: benchmark.py

Seed 2026112612. 40 base instances across seven configurations, each reused at three eta levels (120 observations; not 120 independent structures). Includes repeated Pasch alternatives with identical projection, random and star instances. Four methods: v0.10 with repetition, v0.9 previous heuristic budget, v0.9 capped at v0.10's acquisition budget (split in same stage ratio, can stop/reject early), and v0.4 repeated algebraic with equal acquisition union-bound target. All successful candidates use the same holdout-size rule. Different methods use independent simulated noise and masks. Counts in table are median total phase calls including holdout when accepted. No comparison against all published methods, and v0.9 acquisition budget is heuristic, not equal theoretical error bound.

| n,d,lambda | eta | trials | new correct | new total | v0.9 total | v0.4 total |
|---|---|---|---|---|---|---|
| 6,2,1 Pasch | .25 | 10 | 10 | 4892 | 81032 | 8228 |
| 24,4,1 | .25 | 8 | 8 | 14892 | 114616 | 81960 |
| 64,4,1 | .25 | 6 | 6 | 22540 | 149612 | 143844 |
| 128,2,1 | .25 | 4 | 4 | 13704 | 88328 | 41288 |
| 32,6,6 star | .25 | 4 | 4 | 589040 | 186316 | 194092 |
| 32,4,4 random | .25 | 4 | 3 | 301084 | 739276 | 106576 |
| 64,2,2 random | .25 | 4 | 4 | 104328 | 75884 | 33260 |

Overall exact after holdout: new 119/120, v0.9 full 120/120, v0.9 capped 9/120, v0.4 120/120. Others rejected; zero wrong accepted. In ideal linear n=128,d=2, acquisition 128 phase calls vs v0.9 21504 and v0.4 448 (all four cases), excluding shared holdout. For n=64,d=4, ideal acquisition 224 calls. The new general branch is often substantially worse than v0.4; retain the latter for high overlap, no claim of automatic selector implemented. Capped baseline uses at most new acquisition budget, not forced to spend remaining queries after rejection. Timings logged but not robust physical runtime measurements.

## 4. Audit: audit.py

Seed 2026112613. All 1024 hypergraphs on five vertices (26 linear, 998 general) and all 271 linear hypergraphs on six vertices recovered, including 30 requiring ambiguity resolution. 16 circuits, 324 second-derivative probes independently checked by explicit statevector gates, with additional linear/quadratic terms. 85 generated cubic cases violating lambda=1 rejected before and after holdout; not an exhaustive out-of-promise guarantee. 27 scale observations (9 base instances reused at three eta values) all accepted correctly, using algebraic contraction plus BSC simulation; no n=1024 statevector. Scale tests:

| n,d,lambda | cases per eta | eta=0 acquisition | eta=.15 acquisition | eta=.25 acquisition | eta=.25 total |
|---|---|---|---|---|---|
| 256,2,1 | 4 | 144 | 5904 | 13680 | 16148 |
| 512,4,1 | 3 | 320 | 15040 | 34240 | 36868 |
| 1024,2,1 | 2 | 176 | 7920 | 18480 | 21264 |

Original audit attempted n=2048 too but exceeded execution time after n=1024. Retained audit_timeout.log, reran with max n=1024 and checkpoint JSON, succeeded. No claim of 2048 test. Scale examples all skipped ambiguity stage and do not measure worst-case query count. Current code supports only listed field degrees, not arbitrary n.

## 5. Outer code: outer_code.py

Seed 2026112614. 2667 pairwise distance checks for all codewords of widths 1..6; 32 base observations reused across two eta levels, 64 paired comparisons. Outer code 64/64; repetition 63/64 with one rejection. Zero wrong accepted. Same union-bound acquisition target, same holdout, independent BSC. At eta=.25:

| family,n,d | trials | repetition acquisition | coded acquisition | repetition total | coded total |
|---|---|---|---|---|---|
| Pasch,6,2 | 8 | 3276 | 2880 | 4892 | 4496 |
| linear,32,4 | 8 | 15640 | 7952 | 17636 | 9948 |
| linear,128,2 | 6 | 11392 | 5640 | 13704 | 7952 |
| star,24,4 | 4 | 210040 | 137424 | 211972 | 139356 |
| random,32,2 | 6 | 69720 | 48192 | 71716 | 50188 |

At eta=.15, Pasch outer acquisition 1540 vs repetition 1404; repetition's reuse of masks beats block code plan in that small case. Use raw counts, not an independent physical validation. Samples small and comparisons exploratory, no preregistration or multiple-comparison claims.

## 6. Prior art and limits

- Montanaro 2012, https://arxiv.org/abs/1105.3310 — derivative/BV learning of low-degree multilinear polynomials.
- Montanaro and Shao 2022, https://doi.org/10.4230/LIPIcs.TQC.2022.1 — hidden graphs with OR/parity oracle.
- Ferber et al. 2024, https://arxiv.org/abs/2402.18714 — bounded-degree graphs in a different query model.
- Arunachalam et al. 2023, https://doi.org/10.4230/LIPIcs.TQC.2023.3 — phase-state learning in copy model.
- Bresler et al. COLT 2024/2025, https://proceedings.mlr.press/v247/bresler24a.html and https://proceedings.mlr.press/v291/bresler25a.html — reconstruction from graph projection, information loss known.
- Dodis et al. 2008 and PinSketch, https://cs-pub.bu.edu/faculty/reyzin/code/fuzzy.html — BCH-based sparse syndrome recovery known; Bitcoin Core Minisketch https://github.com/bitcoin-core/minisketch is an optimized classical implementation, not a quantum algorithm.
- Sketching Sparse Matrices, https://arxiv.org/abs/1303.6544 — two-sided matrix sketches in real-valued recovery model.
- Simple Codes and Sparse Recovery with Fast Decoding, https://doi.org/10.1137/21M1465354 — classical sparse recovery.

The candidate contribution is the combination of coherent second-derivative measurements with deterministic linear-hypergraph projection, adaptive local coloring to resolve ambiguity, and coded probe acquisition. Each ingredient is known. This review is focused, not systematic; no novelty claim, no complete comparison with published algorithms in identical oracle model. No evidence of practical quantum advantage, calibrated physical noise robustness, hardware execution, or actual blockchain application. The prior Graph Collision blockchain line remains in reserve. This round did not implement linear-rank multiplication for v0.5, or reproduce all historical suites. Qiskit/Aer still unavailable. Independent peer review and external execution remain gates, not tasks falsely marked done.

## 7. Reproduce

Python 3.13.5 / NumPy 2.3.5 / SciPy 1.17.0. Unzip and run in quantum_round12:

    pip install -r requirements.txt
    OPENBLAS_NUM_THREADS=1 python benchmark.py
    OPENBLAS_NUM_THREADS=1 python audit.py
    OPENBLAS_NUM_THREADS=1 python outer_code.py

JSON contains raw per-instance statuses and query counts; logs show executions. Earlier modules copied for comparison. All three scripts completed in this environment after limiting the audit scale as above. No external repository or SDK modified. 
