"""Asymmetric BCH sketches and projection-aware coloring. Learner sees only probe callback."""
import itertools as it, math
from collections import Counter, defaultdict
import numpy as np
from scipy.stats import binom
from previous import CompactField, roots, masks
from pruning import propagate
from shadow import shadow
class Reject(ValueError): pass
def pack(indices):return sum(1<<int(i) for i in indices)
def contract(E,a,b):
    v=0
    for i,j,k in E:
        for x,y,z in ((i,j,k),(j,i,k),(k,i,j)):
            if ((a>>y&1)*(b>>z&1))^((a>>z&1)*(b>>y&1)):v^=1<<x
    return v
class BCH:
    def __init__(self,n,k):
        self.n=n;self.k=min(k,n);self.g=CompactField(max(2,n.bit_length()));self.m=self.g.m
        self.masks=[b for t in range(1,2*self.k,2) for b in masks([self.g.pow(j+1,t) for j in range(n)],self.m)]
    def decode(self,bits):
        odd=[sum(int(bits[j+i])<<i for i in range(self.m)) for j in range(0,len(bits),self.m)]
        try:
            C=self.g.locator(odd,self.k);r=sorted(self.g.div(1,z)-1 for z in roots(C,self.g))
            if len(r)!=len(C)-1 or len(set(r))!=len(r) or len(r)>self.k or any(not 0<=j<self.n for j in r):raise Reject('bad locator')
            v=pack(r)
            if any(((v&b).bit_count()&1)!=int(y) for b,y in zip(self.masks,bits)):raise Reject('syndrome mismatch')
            return r
        except (AssertionError,ZeroDivisionError,KeyError,ValueError,IndexError) as e:raise Reject('BCH decode failed') from e
class Probe:
    def __init__(self,n,fn,eta,shots,rng):self.n=n;self.fn=fn;self.eta=eta;self.shots=shots;self.rng=rng;self.cache={};self.calls=0
    def __call__(self,a,b):
        if not a or not b or a==b:return 0
        key=tuple(sorted((a,b)))
        if key not in self.cache:
            z=self.fn(a,b)
            if self.eta:z^=pack(np.flatnonzero(self.rng.binomial(self.shots,self.eta,self.n)>self.shots//2))
            self.cache[key]=z;self.calls+=4*self.shots
        return self.cache[key]
def repetitions(n,P,eta,delta):
    if not eta:return 1
    if not 0<=eta<.5 or not 0<delta<1:raise ValueError('noise or delta')
    r=1
    while n*P*binom.sf(r//2,r,eta)>delta:r+=2
    return r
def cap_probes(n,d,lam):
    m=max(2,n.bit_length());b=min(2*d,n)*m
    return b*(1+math.ceil(math.log2((2*d)**2+1))) if lam==1 else b*min(lam,n)*m
def acquire(n,codec,probe,a,F=()):
    raw=probe.block_acquire(a,codec.masks) if hasattr(probe,"block_acquire") else [probe(a,b) for b in codec.masks]
    out=[v^contract(F,a,b) for v,b in zip(raw,codec.masks)]
    return [codec.decode([(v>>i)&1 for v in out]) for i in range(n)]
def validate(E,n,d,lam):
    if any(len(e)!=3 or tuple(sorted(set(e)))!=e or not 0<=e[0]<e[-1]<n for e in E):raise Reject('invalid edges')
    if max(Counter(i for e in E for i in e).values(),default=0)>d:raise Reject('degree')
    if max(Counter(p for e in E for p in it.combinations(e,2)).values(),default=0)>lam:raise Reject('codegree')
def asymmetric(n,d,lam,probe):
    B=BCH(n,2*d);A=BCH(n,lam);links=[defaultdict(int) for _ in range(n)]
    for t,a in enumerate(A.masks):
        for i,js in enumerate(acquire(n,B,probe,a)):
            if i in js:raise Reject('diagonal')
            for j in js:links[i][j]|=1<<t
    E=set();witnesses=Counter()
    for i,rows in enumerate(links):
        for j,v in rows.items():
            for k in A.decode([(v>>t)&1 for t in range(len(A.masks))]):
                if len({i,j,k})!=3:raise Reject('diagonal')
                e=tuple(sorted((i,j,k)));E.add(e);witnesses[e]+=1
    if any(x!=6 for x in witnesses.values()):raise Reject('asymmetric links')
    validate(E,n,d,lam);return E,dict(colors=None,stage2=1,unresolved=None)
def color_candidates(U):
    choices=defaultdict(set)
    for e in U:
        for p in it.combinations(e,2):choices[p].add(next(x for x in e if x not in p))
    conflicts=defaultdict(set)
    for c in choices.values():
        for j in c:conflicts[j].update(c-{j})
    colors={}
    for k in sorted(conflicts,key=lambda j:(-len(conflicts[j]),j)):
        used={colors[x] for x in conflicts[k] if x in colors};colors[k]=next(c for c in range(len(used)+1) if c not in used)
    return choices,colors
def linear_recover(n,d,probe):
    B=BCH(n,2*d);N=[set(js) for js in acquire(n,B,probe,(1<<n)-1)]
    if any(i in js for i,js in enumerate(N)) or any(i not in N[j] for i,js in enumerate(N) for j in js):raise Reject('shadow not symmetric')
    FU=propagate(N,d,1)
    if FU is None:raise Reject('inconsistent projection')
    F,U=FU
    if not U:
        validate(F,n,d,1)
        if shadow(F,n)!=N:raise Reject('shadow mismatch')
        return F,dict(colors=0,stage2=0,unresolved=0)
    choices,colors=color_candidates(U);c=1+max(colors.values());assert c<=(2*d)**2+1
    sig={p:0 for p in choices};bits=(c-1).bit_length()
    for t in range(bits):
        a=pack(k for k,v in colors.items() if v>>t&1);row=acquire(n,B,probe,a,F)
        for i,j in choices:
            x=j in row[i];y=i in row[j]
            if x!=y:raise Reject('non-symmetric residual')
            if x:sig[i,j]|=1<<t
        if any(tuple(sorted((i,j))) not in choices for i,js in enumerate(row) for j in js):raise Reject('unexpected residual')
    found=Counter()
    for p,C in choices.items():
        matching=[k for k in C if colors[k]==sig[p]]
        if len(matching)!=1:raise Reject('color not found')
        found[tuple(sorted((*p,matching[0])))]+=1
    if any(x!=3 for x in found.values()):raise Reject('inconsistent triangles')
    E=F|set(found);validate(E,n,d,1)
    if shadow(E,n)!=N:raise Reject('shadow mismatch')
    return E,dict(colors=c,stage2=bits,unresolved=len(U))
def recover(n,d,lam,probe):
    if not 3<=n or not 1<=lam<=d:raise ValueError('invalid promise')
    try:return linear_recover(n,d,probe) if lam==1 else asymmetric(n,d,lam,probe)
    except Reject:return None,dict(colors=None,stage2=None,unresolved=None)
