"""Certificate for unknown heterogeneous stationary BSC; adversarial identifiability test."""
import numpy as np, math, json
from pathlib import Path
from robust import generate
from certification import dense_obs,verify

def calibrated_size(n,eta_max,delta):
 # Compare residual bits with independently measured reference bits. D in [-1,1].
 gap=3*(1-2*eta_max)/8
 return math.ceil(8*math.log(n/delta)/(gap*gap)),gap/2

def calibrated_verify(C,A,B,Y,ref,tau):
 return bool(np.all((Y^dense_obs(A,B,C)).mean(0)-ref.mean(0)<=tau))

def run():
 rng=np.random.default_rng(2026112512);rows=[]
 for n,d in [(8,2),(16,3),(32,4)]:
  for cap in (.15,.3,.4):
   M,tau=calibrated_size(n,cap,.01);stats=[0,0,0,0];T=60
   for _ in range(T):
    E=generate(n,d,rng);wrong=E^{tuple(sorted(map(int,rng.choice(n,3,replace=False))))};eta=rng.uniform(0,cap,n)
    A=rng.random((M,n))<.5;B=rng.random((M,n))<.5;Y=dense_obs(A,B,E)^(rng.random((M,n))<eta);ref=rng.random((M,n))<eta
    stats[0]+=calibrated_verify(E,A,B,Y,ref,tau);stats[1]+=calibrated_verify(wrong,A,B,Y,ref,tau)
    # Misspecified fixed-rate verifier as comparison, same holdout.
    stats[2]+=verify(E,A,B,Y,cap/2);stats[3]+=verify(wrong,A,B,Y,cap/2)
   row=dict(n=n,d=d,eta_cap=cap,probes=M,reference_probes=M,phase_calls_if_reference_uses_four=8*M,trials=T,correct_calibrated=stats[0],wrong_calibrated=stats[1],correct_fixed=stats[2],wrong_fixed=stats[3]);rows.append(row);print(row,flush=True)
 # Adversary: noise adds precisely the syndrome of a different cubic function.
 M=512;count=0;true_accepted=0;false_accepted=0
 for _ in range(100):
  n=9;E=generate(n,2,rng);F={tuple(sorted(map(int,rng.choice(n,3,replace=False))))};C=E^F
  A=rng.random((M,n))<.5;B=rng.random((M,n))<.5;Y=dense_obs(A,B,E)^dense_obs(A,B,F)
  assert np.array_equal(Y,dense_obs(A,B,C));count+=1;true_accepted+=verify(E,A,B,Y,0);false_accepted+=verify(C,A,B,Y,0)
 out=dict(rows=rows,adversarial=dict(cases=count,true_accepted=true_accepted,wrong_accepted=false_accepted));Path(__file__).with_name('noise_audit.json').write_text(json.dumps(out,indent=2));print(out['adversarial'])
if __name__=='__main__':run()
