"""External, unexecuted integration test. Requires Qiskit/Aer; no QPU submission."""
import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit_aer import AerSimulator
from robust import masks, observations
from scale import fast
from circuit import shifts

def main():
 n=5; d=1; E={(0,2,4)}; rng=np.random.default_rng(26112512); A,B=masks(n,d,1024,rng)
 oracle=QuantumCircuit(n);oracle.ccz(0,2,4);oracle.cz(1,3);oracle.z(2);gate=oracle.to_gate()
 def word(row):return sum(int(v)<<i for i,v in enumerate(row))
 pairs=[(word(a),word(b)) for a,b in zip(A,B)]; unique=list(dict.fromkeys(pairs)); circuits=[]
 for a,b in unique:
  qc=QuantumCircuit(n,n);qc.h(range(n))
  for xs in shifts(n,(a,b)):
   qc.append(gate,list(range(n)))
   for _,i in xs:qc.x(i)
  qc.h(range(n));qc.measure(range(n),range(n));circuits.append(qc)
 backend=AerSimulator(); compiled=transpile(circuits,backend,seed_transpiler=26112512,optimization_level=1)
 result=backend.run(compiled,shots=1,seed_simulator=26112512).result(); words={k:int(next(iter(result.get_counts(i))).replace(' ',''),2) for i,k in enumerate(unique)}
 Y=np.array([[bool(words[p]>>i&1) for i in range(n)] for p in pairs]);assert np.array_equal(Y,observations(A,B,E,rng));assert fast(A,B,Y,d)==E
 print('Aer ideal integration passed; distinct circuits:',len(unique),'max transpiled depth:',max(x.depth() for x in compiled))
if __name__=='__main__':main()
