"""Equal query budget comparison: conditional voting versus repeated algebraic probes."""
import numpy as np, json, math
from pathlib import Path
from robust import generate,masks,observations
from scale import fast
from previous import direct_recover
from round4_reference import contraction

def run():
 rng=np.random.default_rng(26112511);rows=[]
 for n,d,M,trials in [(5,1,256,60),(9,2,1024,40),(16,2,1024,30),(32,4,6144,20)]:
  plan={};direct_recover(n,d,lambda a,b:plan.setdefault((a,b),0),compact=True);keys=list(plan);shots=M//len(keys);shots-=int(shots%2==0);assert shots>0
  eslist=[generate(n,d,rng) if k%7 else set() for k in range(trials)]
  for eta in (.05,.15,.25):
   votes={'conditional':dict(exact=0,wrong=0,rejected=0),'algebraic':dict(exact=0,wrong=0,rejected=0)};raw=[]
   for E in eslist:
    A,B=masks(n,d,M,rng);Y=observations(A,B,E,rng,eta);C=fast(A,B,Y,d);look={}
    for a,b in keys:
     correct=contraction(E,a,b);errors=rng.binomial(shots,eta,size=n)>shots//2;look[a,b]=correct^sum(int(e)<<i for i,e in enumerate(errors))
    D=None
    try:D,_=direct_recover(n,d,lambda a,b:look[a,b],compact=True)
    except (ValueError,AssertionError,KeyError,IndexError,ZeroDivisionError):pass
    pair=[]
    for key,out in [('conditional',C),('algebraic',D)]:
     s='rejected' if out is None else 'exact' if out==E else 'wrong';votes[key][s]+=1;pair.append(s)
    raw.append(pair)
   row=dict(n=n,d=d,eta=eta,trials=trials,conditional_calls=4*M,algebraic_calls=4*len(keys)*shots,algebraic_shots=shots,**votes,raw=raw);rows.append(row);print({k:v for k,v in row.items() if k!='raw'},flush=True)
 Path(__file__).with_name('paired_results.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':run()
