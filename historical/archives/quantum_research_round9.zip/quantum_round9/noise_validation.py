"""Independent exact density-matrix noise simulator; no hardware data. Fixed settings before run."""
import numpy as np, itertools as it, random, math, json
from pathlib import Path
from circuit import oracle_gates, derivative, Simulator
from previous import direct_recover
from round4_reference import contraction
from soft_noise import candidates
from scipy.stats import binomtest
from functools import lru_cache
R=random.Random(881182); N=np.random.default_rng(881182)
class Density:
 def __init__(self,n):
  self.n=n;self.dim=1<<n;self.ids=np.arange(self.dim);self.sim=Simulator(n);self.perm=[self.ids^(1<<i) for i in range(n)];self.ones=[self.ids[(self.ids>>i&1)>0] for i in range(n)];self.zeros=[x^(1<<i) for i,x in enumerate(self.ones)]
 @lru_cache(None)
 def gate(self,g):
  # Independent matrix construction from basis action, with explicit tensor gate formulas.
  k,*qs=g;q=qs[0];a=self.ids;v=np.eye(self.dim,dtype=complex);one=self.ones[q];zero=self.zeros[q]
  if k=='H':v[:,zero]=0;v[:,one]=0;v[zero,zero]=v[zero,one]=v[one,zero]=1/np.sqrt(2);v[one,one]=-1/np.sqrt(2)
  elif k=='X':v=v[:,self.perm[q]]
  elif k in ('Z','T','TDG'):v[one,one]=dict(Z=-1,T=np.exp(1j*np.pi/4),TDG=np.exp(-1j*np.pi/4))[k]
  elif k=='CZ':idx=one[(one>>qs[1]&1)>0];v[idx,idx]=-1
  elif k=='CX':v=v[:,a^(((a>>q)&1)<<qs[1])]
  else:raise ValueError(g)
  return v
 def channel(self,r,q,kind,p):
  if kind=='damping':
   z,o=self.zeros[q],self.ones[q];zz,oo,zo,oz=np.ix_(z,z),np.ix_(o,o),np.ix_(z,o),np.ix_(o,z)
   r[zz]+=p*r[oo];r[oo]*=1-p;r[zo]*=np.sqrt(1-p);r[oz]*=np.sqrt(1-p);return r
  if kind=='coherent_rx':
   a=self.perm[q];c=np.cos(p/2);s=np.sin(p/2);r=c*r-1j*s*r[a,:];return c*r+1j*s*r[:,a]
  return r
 def probs(self,gates,kind,p):
  r=np.zeros((self.dim,self.dim),complex);r[0,0]=1
  for g in gates:
   u=self.gate(g);r=u@r@u.conj().T
   for q in g[1:]:r=self.channel(r,q,kind,p)
  assert np.allclose(r,r.conj().T,atol=1e-9) and abs(np.trace(r)-1)<1e-9 and np.linalg.eigvalsh(r).min()>-1e-8
  pr=np.diag(r).real.copy();assert min(pr)>-1e-8;pr=np.maximum(pr,0);return pr/pr.sum()

def interval(k,n):
 ci=binomtest(k,n).proportion_ci(.95,method='wilson');return [ci.low,ci.high]

def run():
 n=5;d=1;sim=Density(n);cs=candidates(n);plan={};direct_recover(n,d,lambda a,b:plan.setdefault((a,b),0),compact=True);keys=list(plan);pred=np.array([[[contraction(c,a,b)>>i&1 for i in range(n)] for a,b in keys] for c in cs],dtype=int)
 # Independent uniform sample over complete degree-one class (including empty), random lower-order terms.
 cases=[(set(R.choice(cs)),{(i,) for i in range(n) if R.random()<.5}|{e for e in it.combinations(range(n),2) if R.random()<.25},[(R.getrandbits(n),R.getrandbits(n)) for _ in range(3)]) for _ in range(60)]
 # Independent validation of noiseless probabilities and trace-preserving channels.
 rows=[];raw=[]
 for kind,p in [('ideal',0),('damping',.005),('damping',.02),('coherent_rx',.05),('coherent_rx',.15),('correlated_readout',.05),('correlated_readout',.2)]:
  all_counts={s:[] for s in (1,5,15)}
  for es,lower,holdouts in cases:
   og=oracle_gates(es|lower);ps=[]
   for a,b in keys+holdouts:
    gs=derivative(n,og,(a,b));prob=sim.probs(gs,kind,p)
    if kind=='ideal':assert prob[contraction(es,a,b)]>1-1e-9
    ps.append(prob)
   # The three budgets are nested; same raw shots for all decoders.
   samples=[]
   for pr in ps:
    z=N.choice(1<<n,size=15,p=pr)
    if kind=='correlated_readout':z^=np.where(N.random(15)<p,(1<<n)-1,0)
    # Same independent readout flip probability for all models except ideal.
    if kind!='ideal':
     for i in range(n):z^=(N.random(15)<.002).astype(int)<<i
    samples.append(z)
   for shots in (1,5,15):
    c=np.array([[sum((v>>i)&1 for v in s[:shots]) for i in range(n)] for s in samples]);m=[sum((int(v)>shots//2)<<i for i,v in enumerate(row)) for row in c];lookup=dict(zip(keys,m));hard=None;soft=None
    try:hard,_=direct_recover(n,d,lambda a,b:lookup[a,b],compact=True)
    except (ValueError,AssertionError,KeyError,IndexError,ZeroDivisionError):pass
    cost=(pred*(shots-2*c[:len(keys)])+c[:len(keys)]).sum(axis=(1,2));idx=np.flatnonzero(cost==cost.min())
    if len(idx)==1:soft=set(cs[int(idx[0])])
    validated=soft if soft is not None and all(contraction(soft,a,b)==w for (a,b),w in zip(holdouts,m[len(keys):])) else None
    def status(e):return 'rejected' if e is None else 'exact' if e==es else 'wrong'
    all_counts[shots].append([status(hard),status(soft),status(validated)])
  for shots,c in all_counts.items():
   row=dict(kind=kind,p=p,shots=shots,trials=len(c),phase_calls=4*len(keys)*shots,holdout_phase_calls=12*shots)
   for j,name in enumerate(['hard','soft','holdout']):
    z=[x[j] for x in c];row[name]={k:z.count(k) for k in ['exact','wrong','rejected']};row[name]['wilson95']=interval(z.count('exact'),len(c))
   a=sum(x[0]=='exact' and x[1]!='exact' for x in c);b=sum(x[1]=='exact' and x[0]!='exact' for x in c);row['paired_mcnemar_p']=binomtest(a,a+b,.5).pvalue if a+b else 1.
   rows.append(row);raw.append(dict(kind=kind,p=p,shots=shots,status=c));print(kind,p,shots,[(k,row[k]['exact'],row[k]['wrong']) for k in ['hard','soft','holdout']],flush=True)
 Path('noise_r8.json').write_text(json.dumps(dict(rows=rows,raw=raw,seed=881182),indent=2))
if __name__=='__main__':run()
