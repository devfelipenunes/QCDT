# QCDT — Rodada 9: recuperação robusta, certificação e mitigação de erros

Pesquisa exploratória, sem revisão independente. Código e testes executados localmente em Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0. Qiskit/Aer ausentes (ver environment.json); os adaptadores externos foram apenas compilados sintaticamente. Não houve QPU, dados de calibração, publicação, ou alteração do SDK. A comparação é de consultas lógicas ao oráculo, não de tempo físico. As sementes constam dos scripts; amostras pequenas, sem pré-registro externo.

## 1. Modelo e proposição candidata

Seja f: F2^n → F2 de grau no máximo 3, com hipergrafo cúbico E de grau local máximo d≥1. O oráculo de fase U_f é coerente e repetível. Uma sonda D(a,b) implementa a dupla derivada via 4 chamadas de fase e H inicial/final; entrega simultaneamente s_i=Σ_{(i,j,k)∈E}(a_j b_k+a_k b_j) em F2. A saída mede o tensor cúbico, não termos inferiores. Admitimos um canal de erro binário simétrico de taxa conhecida eta<1/2, independente entre sondagens (correlação entre bits da mesma sonda é admissível para a prova se as marginais são as especificadas). Não é uma hipótese geral de ruído de portas.

**Teorema candidato.** Para delta∈(0,1), existe algoritmo não adaptativo que recupera E com probabilidade ≥1−delta usando O(d² log(n/delta)/(1−2eta)²) consultas de fase e O(M n³) operações aritméticas clássicas, M sondagens. Para d,eta,delta constantes, a complexidade de consultas é Θ(log n) no pior caso na família anterior de partições em trios; a construção é aleatória e não precisa de multiplicação de posto linear. Não provar novidade por esta conclusão.

**Demonstração.** Cada vértice recebe independentemente uma cor A ou B com probabilidade p=1/(4d) cada; resto fica de fora. Máscaras a,b são disjuntas. Para cada i e par j,k distintos de i, condicionar ao evento C de que j,k têm cores opostas, probabilidade q=2p². A contribuição da aresta candidata então é exatamente T_ijk. Cada outra aresta do link que compartilha um extremo cruza as cores com probabilidade p; uma disjunta, com probabilidade 2p²≤p. União sobre no máximo d arestas dá probabilidade ≤dp=1/4 de alguma outra contribuição não nula. Assim o bit ideal condicionado coincide com T com probabilidade ≥3/4. Depois do BSC, probabilidade ≥1/2+g, g=(1−2eta)/4. As M sondagens são independentes. Número N_C de eventos é binomial(M,q); P(N_C<Mq/2)≤exp(−Mq/8). Condicionado ao conjunto de sondagens que satisfaz C, a maioria falha com probabilidade ≤exp(−2N_C g²)≤exp(−Mqg²). União sobre menos de n³ coeficientes dá falha ≤n³[exp(−Mq/8)+exp(−Mqg²)]. Basta M≥max(8/q,1/(qg²)) ln(2n³/delta). Cada sonda usa quatro consultas. O decodificador examina pares e conta votos para todas as saídas i; O(Mn³), sem enumerar hipergrafos completos. Rejeita empates, inconsistências entre os três links e violações de grau. Os limites de probabilidade incluem rejeição como falha de recuperação. Uso de máscaras nulas ou repetidas é contabilizado conservadoramente (4 chamadas cada). O lower bound de Ω(log n) da rodada 5 decorre da contagem de partições e da dimensão de estados alcançáveis por q consultas de fase; não é limite para acesso clássico ao código. Para d variável o método algébrico v0.5 continua com dependência em d melhor. Se eta não for conhecida ou depender da máscara, esta prova não se aplica automaticamente.

## 2. Testes de recuperação

robust.py: 480 observações (120 instâncias-base, reutilizadas em quatro níveis de ruído), contração com BSC sintético. Resultados por orçamento fixo, não orçamento suficiente do teorema:

| n,d | sondagens | casos por nível | eta=0 | eta=.05 | eta=.15 | eta=.25 |
|---|---:|---:|---:|---:|---:|---:|
| 5,1 | 256 | 50 | 49 | 46 | 46 | 28 |
| 9,2 | 1024 | 30 | 30 | 29 | 18 | 3 |
| 16,2 | 1024 | 20 | 20 | 19 | 4 | 0 |
| 24,3 | 3072 | 12 | 12 | 12 | 10 | 0 |
| 32,4 | 6144 | 8 | 8 | 8 | 5 | 0 |

Todos os demais foram rejeitados, zero aceitações erradas observadas (não garantia empírica de taxa zero). Com o orçamento conservador derivado para delta=.01, certification.py executou 72/72 recuperações corretas, n=5,9,16, eta=.15,.25, 12 por condição. crosscheck.py verificou 960 sondagens por simulação explícita de portas contra duas contrações independentes; 6/6 reconstruções completas em n=5,6 com simulação de portas, cache apenas no caso ideal.

scale.py: 60 comparações de equivalência do decodificador vetorizado contra o original e 54/54 observações corretas de escala (27 instâncias-base, duas taxas eta=.05,.15), todas por contração algébrica. n=32,64,128,256 com d=1 (8,6,4,2 instâncias por taxa), 1920,2304,2688,3072 sondagens respectivamente; n=64,128 com d=2 (4,3 instâncias), 9216 e 10752 sondagens. 256,d=1,eta=.15: 2/2, 12.288 chamadas, mediana CPU do decodificador ~1,50s. Não são 256 qubits simulados. Orçamento empírico, não garantia formal delta=.01; n grande tem poucos casos.

## 3. Comparação pareada por orçamento

paired.py: mesmas 150 instâncias-base em 3 taxas (450 pares cenário-orçamento), ruído BSC, orçamento do método algébrico <= orçamento da votação; número ímpar de repetições por máscara. Decodificador v0.4 original, sem certificação extra, nenhum erro aceito observado em ambas as variantes. A tabela mostra eta=.15:

| n,d | casos | chamadas votação | chamadas v0.4 | votação certa | v0.4 certa |
|---|---:|---:|---:|---:|---:|
| 5,1 | 60 | 1024 | 984 | 50 | 60 |
| 9,2 | 40 | 4096 | 3864 | 25 | 38 |
| 16,2 | 30 | 4096 | 3660 | 6 | 17 |
| 32,4 | 20 | 24576 | 23940 | 16 | 2 |

O método algébrico vence em muitas instâncias pequenas; a votação foi melhor no último cenário, sem generalizar para d maior. Com eta=.25,n=32,d=4 ambas tiveram 0/20 acertos; com n=5,d=1, v0.4 60/60 vs votação 28/60. Dados pareados brutos no JSON. Não comparar as contagens com QPU nem afirmar melhor método existente.

## 4. Certificação estatística sob BSC

Uma candidata independente das sondagens de holdout é comparada ao oráculo usando a,b uniformes densas. Para candidato correto, taxa marginal de desacordo eta. Se residual cúbico não nulo, alguma matriz alternante de link tem posto >=2: Pr[resíduo_i=1]=(1−2^(-rank))/2≥3/8. Com BSC, taxa esperada no bit testemunha ≥eta+3(1−2eta)/8. Limiar intermediário tau=eta+3(1−2eta)/16. Defina g'=3(1−2eta)/16. Hoeffding e união em n bits dão falsa rejeição ≤n exp(−2Mg'²); falsa aceitação de qualquer candidato incorreto fixo ≤exp(−2Mg'²). Para cada erro ≤delta, use M≥ln(n/delta)/(2g'²). Reutilizar holdout para selecionar candidatos adaptativamente exige nova análise. Não garante detecção de termos de grau>3 nem de fase global.

Testes: 1200 pares de candidato correto e candidato incorreto (uma aresta adicionada/removida), n=5,9,16,32, eta=.05,.15,.25, 100 por condição. 1200/1200 corretos aceitos, 0/1200 incorretos aceitos. Orçamento 110–460 sondagens adicionais conforme dimensão e taxa. Sem hardware ou certificação para ruído geral.

## 5. Ruído coerente e mitigação idealizada

Para erro Rx(theta) após cada porta e em cada fio tocado, a média de Rx(+theta) e Rx(−theta) como canais é (1−sin²(theta/2)) rho + sin²(theta/2) X rho X. Simulamos exatamente este canal médio de sinais independentes usando matriz densidade. Isso modela um twirl ideal com operações de mudança de sinal sem custo ou erro; não implementa randomized compiling físico e exige controle sobre portas internas do oráculo, que pode não existir em oráculo opaco. Literatura: Wallman e Emerson 2016 https://doi.org/10.1103/PhysRevA.94.052325.

Local ML: para d=1 cada link tem zero ou uma aresta. Examina O(n²) pares por link usando contagens de todos os shots, minimiza custo Hamming e exige consistência. O(n³ × número de máscaras), não enumera hipergrafos; não é ML exato sob ruído de portas correlacionado. Comparado com decodificação algébrica hard e enumeração global combinatória, com mesmos dados dentro de cada condição. 60 instâncias-base, n=5, termos inferiores aleatórios, 3 ângulos, 2 canais e 2 orçamentos aninhados (720 observações, não independentes). Leitura .002. Shots independentes entre canais, mesmas instâncias. 15 shots (360 chamadas de fase):

| theta | canal | hard certo | local certo | global certo | global errado |
|---|---|---:|---:|---:|---:|
| .05 | coerente | 47 | 55 | 60 | 0 |
| .05 | twirl | 60 | 60 | 60 | 0 |
| .15 | coerente | 5 | 5 | 27 | 28 |
| .15 | twirl | 50 | 59 | 60 | 0 |
| .25 | coerente | 4 | 5 | 22 | 32 |
| .25 | twirl | 4 | 16 | 57 | 3 |

Hard e local não tiveram aceitação errada observada nessas condições; demais rejeições. Wilson 95% local .15 twirl 59/60: [91,14%,99,71%]. Forte ruído continua causando rejeições. Não alegar vantagem prática, robustez universal ou implementação de twirl em hardware.

## 6. Revisão de anterioridade e próximos gates

- Montanaro 2012 https://arxiv.org/abs/1105.3310 (derivadas e BV para polinômios multilineares gerais, O(n^(grau−1)) consultas; técnica-base conhecida).
- Montanaro/Shao 2022 https://doi.org/10.4230/LIPIcs.TQC.2022.1 (grafos ocultos, oráculos de paridade; antecedente de grau 2).
- Arunachalam et al. 2023 https://doi.org/10.4230/LIPIcs.TQC.2023.3 (cópias de estados de fase, incluindo esparsidade e circuitos diagonais; modelo de cópias não equivale a consultas de fase coerentes).
- Roth/Benedek 1991 https://doi.org/10.1137/0220019 (interpolação esparsa GF(2)); Schapire/Sellie https://doi.org/10.1145/168304.168307 (membership e equivalence); Bshouty 2023 https://doi.org/10.4230/LIPIcs.STACS.2023.16 (aprendizado próprio aproximado sob distribuição uniforme); Bshouty 2026 https://www.sciencedirect.com/science/article/pii/S0304397526005098 (adaptive proper learning); adaptive sparse Möbius transforms https://arxiv.org/abs/2602.06246 (valores reais/contagem, não paridade). Não executamos implementações de todos esses trabalhos.
- Multiplicação de posto linear existente https://doi.org/10.1006/ffta.1999.0255. Implementação uniforme ainda pendente para v0.5; desnecessária para a v0.7 aleatória com d constante. Twirling é técnica conhecida, não novidade nossa. Revisão focal, não sistemática, não certifica originalidade.

**Gate:** prova candidata e testes sustentam decodificação robusta polinomial no modelo BSC, não robustez em hardware. Provas requerem revisão por pesquisador independente. Qiskit/Aer e hardware não executados. Ainda faltam: comparação integral no mesmo modelo com estado da arte, implementação de multiplicação linear para d variável, ruído calibrado, custos de compilação e roteamento em QPU, aplicação real com oráculo coerente, confirmação de originalidade e revisão independente. Nenhuma nova investigação em Graph Collision ou aplicação blockchain nesta rodada, devido à contraevidência clássica anterior.

## 7. Reproduzir

```sh
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python robust.py
OPENBLAS_NUM_THREADS=1 python certification.py
OPENBLAS_NUM_THREADS=1 python crosscheck.py
OPENBLAS_NUM_THREADS=1 python scale.py
OPENBLAS_NUM_THREADS=1 python paired.py
OPENBLAS_NUM_THREADS=1 python twirl.py
# Em ambiente externo com Qiskit e Aer:
python -m pip install -r requirements-aer.txt
python qiskit_check.py
python aer_round9.py
```

Os seis scripts experimentais acima (sem Qiskit) foram executados. Todos os JSONs e logs de sucesso estão no ZIP. `previous.py`, `circuit.py`, `round4_reference.py`, `noise_validation.py`, `soft_noise.py` são referências copiadas da rodada anterior, não alegações de nova execução integral. Os testes externos foram apenas compilados sintaticamente. Não executar código com `-O`, pois os módulos legados usam asserts. Para experimento físico, escolher backend explicitamente autorizado, registrar calibração, data, job IDs, versão do transpiler, depth, SWAP/CX, shots, latência e orçamento; comparar ideal Aer, Aer calibrado, QPU e alternativas com mesmas instâncias. Pré-registrar critérios e sementes antes de executar; obter avaliação por pesquisador externo. Não há submissão automática à QPU nem cobrança nesta entrega.
