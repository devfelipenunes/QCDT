"""Independent gate-level checks for disjoint-mask probe identity and decoder."""
from pathlib import Path
import numpy as np,itertools as it,json
from robust import generate,observations,masks,decode
from circuit import Simulator,oracle_gates,derivative
from certification import dense_obs
from round4_reference import contraction

def word(a):return sum(int(v)<<i for i,v in enumerate(a))
def main():
 rng=np.random.default_rng(719099);checks=0;full=0;rows=[]
 for n,d in [(5,1),(6,2),(7,3)]:
  for k in range(5):
   E=generate(n,d,rng);lower={(i,) for i in range(n) if rng.random()<.5}|{e for e in it.combinations(range(n),2) if rng.random()<.25};sim=Simulator(n);g=oracle_gates(E|lower);A,B=masks(n,d,64,rng);Y=observations(A,B,E,rng);Z=dense_obs(A,B,E)
   for a,b,y,z in zip(A,B,Y,Z):
    a,b=word(a),word(b);r=sim.run(derivative(n,g,(a,b)));assert r==word(y)==word(z)==contraction(E,a,b);checks+=1
 for n,d in [(5,1),(6,2)]:
  for k in range(3):
   E=generate(n,d,rng);A,B=masks(n,d,1024 if d==1 else 2048,rng);sim=Simulator(n);g=oracle_gates(E|{(0,),(1,2)});cache={};Y=[]
   for a,b in zip(A,B):
    key=(word(a),word(b))
    if key not in cache:cache[key]=sim.run(derivative(n,g,key))
    Y.append([bool(cache[key]>>i&1) for i in range(n)])
   C=decode(A,B,np.asarray(Y),d);assert C==E;full+=1;rows.append(dict(n=n,d=d,probes=len(A),unique_gate_simulations=len(cache),exact=True))
 print('probe_checks',checks,'end_to_end',full);Path(__file__).with_name('crosscheck_results.json').write_text(json.dumps(dict(probe_checks=checks,end_to_end=full,rows=rows),indent=2))
if __name__=='__main__':main()
