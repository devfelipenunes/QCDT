"""Ideal sign randomization of modeled Rx errors, not implementation of physical randomized compiling."""
import numpy as np, random, itertools as it, json
from pathlib import Path
from noise_validation import Density, interval
from circuit import oracle_gates,derivative
from previous import direct_recover
from round4_reference import contraction
from soft_noise import candidates
class Twirled(Density):
 def channel(self,r,q,kind,p):
  if kind=='twirl':
   a=self.perm[q];s=np.sin(p/2)**2;return (1-s)*r+s*r[np.ix_(a,a)]
  return super().channel(r,q,kind,p)

def local_ml(n,keys,counts,shots):
 links=[]
 for i in range(n):
  pairs=[None]+list(it.combinations([j for j in range(n) if j!=i],2))
  cost=[]
  for edge in pairs:
   z=np.array([0 if edge is None else ((a>>edge[0]&1)*(b>>edge[1]&1))^((a>>edge[1]&1)*(b>>edge[0]&1)) for a,b in keys]);cost.append(np.sum(counts[:,i]+z*(shots-2*counts[:,i])))
  win=np.flatnonzero(np.array(cost)==min(cost))
  if len(win)!=1:return None
  p=pairs[win[0]];links.append(None if p is None else tuple(sorted((i,*p))))
 es=set(filter(None,links))
 return es if all(all(links[i]==e for i in e) for e in es) else None

def run():
 rng=np.random.default_rng(26112509);r=random.Random(26112509);n=5;sim=Twirled(n);cs=candidates(n);plan={};direct_recover(n,1,lambda a,b:plan.setdefault((a,b),0),compact=True);keys=list(plan)
 pred=np.array([[[contraction(c,a,b)>>i&1 for i in range(n)] for a,b in keys] for c in cs]);cases=[(set(r.choice(cs)),{(i,) for i in range(n) if r.random()<.5}|{e for e in it.combinations(range(n),2) if r.random()<.25}) for _ in range(60)]
 rows=[]
 # Compare independent shots from exact noise channels on same hidden cases.
 for theta in (.05,.15,.25):
  for kind in ('coherent_rx','twirl'):
   stats={s:[] for s in (5,15)}
   for E,lower in cases:
    og=oracle_gates(E|lower);samples=[]
    for a,b in keys:
     pr=sim.probs(derivative(n,og,(a,b)),kind,theta);z=rng.choice(1<<n,15,p=pr)
     for i in range(n):z^=(rng.random(15)<.002).astype(int)<<i
     samples.append(z)
    for shots in (5,15):
     c=np.array([[sum(int(v)>>i&1 for v in z[:shots]) for i in range(n)] for z in samples]);words=dict(zip(keys,[sum(int(v>shots//2)<<i for i,v in enumerate(row)) for row in c]));hard=None
     try:hard,_=direct_recover(n,1,lambda a,b:words[a,b],compact=True)
     except (ValueError,AssertionError,KeyError,IndexError,ZeroDivisionError):pass
     costs=(pred*(shots-2*c)+c).sum(axis=(1,2));idx=np.flatnonzero(costs==costs.min());global_ml=set(cs[idx[0]]) if len(idx)==1 else None
     local=local_ml(n,keys,c,shots)
     stats[shots].append(['rejected' if x is None else 'exact' if x==E else 'wrong' for x in (hard,local,global_ml)])
   for shots,data in stats.items():
    row=dict(theta=theta,kind=kind,shots=shots,trials=len(cases),phase_calls=4*len(keys)*shots)
    for j,name in enumerate(('hard','local','global')):
     z=[x[j] for x in data];row[name]={k:z.count(k) for k in ('exact','wrong','rejected')};row[name]['wilson95']=interval(z.count('exact'),len(z))
    rows.append(row);print(row,flush=True)
 Path(__file__).with_name('twirl_results.json').write_text(json.dumps(rows,indent=2))
if __name__=='__main__':run()
