"""Check counting-family construction for variable local degree on small cases."""
import itertools,math,json
from pathlib import Path

def families(m,d):
    assert m%d==0
    r=m//d;perms=list(itertools.permutations(range(r)))
    for choice in itertools.product(perms,repeat=d*d):
        edges=set()
        for shift in range(d):
            for block in range(d):
                for j,p in enumerate(choice[shift*d+block]):
                    a=block*r+j;b=((block+shift)%d)*r+p
                    edges.add((a,m+b,2*m+a))
        assert len(edges)==m*d
        assert all(sum(v in e for e in edges)==d for v in range(3*m))
        yield frozenset(edges)
rows=[]
for m,d in [(3,1),(4,2),(6,2),(6,3)]:
    sets=set(families(m,d));expected=math.factorial(m//d)**(d*d)
    assert len(sets)==expected
    rows.append(dict(n=3*m,d=d,distinct_graphs=len(sets),expected=expected))
print(rows)
Path(__file__).with_name('lower_bound_results.json').write_text(json.dumps(rows,indent=2))
