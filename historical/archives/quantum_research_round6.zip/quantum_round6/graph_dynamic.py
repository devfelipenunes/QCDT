"""Classical dynamic conflict baseline for transaction selection with known footprints."""
import random,json,time
from pathlib import Path

class Index:
    def __init__(self,footprints):
        self.f=footprints;self.active=set();self.total={};self.writers={};self.conflicting=0
    def set(self,i,value):
        if (i in self.active)==value:return 0
        if value:self.active.add(i)
        else:self.active.remove(i)
        delta=1 if value else -1
        for key,write in self.f[i].items():
            t,w=self.total.get(key,0),self.writers.get(key,0);old=t>=2 and w>=1
            t+=delta;w+=delta*write;assert 0<=w<=t
            self.total[key],self.writers[key]=t,w
            self.conflicting+=int(t>=2 and w>=1)-int(old)
        return len(self.f[i])
    def collision(self):return self.conflicting>0

def scan(f,active):
    counts={};writes={}
    for i in active:
        for k,w in f[i].items():
            counts[k]=counts.get(k,0)+1;writes[k]=writes.get(k,0)+w
    return any(c>=2 and writes[k]>=1 for k,c in counts.items())

def pairwise(f,active):
    a=list(active)
    for j,i in enumerate(a):
        for l in a[j+1:]:
            if any(f[i][k] or f[l][k] for k in f[i].keys()&f[l].keys()):return True
    return False

rng=random.Random(7132027);rows=[]
for n,k,keys,updates,interval in [(32,3,32,5000,1),(128,4,100,5000,1),(1024,4,2000,20000,10),(10000,4,20000,20000,100)]:
    f=[{key:rng.randrange(2) for key in rng.sample(range(keys),k)} for _ in range(n)]
    idx=Index(f);validated=0;cells=0;scan_cells=0;valid_pairs=0;it=0;scan_time=0;index_time=0
    for s in range(updates):
        i=rng.randrange(n);on=rng.random()<.5
        t=time.perf_counter();cells+=idx.set(i,on);actual=idx.collision();index_time+=time.perf_counter()-t
        if s%interval==0:
            t=time.perf_counter();expected=scan(f,idx.active);scan_time+=time.perf_counter()-t
            assert actual==expected;validated+=1;scan_cells+=sum(len(f[j]) for j in idx.active)
            if n<=128 and s%50==0:assert actual==pairwise(f,idx.active);valid_pairs+=1
    row=dict(n=n,k=k,updates=updates,checks=validated,pair_checks=valid_pairs,index_key_updates=cells,scan_key_visits=scan_cells,index_seconds=index_time,scan_seconds=scan_time,scan_every=interval);rows.append(row);print(row,flush=True)
Path(__file__).with_name('graph_dynamic_results.json').write_text(json.dumps(rows,indent=2))
