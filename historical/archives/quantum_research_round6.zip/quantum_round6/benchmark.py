import random,itertools,time,json,statistics
from pathlib import Path
from previous import direct_recover,random_hypergraph,statevector_probe,contraction
from weighted import recover,Tower
rng=random.Random(20261126);rows=[]
for n,d,reps in [(6,1,8),(6,2,8),(9,3,8),(12,4,6),(32,2,4),(32,4,4),(32,8,4),(64,4,3),(64,8,3),(64,12,2),(128,2,2),(128,8,2),(256,2,2),(256,8,1)]:
 ts=[[],[]];qs=[]
 for _ in range(reps):
  es=random_hypergraph(n,d,rng);p=statevector_probe(n,es,rng) if n<=12 else lambda a,b:contraction(es,a,b)
  st=time.perf_counter();g,q=recover(n,d,p,verify=es);ts[0].append(time.perf_counter()-st)
  st=time.perf_counter();g0,q0=direct_recover(n,d,p,compact=True,verify=es);ts[1].append(time.perf_counter()-st)
  assert g==g0==es;qs.append((q,q0))
 assert len(set(qs))==1
 row=dict(n=n,d=d,cases=reps,correct=reps,weighted_queries=q,previous_queries=q0,median_seconds=[statistics.median(x) for x in ts],mode='statevector' if n<=12 else 'contraction');rows.append(row);print(row,flush=True)
tr=list(itertools.combinations(range(5),3));count=0
for bits in range(1<<len(tr)):
 es={e for i,e in enumerate(tr) if bits>>i&1}
 if max(sum(v in e for e in es) for v in range(5))>2:continue
 assert recover(5,2,lambda a,b:contraction(es,a,b),verify=es)[0]==es;count+=1
g=Tower(8);z={g.mul((1<<8)|i,(1<<8)|j) for i,j in itertools.combinations(range(1,129),2)};assert len(z)==128*127//2
print('exhaustive',count,'pair labels',len(z),flush=True)
Path(__file__).with_name('results.json').write_text(json.dumps(dict(seed=20261126,rows=rows,exhaustive_cases=count,distinct_pair_labels=len(z)),indent=2))
